(function($) {
  'use strict';
   var aboutDataset = [
    ["1","Web Banner","<img src='../img/home-banner.jpg'>", "<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>"],
    ["2","Mobile Banner","<img src='../img/home-banner-m.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>"],
    ["3","KNOW MORE ABOUT US","Design studio specialising in architecture, illustration and photography","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["4","FIRST HEADING","An active lifestyle","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["5","SECOND HEADING","SURROUND YOURSELF WITH LOVE","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["6","ABOUT US PHOTO 1","<img src='../img/surround-1.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["7","ABOUT US PHOTO 2","<img src='../img/surround-2.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["8","ABOUT US PHOTO 3","<img src='../img/surround-3.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["9","ABOUT US PHOTO 4","<img src='../img/surround-4.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["10","ABOUT US PHOTO 5","<img src='../img/surround-5.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["11","ABOUT US PHOTO 6","<img src='../img/surround-6.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["12","ABOUT US PHOTO 7","<img src='../img/surround-7.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["13","ABOUT US PHOTO 8","<img src='../img/surround-8.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["14","THIRD HEADING","SELECT AN APRTMENT","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],       
    ["15","PHOTO","<img src='../img/select-1.jpg'>","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["16","Meta Keywords","Habitro","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
    ["17","Meta Description","Habitro","<a href='#'><i class='fas fa-pencil-alt text-secondary'></i></a>" ],
];

  var tableFour = $('#aboutpage').DataTable( {
    w: aboutDataset,
    columns: [
      { title: "Sr.No" },    
      { title: "Title" },  
      { title: "Content" },
      { title: "Action" },
    ],
  });
})(jQuery);
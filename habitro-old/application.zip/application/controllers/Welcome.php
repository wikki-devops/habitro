<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('home');
	}
	public function project()
	{
	    
		$this->load->view('project');
	}
	public function projects($id)
	{
		// print_r($id);
		$data['current_project']=$id;
		$this->load->view('projects',$data);
	}
	public function about()
	{
		$this->load->view('about');
	}
	public function legal()
	{
		// code...
		$this->load->view('legal');

	}
	public function contact()
	{
		// code...
		$this->load->view('contact');
	}
	public function blog()
	{
		$this->load->view('blog');
	}
	public function blogs($id)
	{
		$data['current_blog']=$id;
		$this->load->view('blogs',$data);
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/*Load View*/

	public function index()
	{
		$this->load->view('admin/login');
	}
	public function dashboard()
	{
		$this->load->view('admin/dashboard');
	}
	public function home()
	{
		$data=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on,home_page",'home',"home_page='Home'");
		 $ans['data']=$data;
		$this->load->view('admin/home',$ans);
	}
	public function edit($val)
	{
		$data=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on,home_page",'home',"home_id=".$val."");
		 $ans['data']=$data;
		$this->load->view('admin/home_edit',$ans);
	}

	public function about()
	{
		$data=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on,home_page",'home',"home_page='About Us'");
		 $ans['data']=$data;
		$this->load->view('admin/about',$ans);
	}
	public function projects()
	{
		$data=$this->myclass->select("project_id,project_name,project_homepage,project_sorting,project_status,project_updatedon",'project',"1  order by project_sorting");
		 $ans['data']=$data;
		$this->load->view('admin/project-list',$ans);
	}
	public function addprojects()
	{
		// code...
		$this->load->view('admin/add-project');
	}
	public function addProject_Action()
	{
		// code...
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];

		$imgfile2=$_FILES['userfile2'];
		$imgf2=time().$imgfile2['name'];

		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		$this->form_validation->set_rules('project_name','Project Name','required|trim');
		$this->form_validation->set_rules('project_banner_text','Project Banner Text','required|trim');
		$this->form_validation->set_rules('project_description','Project Description','required|trim');
		$this->form_validation->set_rules('project_sorting','Project Sorting Order','required|trim');
		$this->form_validation->set_rules('project_homepage','Project Show Home Page','required|trim');
		$this->form_validation->set_rules('project_page_title','Project Page Title','required|trim');
		$this->form_validation->set_rules('project_meta','Project Meta','required|trim');
		$this->form_validation->set_rules('project_meta_description','Project Meta Description','required|trim');
		$this->form_validation->set_rules('project_status','Project Status','required|trim');
		
			$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;

			$config2['upload_path'] = './img/';
			$config2['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config2['file_name'] = $imgf2;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';

		if($this->form_validation->run()==TRUE)
		{	
				if (!$this->upload->do_upload())
				{
								
					$data['data']=$data;
					$data['error']=$this->upload->display_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					
					$this->load->view('admin/add-project',$data);

					
				}
				else
				{
					
					$Insertdata['project_banner']			= $config['file_name'];
					$Insertdata['project_banner_mobile']	= $config2['file_name'];
					$Insertdata['project_name']				= $this->input->post('project_name');
					$Insertdata['project_banner_text']		= $this->input->post('project_banner_text');
					$Insertdata['project_description']		= $this->input->post('project_description');
					$Insertdata['project_homepage']			= $this->input->post('project_homepage');
					$Insertdata['project_sorting']			= $this->input->post('project_sorting');
					$Insertdata['project_slug']				= $this->input->post('project_slug');
					$Insertdata['project_page_title']		= $this->input->post('project_page_title');
					$Insertdata['project_meta']				= $this->input->post('project_meta');
					$Insertdata['project_meta_description']	= $this->input->post('project_meta_description');
					$Insertdata['project_status']			= $this->input->post('project_status');
					$Insertdata['project_added']			= date('Y-m-d_H-i');
					$ans=$this->admin_model->insert('project',$Insertdata);
					// $ans=$this->admin_model->update_record($id,' services',$edit_data,'home_id');
					$this->session->set_flashdata('success_msg',"New Project Created Successfully"); 
					// $this->services();
					redirect('admin/projects');
				}
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					
					$this->load->view('admin/add-project',$data);
		}
	}
	public function editProject($val)
	{
		$data=$this->myclass->select("project_id,project_name,project_banner,project_banner_text,project_description,project_homepage,project_sorting,project_page_title,project_meta,project_meta_description,project_status,project_slug",'project',"project_id=".$val."");
		 $ans['data']=$data;
		$this->load->view('admin/project_edit',$ans);
	}
	public function UpdateProject_Action()
	{
		// code...
		$id=$this->input->post('project_id');
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		$this->form_validation->set_rules('project_name','Project Name','required|trim');
		$this->form_validation->set_rules('project_banner_text','Project Banner Text','required|trim');
		$this->form_validation->set_rules('project_description','Project Description','required|trim');
		$this->form_validation->set_rules('project_sorting','Project Sorting Order','required|trim');
		$this->form_validation->set_rules('project_slug','Project Sorting Order','required|trim');
		$this->form_validation->set_rules('project_homepage','Project Show Home Page','required|trim');
		$this->form_validation->set_rules('project_page_title','Project Page Title','required|trim');
		$this->form_validation->set_rules('project_meta','Project Meta','required|trim');
		$this->form_validation->set_rules('project_meta_description','Project Meta Description','required|trim');
		$this->form_validation->set_rules('project_status','Project Status','required|trim');
		
		$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';

		if($this->form_validation->run()==TRUE)
		{	
				
					if($_FILES['userfile']['size'] !=0)
					{
						$Insertdata['project_banner']		= $config['file_name'];	
					}	
					

					$Insertdata['project_name']		=$this->input->post('project_name');
					$Insertdata['project_banner_text']	=$this->input->post('project_banner_text');
					$Insertdata['project_description']		=$this->input->post('project_description');
					$Insertdata['project_sorting']	=$this->input->post('project_sorting');
					$Insertdata['project_homepage']		=$this->input->post('project_homepage');
					$Insertdata['project_slug']				= $this->input->post('project_slug');
					$Insertdata['project_page_title']=$this->input->post('project_page_title');
					$Insertdata['project_meta']		=$this->input->post('project_meta');
					$Insertdata['project_meta_description']		=$this->input->post('project_meta_description');
					$Insertdata['project_status']		=$this->input->post('project_status');
					$ans=$this->admin_model->update_record($id,' project',$Insertdata,'project_id ');
					$this->session->set_flashdata('success_msg',"Project Update Successfully"); 
					redirect('admin/projects');
				
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					redirect('admin/projects');
		}
	}

	public function projectDel()
	{
		// code...
		$ans=$this->input->post('serviceDel');
		
		$this->load->model('admin/admin_model');
		$this->admin_model->delete_record($ans,'project_id','project');
		//echo 1;
		echo $ans;

	}

	public function addProjectPhoto()
	{
		// code...
		// $data=$this->myclass->select("project_photo_id,project_photo_proid,project_photo_sorting,project_photo_status,project_photo_updatedon",'proejct_photos',"project_photo_proid=".$val."");
		$project=$this->myclass->select("project_id,project_name,project_banner,project_banner_text,project_description,project_homepage,project_sorting,project_page_title,project_meta,project_meta_description,project_status",'project',"1 order by project_name");
		 $ans['project']=$project;
		$this->load->view('admin/project_photo',$ans);
	}
	public function addProjectPhoto_Action()
	{
		// code...
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		//$this->form_validation->set_rules('userfile','Project Photo','required|trim');
		$this->form_validation->set_rules('project_photo_proid','Project Name','required|trim');
		$this->form_validation->set_rules('project_photo_sorting','Project Sorting Order','required|trim');
		$this->form_validation->set_rules('project_photo_status','Project Status','required|trim');
		
		
		$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';
			
		if($this->form_validation->run()==TRUE)
		{	
				if (!$this->upload->do_upload())
				{
								
					$data['data']=$data;
					$data['error']=$this->upload->display_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					$this->load->view('admin/project_photo',$data);
				}
				else
				{
					
					$Insertdata['project_photo']		= $config['file_name'];
					$Insertdata['project_photo_proid']		=$this->input->post('project_photo_proid');
					$Insertdata['project_photo_sorting']	=$this->input->post('project_photo_sorting');
					$Insertdata['project_photo_status']		=$this->input->post('project_photo_status');
					$Insertdata['project_photo_added']		=date('Y-m-d_H-i');

					$ans=$this->admin_model->insert('proejct_photos',$Insertdata);
					// $ans=$this->admin_model->update_record($id,' services',$edit_data,'home_id');
					$this->session->set_flashdata('success_msg',"New Project Photos Added Successfully"); 
					// $this->services();
					redirect('admin/projectsPhoto');
				}
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					redirect('admin/project_photo');
		}
	}

	public function projectsPhoto()
	{
		// code...
		$data=$this->myclass->select("project_photo_id,project_name,project_photo,project_photo_sorting,project_photo_status,project_photo_updatedon",'proejct_photos,project',"project_photo_proid=project_id");
		
		 $ans['data']=$data;
		$this->load->view('admin/project_photo_list',$ans);
	}
	public function projectPhotoDel()
	{
		// code...
		$ans=$this->input->post('serviceDel');
		
		$this->load->model('admin/admin_model');
		$this->admin_model->delete_record($ans,'project_photo_id','proejct_photos');
		//echo 1;
		echo $ans;

	}
	public function editProjectPhoto($val)
	{
		
			// code...
	$data=$this->myclass->select("project_photo_id,project_name,project_photo_proid,project_photo,project_photo_sorting,project_photo_status,project_photo_updatedon",'proejct_photos,project',"project_photo_proid=project_id AND project_photo_id=".$val."");
	$project=$this->myclass->select("project_id,project_name,project_banner,project_banner_text,project_description,project_homepage,project_sorting,project_page_title,project_meta,project_meta_description,project_status",'project',"1 order by project_name");
		
	
		$ans['data']=$data;
		$ans['project']=$project;

		$this->load->view('admin/project_photo_edit',$ans);
	}
	public function UpdateProjectPhoto_Action()
	{
		// code...
		$id=$this->input->post('project_photo_id');
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		//$this->form_validation->set_rules('userfile','Project Photo','required|trim');
		$this->form_validation->set_rules('project_photo_proid','Project Name','required|trim');
		$this->form_validation->set_rules('project_photo_sorting','Project Sorting Order','required|trim');
		$this->form_validation->set_rules('project_photo_status','Project Status','required|trim');
		
		
		$config['upload_path'] = './img/';
		$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
		$config['file_name'] = $imgf;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$data['upload_data'] = '';

		$data=$this->myclass->select("project_photo_id,project_name,project_photo_proid,project_photo,project_photo_sorting,project_photo_status,project_photo_updatedon",'proejct_photos,project',"project_photo_proid=project_id AND project_photo_id=".$id."");
	
		$project=$this->myclass->select("project_id,project_name,project_banner,project_banner_text,project_description,project_homepage,project_sorting,project_page_title,project_meta,project_meta_description,project_status",'project',"1 order by project_name");

		if($this->form_validation->run()==TRUE)
		{	
				
					if($_FILES['userfile']['size'] !=0)
					{
						$Insertdata['project_photo']		= $config['file_name'];	
					}	
					
					$Insertdata['project_photo_proid']		=$this->input->post('project_photo_proid');
					$Insertdata['project_photo_sorting']	=$this->input->post('project_photo_sorting');
					$Insertdata['project_photo_status']		=$this->input->post('project_photo_status');
				//	$Insertdata['project_photo_added']		=date('Y-m-d_H-i');

					//$ans=$this->admin_model->insert('proejct_photos',$Insertdata);
					$ans=$this->admin_model->update_record($id,' proejct_photos',$Insertdata,'project_photo_id');
					$this->session->set_flashdata('success_msg',"New Project Photos Updated Successfully"); 
					// $this->services();
					redirect('admin/projectsPhoto');
				
		}
		else
		{
			$ans['data']=$data;
			$ans['error']=$this->upload->display_errors();
			
			$this->session->set_flashdata('error_msg',$ans['error']); 

			$ans['data']=$data;
			$ans['project']=$project;
			redirect('admin/project_photo_edit',$ans);
		}
	}
	public function blogs()
	{
		$data=$this->myclass->select("blog_id,blog_title,blog_sorting,blog_status,blog_updated_on",'blog',"1  order by blog_sorting");
		 $ans['data']=$data;

		$this->load->view('admin/blog-list',$ans);
	}
	public function addblogs()
	{
		// code...

		$this->load->view('admin/add-blog');
	}
	public function addBlog_Action()
	{
		// code...
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		//$this->form_validation->set_rules('userfile','Project Photo','required|trim');
		$this->form_validation->set_rules('blog_slug','Blog Slug','required|trim');
		$this->form_validation->set_rules('blog_title','Blog Title','required|trim');
		$this->form_validation->set_rules('blog_short_description','Blog Short Description','required|trim');
		$this->form_validation->set_rules('blog_content','Blog Content','required|trim');
		$this->form_validation->set_rules('blog_sorting','Blog Sorting Order','required|trim');
		$this->form_validation->set_rules('blog_page_title','Blog Title','required|trim');
		$this->form_validation->set_rules('blog_meta_keyword','Blog Meta Keywords','required|trim');
		$this->form_validation->set_rules('blog_meta_description','Blog Meta Description','required|trim');
		$this->form_validation->set_rules('blog_status','Blog Blog','required|trim');

		$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';
			
		if($this->form_validation->run()==TRUE)
		{	
				if (!$this->upload->do_upload())
				{
								
					$data['data']=$data;
					$data['error']=$this->upload->display_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					$this->load->view('admin/add-blog',$data);
				}
				else
				{
					
					$Insertdata['blog_banner']		= $config['file_name'];
					$Insertdata['blog_title']		=$this->input->post('blog_title');
					$Insertdata['blog_slug']	=$this->input->post('blog_slug');
					$Insertdata['blog_short_description']		=$this->input->post('blog_short_description');
					$Insertdata['blog_content']		=$this->input->post('blog_content');
					$Insertdata['blog_sorting']		=$this->input->post('blog_sorting');
					$Insertdata['blog_page_title']		=$this->input->post('blog_page_title');
					$Insertdata['blog_meta_keyword']		=$this->input->post('blog_meta_keyword');
					$Insertdata['blog_meta_description']		=$this->input->post('blog_meta_description');
					$Insertdata['blog_status']		=$this->input->post('blog_status');
					$Insertdata['blog_add_on']		=date('Y-m-d_H-i');

					$ans=$this->admin_model->insert('blog',$Insertdata);
					// $ans=$this->admin_model->update_record($id,' services',$edit_data,'home_id');
					$this->session->set_flashdata('success_msg',"New Blog Added Successfully"); 
					// $this->services();
					redirect('admin/blogs');
				}
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					redirect('admin/blogs');
		}
	}
	public function blogId()
	{
		// code...
		$ans=$this->input->post('blogid');
		
		$this->load->model('admin/Admin_model');
		$this->admin_model->delete_record($ans,'blog_id','blog');
		//echo 1;
		echo $ans;

	}

	public function editBlog($val)
	{
		$data=$this->myclass->select("blog_id,blog_slug,blog_title,blog_banner,blog_short_description,blog_content,blog_sorting,blog_page_title,blog_meta_keyword,blog_meta_description,blog_status",'blog',"blog_id=".$val."");
		 $ans['data']=$data;
		$this->load->view('admin/blog_edit',$ans);
	}

	public function UpdateBlog_Action()
	{
		// code...
		$id=$this->input->post('blog_id');
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		$this->form_validation->set_rules('blog_slug','Blog Slug','required|trim');
		$this->form_validation->set_rules('blog_title','Blog Title','required|trim');
		$this->form_validation->set_rules('blog_short_description','Blog Short Description','required|trim');
		$this->form_validation->set_rules('blog_content','Blog Content','required|trim');
		$this->form_validation->set_rules('blog_sorting','Blog Sorting Order','required|trim');
		$this->form_validation->set_rules('blog_page_title','Blog Title','required|trim');
		$this->form_validation->set_rules('blog_meta_keyword','Blog Meta Keywords','required|trim');
		$this->form_validation->set_rules('blog_meta_description','Blog Meta Description','required|trim');
		$this->form_validation->set_rules('blog_status','Blog Blog','required|trim');
		
			$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';

		if($this->form_validation->run()==TRUE)
		{	
					if($_FILES['userfile']['size'] !=0)
					{
						$Insertdata['blog_banner']		= $config['file_name'];	
					}	
					
					$Insertdata['blog_title']		=$this->input->post('blog_title');
					$Insertdata['blog_slug']	=$this->input->post('blog_slug');
					$Insertdata['blog_short_description']		=$this->input->post('blog_short_description');
					$Insertdata['blog_content']		=$this->input->post('blog_content');
					$Insertdata['blog_sorting']		=$this->input->post('blog_sorting');
					$Insertdata['blog_page_title']		=$this->input->post('blog_page_title');
					$Insertdata['blog_meta_keyword']		=$this->input->post('blog_meta_keyword');
					$Insertdata['blog_meta_description']		=$this->input->post('blog_meta_description');
					$Insertdata['blog_status']		=$this->input->post('blog_status');
					$Insertdata['blog_add_on']		=date('Y-m-d_H-i');
					
					$ans=$this->admin_model->update_record($id,' blog',$Insertdata,'blog_id ');
					$this->session->set_flashdata('success_msg',"Blog Update Successfully"); 
					redirect('admin/blogs');
				
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					redirect('admin/blogs');
		}
	}

	public function services()
	{
		// code...
		$data=$this->myclass->select("services_id,services_name,services_sorting,services_status,services_updated_on",'services',"1  order by services_sorting");
		 $ans['data']=$data;
		$this->load->view('admin/services-list',$ans);
	}
	public function addservice()
	{
		// code...
		$this->load->view('admin/add-services');
	}
	public function addService_Action()
	{
		// code...
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');

		// $this->form_validation->set_rules('userfile','Service Icon','required|trim');
		$this->form_validation->set_rules('services_name','Service Name','required|trim');
		$this->form_validation->set_rules('services_description','Service Description','required|trim');
		$this->form_validation->set_rules('services_sorting','Service Sorting Order','required|trim');
		$this->form_validation->set_rules('services_page_title','Service Page Title','required|trim');
		$this->form_validation->set_rules('services_meta','Service Meta Tags','required|trim');
		$this->form_validation->set_rules('services_meta_description','Service Meta Description','required|trim');
		$this->form_validation->set_rules('services_status','Service Status','required|trim');
		$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';
		
		if($this->form_validation->run()==TRUE)
		{	
				if (!$this->upload->do_upload())
				{
								
					$data['data']=$data;
					$data['error']=$this->upload->display_errors();
					$this->load->view('admin/addservice',$data);

					
				}
				else
				{
					
					$Insertdata['services_icon']		= $config['file_name'];
					$Insertdata['services_name']		=$this->input->post('services_name');
					$Insertdata['services_description']	=$this->input->post('services_description');
					$Insertdata['services_sorting']		=$this->input->post('services_sorting');
					$Insertdata['services_page_title']	=$this->input->post('services_page_title');
					$Insertdata['services_meta']		=$this->input->post('services_meta');
					$Insertdata['services_meta_description']=$this->input->post('services_meta_description');
					$Insertdata['services_status']		=$this->input->post('services_status');
					$ans=$this->admin_model->insert('services',$Insertdata);
					// $ans=$this->admin_model->update_record($id,' services',$edit_data,'home_id');
					$this->session->set_flashdata('success_msg',"New Service Created Successfully"); 
					// $this->services();
					redirect('admin/services');
				}
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					redirect('admin/addservice');
		}
	}
	public function UpdateService_Action()
	{
		// code...
		$id=$this->input->post('services_id');
		
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		$this->form_validation->set_rules('services_name','Service Name','required|trim');
		
			$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp|svg';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';

		if($this->form_validation->run()==TRUE)
		{	
				
					if($_FILES['userfile']['size'] !=0)
					{
						$Insertdata['services_icon']		= $config['file_name'];	
					}	
					$Insertdata['services_name']			=$this->input->post('services_name');
					$Insertdata['services_description']		=$this->input->post('services_description');
					$Insertdata['services_sorting']			=$this->input->post('services_sorting');
					$Insertdata['services_page_title']	=$this->input->post('services_page_title');
					$Insertdata['services_meta']		=$this->input->post('services_meta');
					$Insertdata['services_meta_description']=$this->input->post('services_meta_description');
					$Insertdata['services_status']		=$this->input->post('services_status');
					//$ans=$this->admin_model->insert('services',$Insertdata);
					
					$ans=$this->admin_model->update_record($id,' services',$Insertdata,'services_id');
					$this->session->set_flashdata('success_msg',"Service Update Successfully"); 
					redirect('admin/services');
				
		}
		else{
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']);
					redirect('admin/services');
		}
	}
	public function serviceDel()
	{
		// code...
		$ans=$this->input->post('serviceDel');
		
		$this->load->model('admin/admin_model');
		$this->admin_model->delete_record($ans,'services_id','services');
		//echo 1;
		echo $ans;

	}
	public function editServices($val)
	{
		$data=$this->myclass->select("services_id,services_name,services_description,services_icon,services_sorting,services_page_title,services_meta,services_meta_description,services_status,services_updated_on",'services',"services_id=".$val."");
		 $ans['data']=$data;
		$this->load->view('admin/services_edit',$ans);
	}

	public function contact()
	{
		$data=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on,home_page",'home',"home_page='Contact'");
		 $ans['data']=$data;
		$this->load->view('admin/contact',$ans);
	}

	public function file_upload()
	{
		// code...
		$id=$this->input->post('home_id');
		$imgfile=$_FILES['userfile'];
		$imgf=time().$imgfile['name'];
		$this->load->library('upload');
		$this->load->model('admin/admin_model');
		//print_r($imgfile);
		$config['upload_path'] = './img/';
			$config['allowed_types'] = 'gif|jpg|png|doc|xlsx|docx|pdf|bmp';
			$config['file_name'] = $imgf;
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			$data['upload_data'] = '';
			$data=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on,home_page",'home',"home_id=".$id."");
				if (!$this->upload->do_upload())
				{
					
					$data['data']=$data;
					$data['error']=$this->upload->display_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					$this->load->view('admin/home_edit',$data);

					
				}
				else
				{
					$edit_data['home_content']=$config['file_name'];
					$ans=$this->admin_model->update_record($id,'home',$edit_data,'home_id');
					$this->session->set_flashdata('success_msg',"Content Update Successfully"); 
					if($data[0]->home_page=='Home')
					{
						redirect('admin/home');
					}	

					if($data[0]->home_page=='About Us')
					{
						redirect('admin/about');
					}	

					if($data[0]->home_page=='contact')
					{
						redirect('admin/contact');
					}
				}
	}
	public function content_update()
	{
		// code...
		$ans=$this->input->post();
		$id=$this->input->post('home_id');
		$this->load->model('admin/admin_model');
		$this->form_validation->set_rules('home_content','Content','required|trim');
		$data=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on,home_page",'home',"home_id=".$id."");
	
		if($this->form_validation->run()==FALSE)
		{
					
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					$this->load->view('admin/home_edit',$data);
		}
		else
		{

					$edit_data['home_content']=$ans['home_content'];
					
					$ans=$this->admin_model->update_record($id,'home',$edit_data,'home_id');
					
					$this->session->set_flashdata('success_msg',"Content Update Successfully"); 
					if($data[0]->home_page=='Home')
					{
						redirect('admin/home');
					}	

					if($data[0]->home_page=='About Us')
					{
						redirect('admin/about');
					}	

					if($data[0]->home_page=='contact')
					{
						redirect('admin/contact');
					}

					
		}
	}

	public function login()
	{
		// code...
		$ans=$this->input->post();
		$this->load->model('admin/Admin_model');
		$this->form_validation->set_rules('user_email','Email','required|trim');
		$this->form_validation->set_rules('user_password','Password','required|trim');
		if($this->form_validation->run()==FALSE)
		{	
					
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					redirect('admin');
		}
		else
		{
					$user_email=$ans['user_email'];
					$user_password='habitro123'.sha1($ans['user_password']).'123456';
					$userData=$this->myclass->select("user_id,user_name,user_email,user_updated_on",'users',"user_email='".$user_email."' AND user_password='".$user_password."' limit 1");
					if($userData=='no')
					{
						$this->session->set_flashdata('error_msg','Invalid User Credentials'); 
						redirect('admin');
					}
					else
					{
						$newdata = array(
					        'username'  => $userData[0]->user_name,
					        'email'     =>  $userData[0]->user_email,
					        'logged_in' => TRUE
						);
						$this->session->set_userdata($newdata);
						redirect('admin/home');
					}
		}
	}

	public function profile()
	{
		// code...
		$data=$this->myclass->select("user_id,user_name,user_email,user_updated_on",'users',"user_id='1' limit 1");
		$ans['data']=$data;
		$this->load->view('admin/profile',$ans);
	}
	public function profileUpdate()
	{
		// code...
		$ans=$this->input->post();
		$this->load->model('admin/admin_model');
		$this->form_validation->set_rules('user_name','Name','required|trim');
		$this->form_validation->set_rules('user_email','Email','required|trim');
		if(!empty($this->input->post('user_password')))
		{
			$this->form_validation->set_rules('user_password','Password','required|trim');
			$this->form_validation->set_rules('user_cpassword','Confirm Password','required|matches[user_password]trim');
		}

		$data=$this->myclass->select("user_id,user_name,user_email,user_updated_on",'users',"user_id='1'");
	
		if($this->form_validation->run()==FALSE)
		{
					
					$data['data']=$data;
					$data['error']=validation_errors();
					$this->session->set_flashdata('error_msg',$data['error']); 
					$this->load->view('admin/profile',$data);
		}
		else
		{
					$edit_data['user_name']=$ans['user_name'];
					$edit_data['user_email']=$ans['user_email'];
					if(!empty($this->input->post('user_password')))
					{
						$edit_data['user_password']='habitro123'.sha1($ans['user_password']).'123456';
					}
					
					
					$ans=$this->admin_model->update_record('1','users',$edit_data,'user_id');
					
					$this->session->set_flashdata('success_msg',"User Profile Update Successfully"); 
					redirect('admin/profile');
					
		}
	}
	public function logout()
	{
		// code...
		$this->session->sess_destroy();
		redirect('admin');
	}
}


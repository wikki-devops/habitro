<?php 
$AboutData=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on",'home',"home_page='About Us'");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0"/>
    <title><?php echo $AboutData[6]->home_content;?></title>
     <meta name="keywords" content="<?php echo $AboutData[8]->home_content;?>" />
    <meta name="description" content="<?php echo $AboutData[7]->home_content;?>" />
    <meta property="og:title" content="<?php echo $AboutData[6]->home_content;?> " />
    <meta property="og:description" content="<?php echo $AboutData[7]->home_content;?>" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="img/favicon/android-icon-192x192.png" />
    <meta name="twitter:title" content="<?php echo $AboutData[6]->home_content;?>"/>
    <meta name="twitter:description" content="<?php echo $AboutData[7]->home_content;?>"/>
    <meta name="twitter:image" content="img/favicon/android-icon-192x192.png"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <meta name="msapplication-TileColor" content="#FAFAFA">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#FAFAFA">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <?php include_once('header.php');?>
    </header>

    <main>
        <section class="topSection">
            <div class="temp4">
                <div class="container">
                    <div class="temp4-inner">
                        <h2 class="mb0"><?php echo $AboutData[0]->home_content;?></h2>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="temp10">
                <div class="temp10-left">
                    <figure><img src="<?php echo base_url()."img/".$AboutData[1]->home_content;?>" alt="" data-aos="zoom-out" data-aos-duration="1000"></figure>
                </div>
                <div class="temp10-txt" data-aos="fade-up" data-aos-duration="1000">
                    <p><?php echo $AboutData[2]->home_content;?></p>
                    <h4><?php echo $AboutData[3]->home_content;?></h4>
                    <h6><?php echo $AboutData[4]->home_content;?></h6>
                </div>
            </div>
        </section>

        <section>
            <div class="temp11">
                <div class="container">
                    <div class="temp11-inner">
                        <ul>
                            <?php 
$ServicesData=$this->myclass->select("services_id,services_name,services_description,services_icon,services_sorting",'services',"services_status='Yes' order by services_sorting");
                                if(isset($ServicesData) && is_array($ServicesData))
                                {
                                    foreach($ServicesData as $val)
                                    {
                                        ?>
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <figure><img src="<?php echo base_url()."img/".$val->services_icon;?>" alt="<?php echo $val->services_name;?>"></figure>
                                <h3><?php echo $val->services_name;?></h3>
                                <p><?php echo $val->services_description;?></p>
                            </li>
                             <?php 

                                    }
                                }
                            ?>
                           
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="temp12">
                <div class="container">
                    <div class="temp12-inner">
                        <h3><?php echo $AboutData[5]->home_content;?></h3>
                    </div>
                </div>
            </div>
        </section>

        <section class="mb0">
            <div class="temp9">
                <div class="temp9-inner">
                    <div class="temp9-top" data-aos="fade-up" data-aos-duration="1000">
                        <a href="<?php echo base_url()."blog";?>" class="btn-sml">
                            NEXT
                            <span><img src="img/next.svg" alt="next"></span>
                        </a>
                    </div>
                    <div class="temp9-link2">
                        <div class="temp9-marquee">
                            <a href="<?php echo base_url()."blog";?>">BLOG</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer data-aos="fade-up" data-aos-duration="1000">
       <?php include_once('footer.php');?>
    </footer>
    
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/common.js"></script>
    <script src="js/gsap.min.js"></script>
	<script src="js/ScrollTrigger.min.js"></script>
    <script src="js/smoother.js"></script>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // register gsap scrollTrigger
        gsap.registerPlugin(ScrollTrigger, SplitText);


            (function() {
                const split1 = new SplitText('.temp4-inner h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp4-inner",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split1.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split1Done() { split1.revert() }
            })();


            (function() {
                const split2 = new SplitText('.temp12-inner h3', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp12-inner",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split2.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split2Done() { split2.revert() }
            })();


            (function() {
                const split3 = new SplitText('.temp9-marquee a', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp9-marquee",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split3.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split3Done() { split3.revert() }
            })();


    });
    </script>
</body>
</html>
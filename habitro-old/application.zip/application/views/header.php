
<a href="<?php echo base_url();?>" class="habitroLogo" data-aos="fade-down" data-aos-duration="1000">
            <figure><img src="<?php echo base_url();?>img/habitro-logo.png" alt="Habitro logo"></figure>
        </a>
        <nav data-aos="fade-down" data-aos-duration="1000">
            <ul>
                <li>
                    <a href="<?php echo base_url();?>" class="roll-link">
                        <span data-title="HOME">HOME</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>project" class="roll-link">
                        <span data-title="PROJECT">PROJECT</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."about-us";?>" class="roll-link">
                        <span data-title="ABOUT US">ABOUT US</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."blog";?>" class="roll-link">
                        <span data-title="BLOG">BLOG</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."contact";?>" class="roll-link">
                        <span data-title="CONTACT">CONTACT</span>
                    </a>
                </li>
            </ul>
        </nav>
        <div class="navToggle" data-aos="fade-down" data-aos-duration="1000">
            <span></span>
            <span></span>
        </div>
        <div class="navArea">
            <ul class="navList">
                <li>
                    <a href="<?php echo base_url();?>" class="roll-link">
                        <span data-title="HOME">HOME</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>project" class="roll-link">
                        <span data-title="PROJECT">PROJECTs</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."about-us";?>" class="roll-link activebNav">
                        <span data-title="ABOUT US">ABOUT US</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."blog";?>" class="roll-link">
                        <span data-title="BLOG">BLOG</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."contact";?>" class="roll-link">
                        <span data-title="CONTACT">CONTACT</span>
                    </a>
                </li>
            </ul>
        </div>
        <figure class="navFrame"><img src="<?php echo base_url();?>img/menu-frame.svg" alt="frame"></figure>
        <div class="navOverlay"></div>
<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
     <div class="row">

        <div class="col-md-12">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="fa fa-edit fs-16"></i> Services</a></li>
              <li class="breadcrumb-item active" aria-current="page">Edit Services</li>
            </ol>
          </nav>
        
            <?php

             if($this->session->flashdata('success_msg'))
            {
              ?>
          <div class="alert alert-success" role="alert">
            <strong>Well done!</strong> You successfully created new service.
          </div>
            <?php 
            }
            
            if($this->session->flashdata('error_msg'))
            {
              ?>
              <div class="alert alert-danger" role="alert">
                <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
              </div>
          
            <?php 
            }
            ?>
        </div>

        
        <div class="col-xl-12 col-md-12">
          <div class="ms-panel ms-panel-fh">
            <div class="ms-panel-header">
              <h6>Edit Service</h6>
            </div>
          
            <div class="ms-panel-body">

              <form class="needs-validation clearfix" novalidate action="<?php echo base_url()."admin/UpdateService_Action"; ?>" enctype="multipart/form-data" method="post">
                <input type="hidden" name="services_id" value="<?php echo $data[0]->services_id;?>">
                <div class="form-row">
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom12">Service Icon</label>
                    <div class="custom-file">
                      <!-- <input type="file" name="userfile" class="custom-file-input " > -->
                      <input type="file"  name="userfile" class="custom-file-input ">
                      <label class="custom-file-label" for="validatedCustomFile">Upload Images...</label>
                      
                    </div>

                  </div>
                 
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Service Title</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="services_name" id="validationCustom18" placeholder="Service Title" value="<?php echo $data[0]->services_name; ?>" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Service Name</div>
                    </div>
                  </div>

                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Service Description</label>
                    <div class="input-group">
                      <textarea  class="form-control" id="editor1" name="services_description" placeholder="Service Description" id="validationCustom18" required><?php echo $data[0]->services_description; ?> </textarea>
                     
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Service Description.</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Sorting Order</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="services_sorting" id="validationCustom18" placeholder="Service Sorting Order" value="<?php echo $data[0]->services_sorting; ?>" required>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Service Sorting Order.</div>
                    </div>
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Page Title</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="services_page_title" id="validationCustom18" placeholder="Service Titile" value="<?php echo $data[0]->services_page_title; ?>" required>
                       <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Service Page Title.</div>
                    </div>
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Meta Keywords</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="services_meta" id="validationCustom18" placeholder="Service Meta Keywords" value="<?php echo $data[0]->services_meta; ?>" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Service Meta Keywords</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Meta Description</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="services_meta_description" id="validationCustom18" placeholder="Service Meta Description" value="<?php echo $data[0]->services_meta_description; ?>" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Service Meta Description</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                     <label for="exampleSelect">Status</label>
                     <div class="input-group">
                  <select class="form-control" name="services_status" id="exampleSelect" required>
                    <option value="">Select Status</option>
                    <option value="Yes" <?php if($data[0]->services_status=='Yes'){ echo "selected";}?>>Active</option>
                    <option value="No" <?php if($data[0]->services_status=='No'){ echo "selected";}?>>In-Active</option>
                  </select>
                   <div class="valid-feedback">Looks good!</div>
                   <div class="invalid-feedback">Please select status.</div>
                 </div>
                </div>
                   <div class="col-md-12 mb-3">
                  
                   
                    <div class="custom-file">
                     <button class="btn btn-secondary d-block" type="submit">Submit</button>
                    </div>
                 
                </div>
                </div>
              </form>

            </div>
       
         
          </div>

        </div>
     
        

      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <!-- <script src="<?php echo base_url();?>assets/admin/js/home-tables.js"> </script> -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>

  
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
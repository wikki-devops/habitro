<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
     <div class="row">

        <div class="col-md-12">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="fa fa-edit fs-16"></i> Blog</a></li>
              <li class="breadcrumb-item active" aria-current="page">Edit Blog</li>
            </ol>
          </nav>
        
            <?php

             if($this->session->flashdata('success_msg'))
            {
              ?>
          <div class="alert alert-success" role="alert">
            <strong>Well done!</strong> You successfully created new service.
          </div>
            <?php 
            }
            
            if($this->session->flashdata('error_msg'))
            {
              ?>
              <div class="alert alert-danger" role="alert">
                <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
              </div>
          
            <?php 
            }
            ?>
        </div>

        
        <div class="col-xl-12 col-md-12">
          <div class="ms-panel ms-panel-fh">
            <div class="ms-panel-header">
              <h6>Edit Blog</h6>
            </div>
          
            <div class="ms-panel-body">

              <form class="needs-validation clearfix" novalidate action="<?php echo base_url()."admin/UpdateBlog_Action"; ?>" enctype="multipart/form-data" method="post">
                <div class="form-row">
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom12">Blog Banner</label>
                    <div class="custom-file">
                      <input type="file" name="userfile" class="custom-file-input" >
                      <label class="custom-file-label" for="validatedCustomFile">Upload Images...</label>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Blog Banner</div>
                    </div>
                    <input type="hidden" name="blog_id" value="<?php echo $data[0]->blog_id; ?>">
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Slug URL</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="blog_slug" id="validationCustom18" placeholder="Blog Slug URL" value="<?php echo $data[0]->blog_slug; ?>" required>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Blog Slug URL.</div>
                    </div>
                  </div>
                 
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Blog Title</label>
                    <div class="input-group">
                       <textarea  class="form-control" rows='4' cols="4"  id="editor2" name="blog_title" placeholder="Blog Title" id="validationCustom18"  required><?php echo $data[0]->blog_title; ?></textarea>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Blog Title</div>
                    </div>
                  </div>

                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Blog Short Description</label>
                    <div class="input-group">
                      <textarea  class="form-control" rows='4' cols="4"  id="editor1" name="blog_short_description" placeholder="Blog Short Description" id="validationCustom18"  required><?php echo $data[0]->blog_short_description; ?></textarea>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Short Description Description.</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Blog Content</label>
                    <div class="input-group">
                      <textarea  class="form-control" rows='4' cols="4"  id="editor3" name="blog_content" placeholder="Blog Content" id="validationCustom18"  required><?php echo $data[0]->blog_content; ?></textarea>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Short Description Description.</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Sorting Order</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="blog_sorting" id="validationCustom18" placeholder="Blog Sorting Order" value="<?php echo $data[0]->blog_sorting; ?>" required>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Blog Sorting Order.</div>
                    </div>
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Page Title</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="blog_page_title" id="validationCustom18" placeholder="Blog Titile" value="<?php echo $data[0]->blog_page_title; ?>" required>
                       <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Blog Page Title.</div>
                    </div>
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Meta Keywords</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="blog_meta_keyword" id="validationCustom18" placeholder="Blog Meta Keywords" value="<?php echo $data[0]->blog_meta_keyword; ?>" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Blog Meta Keywords</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Meta Description</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="blog_meta_description" id="validationCustom18" placeholder="Blog Meta Description" value="<?php echo $data[0]->blog_meta_description; ?>" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please provide Blog Meta Description</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                     <label for="exampleSelect">Status</label>
                     <div class="input-group">
                  <select class="form-control" name="blog_status" id="exampleSelect" required>
                    <option value="">Select Status</option>
                    <option value="Yes" <?php if($data[0]->blog_status=='Yes'){ echo "selected";}?>>Active</option>
                    <option value="No" <?php if($data[0]->blog_status=='No'){ echo "selected";}?>>In-Active</option>
                  </select>
                   <div class="valid-feedback">Looks good!</div>
                   <div class="invalid-feedback">Please select status.</div>
                 </div>
                </div>
                   <div class="col-md-12 mb-3">
                  
                   
                    <div class="custom-file">
                     <button class="btn btn-secondary d-block" type="submit">Submit</button>
                    </div>
                 
                </div>
                </div>
              </form>

            </div>
       
         
          </div>

        </div>
     
        

      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <!-- <script src="<?php echo base_url();?>assets/admin/js/home-tables.js"> </script> -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>

  
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
     <div class="row">

        <div class="col-md-12">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a><i class="material-icons">home</i> <?php echo $data[0]->home_page; ?> </a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo $data[0]->home_page; ?> Content</li>
            </ol>
          </nav>
         
            <?php

          
            
            if($this->session->flashdata('error_msg'))
            {
              ?>
              <div class="alert alert-danger" role="alert">
                <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
              </div>
          
            <?php 
            }
            ?>
        
        </div>

        
        <div class="col-xl-6 col-md-12">
          <div class="ms-panel ms-panel-fh">
            <div class="ms-panel-header">
              <h6>Update <?php echo $data[0]->home_content_heading; ?></h6>
            </div>
             <?php 
            
        if($data[0]->home_content_type =='Image')
         { 
        ?>
            <div class="ms-panel-body">

              <form class="needs-validation clearfix" novalidate action="<?php echo base_url()."admin/file_upload"; ?>" enctype="multipart/form-data" method="post">
                <div class="form-row">
                  <div class="col-md-12 mb-3">
                    <label for="validationCustom12"><?php echo $data[0]->home_content_heading; ?> Image</label>
                    <div class="custom-file">
                      <input type="file"  name="userfile" class="custom-file-input" id="validatedCustomFile">
                      <label class="custom-file-label" for="validatedCustomFile">Upload Images...</label>
                      <div class="invalid-feedback">Example invalid custom file feedback</div>
                    </div>
                  </div>
                   <div class="col-md-12 mb-3">
                    <input type="hidden" name="home_id" value="<?php echo $data[0]->home_id;?>">
                    <div class="custom-file">
                     <button class="btn btn-secondary d-block" type="submit">Submit</button>
                    </div>
                  </div>
                </div>
              </form>

            </div>
        <?php 
        }
        else{
          ?>
            <div class="ms-panel-body">
              <form class="needs-validation clearfix" novalidate action="<?php echo base_url()."admin/content_update"; ?>" enctype="multipart/form-data" method="post">
                <div class="form-row">
                  <div class="col-md-12 mb-3">
                    <label for="validationCustom18"><?php echo $data[0]->home_content_heading; ?></label>
                    <div class="input-group">
                      <textarea class="form-control" id="editor1" rows="10" name="home_content" required id="validationCustom18" required><?php echo $data[0]->home_content; ?>
                      </textarea>
                     
                      <div class="valid-feedback">
                        Looks good!
                      </div>
                       <div class="invalid-feedback">Please Provide Content</div>
                    </div>
                  </div>
                   <div class="col-md-12 mb-3">
                    <input type="hidden" name="home_id" value="<?php echo $data[0]->home_id;?>">
                    <div class="custom-file">
                     <button class="btn btn-secondary d-block" type="submit">Submit</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          <?php
        }
        ?>
          </div>

        </div>
        <?php 
        if($data[0]->home_content_type=='Image')
         { 
        ?>
        <div class="col-xl-6 col-md-12">
          <div class="row">
            <div class="col-md-12">
              <div class="ms-panel">
                <div class="ms-panel-header">
                  <h6>Current Photo </h6>
                </div>
                <div class="ms-panel-body">
                  <div id="imagesSlider" class="ms-image-slider carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img class="d-block w-100" src="<?php echo base_url();?>img/<?php echo $data[0]->home_content?>">
                      </div>
                      
                    </div>
                   
                  </div>
                </div>
               
              
              </div>
            </div>
          </div>
        </div>
        <?php 
        }
        ?>

      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <!-- <script src="<?php echo base_url();?>assets/admin/js/home-tables.js"> </script> -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>

  
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
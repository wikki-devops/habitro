<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
      <div class="row">
        <div class="col-md-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="material-icons fs-16">phone</i> Contact</a></li>
              
            </ol>
          </nav>
          <div class="ms-panel">
            <div class="ms-panel-header">
              <h6>Contact</h6>
            </div>
            <div class="ms-panel-body">
              <div class="table-responsive">
                <table id="blogpage" class="table w-100 thead-primary">
                   <thead>
                    <tr>
                    <th>Sr. No</th>
                    <th>Heading</th>
                    <th>Content</th>
                    <th>Updated On</th>
                    <th>Action</th>
                  <tr>  
                  </thead>
                  <tbody>
                    <?php 
                    $i=1;
                    foreach($data as $val)
                    {
                      ?>
                        <tr>
                          <td><?php echo $i;?></td>
                          <td><?php echo $val->home_content_heading;?></td>
                          <td><?php 
                          if($val->home_content_type=='Image')
                           {
                            echo "<img  style='width:400px; height:400px' src='".base_url()."img/".$val->home_content."'>";
                           }
                           else
                           {
                            // echo $val->home_content;  
                             echo substr_replace($val->home_content, "...", 30);
                           } 
                          ?></td>
                          <td><?php echo date('d-M-y H:s a',strtotime($val->home_updated_on));?></td>
                          <td><a href='<?php echo base_url()."admin/edit/".$val->home_id;?>'><i class='fas fa-pencil-alt text-secondary'></i></a></td>
                        </tr>
                      <?php
                      $i++;
                    }
                    ?>
                  
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->
  <!-- Page Specific Scripts Start -->
  <!-- <script src="<?php echo base_url();?>assets/admin/js/blog-list-tables.js"> </script> -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
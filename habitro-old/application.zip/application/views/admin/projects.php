<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
      <div class="row">
        <div class="col-md-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="material-icons">home</i> Home</a></li>
              <li class="breadcrumb-item"><a href="#">Menu</a></li>
              <li class="breadcrumb-item active" aria-current="page">Menu List</li>
            </ol>
          </nav>
          <div class="ms-panel">
            <div class="ms-panel-header">
              <h6>Product List</h6>
            </div>
            <div class="ms-panel-body">
              <div class="table-responsive">
                <table id="data-table-5" class="table w-100 thead-primary"></table>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->
  <!-- Page Specific Scripts Start -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>

  
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
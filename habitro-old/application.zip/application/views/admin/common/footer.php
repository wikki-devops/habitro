<script type="text/javascript">
  var BASE_URL = '<?= base_url(); ?>'
  
</script>
<!-- Global Required Scripts Start -->
  <script src="<?php echo base_url();?>assets/admin/js/jquery-3.3.1.min.js"></script>
  <script src="<?php echo base_url();?>assets/admin/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/admin/js/perfect-scrollbar.js">
  </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery-ui.min.js">
  </script>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Finish -->
  <script src="<?php echo base_url();?>assets/admin/js/datatables.min.js"> </script>
  
  
  <!-- Costic core JavaScript -->
  <script src="<?php echo base_url();?>assets/admin/js/framework.js"></script>
  <!-- Settings -->
  <script src="<?php echo base_url();?>assets/admin/js/settings.js"></script>
  <script>
    CKEDITOR.replace('editor1', {
      height: 200,
      // By default, some basic text styles buttons are removed in the Standard preset.
      // The code below resets the default config.removeButtons setting.
      removeButtons: '',
      removeButtons: 'PasteFromWord',
      enterMode : CKEDITOR.ENTER_BR,
      shiftEnterMode: CKEDITOR.ENTER_P
    });
     CKEDITOR.replace('editor2', {
      height: 200,
      // By default, some basic text styles buttons are removed in the Standard preset.
      // The code below resets the default config.removeButtons setting.
      removeButtons: '',
      removeButtons: 'PasteFromWord',
       enterMode : CKEDITOR.ENTER_BR,
        shiftEnterMode: CKEDITOR.ENTER_P
    });
      CKEDITOR.replace('editor3', {
      height: 200,
      // By default, some basic text styles buttons are removed in the Standard preset.
      // The code below resets the default config.removeButtons setting.
      removeButtons: '',
      removeButtons: 'PasteFromWord',
      enterMode : CKEDITOR.ENTER_BR,
      shiftEnterMode: CKEDITOR.ENTER_P
    });
  </script>
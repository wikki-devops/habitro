<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
     <div class="row">

        <div class="col-md-12">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-regular fa-image fs-16"></i>
                <!-- <i class="fa fa-edit fs-16"></i> --> Projects</a></li>
              <li class="breadcrumb-item active" aria-current="page">Projects Photo</li>
            </ol>
          </nav>
        
            <?php

             if($this->session->flashdata('success_msg'))
            {
              ?>
          <div class="alert alert-success" role="alert">
            <strong>Well done!</strong> You successfully added project photo.
          </div>
            <?php 
            }
            
            if($this->session->flashdata('error_msg'))
            {
              ?>
              <div class="alert alert-danger" role="alert">
                <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
              </div>
          
            <?php 
            }
            ?>
        </div>

        
        <div class="col-xl-6 col-md-12">
          <div class="ms-panel ms-panel-fh">
            <div class="ms-panel-header">
              <h6>Project Photo</h6>
            </div>
          
            <div class="ms-panel-body">

              <form class="needs-validation clearfix" novalidate action="<?php echo base_url()."admin/addProjectPhoto_Action"; ?>" enctype="multipart/form-data" method="post">
                <div class="form-row">
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom12">Project Photo</label>
                    <div class="custom-file">
                      <!-- <input type="file" name="userfile" required> -->
                      <input type="file"  name="userfile" class="custom-file-input " required>
                      <label class="custom-file-label" for="validatedCustomFile">Upload Images...</label>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please Provide Project Photo</div>
                    </div>
                    
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Project</label>
                    <div class="input-group">
                     
                    <select class="form-control" name="project_photo_proid" id="exampleSelect" required>
                    <option value="">Select Project</option>
                    <?php 
                      if(isset($project) && is_array($project))
                      {
                        foreach($project as $val)
                        {
                          ?>
                           <option value="<?php echo $val->project_id; ?>"><?php echo $val->project_name; ?></option>
                          <?php
                        }  
                       

                      }  
                    ?>
                   
                   
                  </select>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please Provide Project Name</div>
                    </div>
                  </div>
                  
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Sorting Order</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="project_photo_sorting" id="validationCustom18" placeholder="Project Photo Sorting Order" value="" required>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Sorting Order.</div>
                    </div>
                  </div>
                 
                  <div class="col-md-6 mb-3">
                     <label for="exampleSelect">Status</label>
                     <div class="input-group">
                  <select class="form-control" name="project_photo_status" id="exampleSelect" required>
                    <option value="">Select Status</option>
                    <option value="Yes">Active</option>
                    <option value="No">In-Active</option>
                  </select>
                   <div class="valid-feedback">Looks good!</div>
                   <div class="invalid-feedback">Please Select Status.</div>
                 </div>
                </div>
                   <div class="col-md-12 mb-3">
                  
                   
                    <div class="custom-file">
                     <button class="btn btn-secondary d-block" type="submit">Submit</button>
                    </div>
                 
                </div>
                </div>
              </form>

            </div>
       
         
          </div>

        </div>
        <div class="col-xl-6 col-md-12">
          <div class="row">
            <div class="col-md-12">
              <div class="ms-panel">
                <div class="ms-panel-header">
                  <h6>Project Banner </h6>
                </div>
                <div class="ms-panel-body">
                  <div id="imagesSlider" class="ms-image-slider carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <?php 
                        if(isset($data) && is_array($data))
                        {
                          foreach($data as $val)
                          {
                            ?>
                            <img class="d-block w-100" style="width:300px; height: 300px"> src="<?php echo base_url();?>img/<?php echo $val->project_photo?>">
                            
                            <?php  
                          }  
                        }
                        else
                        {
                           echo "Project Photo Not Found";
                        }  
                        ?>
                       
                      </div>
                      
                    </div>
                   
                  </div>
                </div>
               
              
              </div>
            </div>
          </div>
        </div>
        

      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <!-- <script src="<?php echo base_url();?>assets/admin/js/home-tables.js"> </script> -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>

  
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
     <div class="row">

        <div class="col-md-12">
         <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="fa fa-edit fs-16"></i> Projects</a></li>
              <li class="breadcrumb-item active" aria-current="page">Update Projects</li>
            </ol>
          </nav>
        
            <?php

             if($this->session->flashdata('success_msg'))
            {
              ?>
          <div class="alert alert-success" role="alert">
            <strong>Well done!</strong> You successfully update project.
          </div>
            <?php 
            }
            
            if($this->session->flashdata('error_msg'))
            {
              ?>
              <div class="alert alert-danger" role="alert">
                <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
              </div>
          
            <?php 
            }
            ?>
        </div>

        
        <div class="col-xl-12 col-md-12">
          <div class="ms-panel ms-panel-fh">
            <div class="ms-panel-header">
              <h6>Update Project</h6>
            </div>
          
            <div class="ms-panel-body">

              <form class="needs-validation clearfix" novalidate action="<?php echo base_url()."admin/UpdateProject_Action"; ?>" enctype="multipart/form-data" method="post">
                <div class="form-row">
                  <div class="col-md-12 mb-3">
                    <label for="validationCustom12">Project Banner</label>
                    <div class="custom-file">
                      <!-- <input type="file" name="userfile" required> -->
                      <input type="file"  name="userfile" class="custom-file-input ">
                      <label class="custom-file-label" for="validatedCustomFile">Upload Images...</label>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please Provide Project Banner</div>
                    </div>
<input type="hidden" name="project_id" value="<?php echo $data[0]->project_id; ?>">
                  </div>
                 
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Project Name</label>
                    <div class="input-group">
                      <textarea  class="form-control" id="editor3" name="project_name" placeholder="Project Name"  id="validationCustom18" required><?php echo $data[0]->project_name; ?></textarea>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please Provide Project Name</div>
                    </div>
                  </div>

                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Banner Text</label>
                    <div class="input-group">
                      <textarea  class="form-control" id="editor1" name="project_banner_text"  placeholder="Banner Text" id="validationCustom18" required><?php echo $data[0]->project_banner_text; ?></textarea>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please Provide Banner Text.</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">About Project</label>
                    <div class="input-group">
                    <textarea  class="form-control" id="editor2" name="project_description" placeholder="About Project" id="validationCustom18" required><?php echo $data[0]->project_description; ?></textarea>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please Provide About Project Information.</div>
                    </div>
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Sorting Order</label>
                    <div class="input-group">
                      <input type="text" class="form-control" value="<?php echo $data[0]->project_sorting; ?>" name="project_sorting" id="validationCustom18" placeholder="Project Sorting Order" required>
                     <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide Project Sorting Order.</div>
                    </div>
                  </div>
                     <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Project URL</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="project_slug" id="validationCustom18" placeholder="Project URL" value="<?php echo $data[0]->project_slug; ?>" required>
                       <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please Provide Project Page Title.</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                     <label for="exampleSelect">Project Show On Home Page</label>
                     <div class="input-group">
                  <select class="form-control" name="project_homepage" id="exampleSelect" required>
                    <option value="">Select Project Status</option>
                    <option value="Yes" <?php if($data[0]->project_homepage=='Yes'){ echo "selected";}?>>Yes</option>
                    <option value="No" <?php if($data[0]->project_homepage=='No'){ echo "selected";}?>>No</option>
                  </select>
                   <div class="valid-feedback">Looks good!</div>
                   <div class="invalid-feedback">Please Select Status.</div>
                 </div>
                </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Page Title</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="project_page_title" value="<?php echo $data[0]->project_page_title; ?>" id="validationCustom18" placeholder="Project Page Titile" value="" required>
                       <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please Provide Project Page Title.</div>
                    </div>
                  </div>
                   <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Meta Keywords</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="project_meta" value="<?php echo $data[0]->project_meta; ?>" id="validationCustom18" placeholder="Project Meta Keywords" value="" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please Provide Project Meta Keywords</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="validationCustom18">Meta Description</label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="project_meta_description" value="<?php echo $data[0]->project_meta_description; ?>" id="validationCustom18" placeholder="Project Meta Description" value="" required>
                      <div class="valid-feedback">Looks good!</div>
                      <div class="invalid-feedback">Please Provide Project Meta Description</div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                     <label for="exampleSelect">Status</label>
                     <div class="input-group">
                  <select class="form-control" name="project_status" id="exampleSelect" required>
                    <option value="">Select Status</option>
                    <option value="Yes" <?php if($data[0]->project_status=='Yes'){ echo "selected";}?>>Active</option>
                    <option value="No" <?php if($data[0]->project_status=='No'){ echo "selected";}?>>In-Active</option>
                  </select>
                   <div class="valid-feedback">Looks good!</div>
                   <div class="invalid-feedback">Please Select Status.</div>
                 </div>
                </div>
                   <div class="col-md-12 mb-3">
                  
                   
                    <div class="custom-file">
                     <button class="btn btn-secondary d-block" type="submit">Submit</button>
                    </div>
                 
                </div>
                </div>
              </form>

            </div>
       
         
          </div>

        </div>
        <div class="col-xl-6 col-md-12">
          <div class="row">
            <div class="col-md-12">
              <div class="ms-panel">
                <div class="ms-panel-header">
                  <h6>Project Banner </h6>
                </div>
                <div class="ms-panel-body">
                  <div id="imagesSlider" class="ms-image-slider carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img class="d-block w-100" src="<?php echo base_url();?>img/<?php echo $data[0]->project_banner?>">
                      </div>
                      
                    </div>
                   
                  </div>
                </div>
               
              
              </div>
            </div>
          </div>
        </div>
        

      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <!-- <script src="<?php echo base_url();?>assets/admin/js/home-tables.js"> </script> -->
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>

  
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
</body>
</html>
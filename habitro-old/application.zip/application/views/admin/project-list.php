<?php include_once('common/header.php');?>
  <!-- Main Content -->
  <main class="body-content">
    <!-- Navigation Bar -->
    <?php include_once('common/menu.php');?>
    <div class="ms-content-wrapper">
      <div class="row">
        <div class="col-md-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="fa fa-archive fs-16"></i> Projects</a></li>
              <li class="breadcrumb-item active" aria-current="page">Project List</li>
            </ol>
          </nav>
           <?php

             if($this->session->flashdata('success_msg'))
            {
              ?>
          <div class="alert alert-success" role="alert">
            <strong>Well done!</strong> <?php echo $this->session->flashdata('success_msg'); ?>
          </div>
            <?php 
            }
            
            if($this->session->flashdata('error_msg'))
            {
              ?>
              <div class="alert alert-danger" role="alert">
                <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error_msg'); ?>
              </div>
          
            <?php 
            }
            ?>
          <div class="ms-panel">
            <div class="ms-panel-header">
              <h6>Project List</h6>
            </div>
            <div class="ms-panel-body">
              <div class="table-responsive">
                
                 <table id="blogpage" class="table w-100 thead-primary">
                    <thead>
                    <tr>
                    <th>Sr.No</th>
                    <th>Project</th>
                    <th>Home Page</th>
                    <th>Order By</th>
                    <th>Status</th>
                    <th>Updated On</th>
                    <th>Action</th>
                  <tr>  
                  </thead>
                  <tbody>
                    <?php
                    if(isset($data) && is_array($data))
                    { 
                      $i=1;
                      foreach($data as $val)
                      {
                        ?>
                          <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo $val->project_name;?></td>
                            <td><?php echo $val->project_homepage; ?></td>
                            <td><?php echo $val->project_sorting;?></td>
                            <td><?php echo $val->project_status; ?></td>
                            <td><?php echo date('d-M-y H:s a',strtotime($val->project_updatedon));?></td>
                            <td><a href='<?php echo base_url()."admin/editProject/".$val->project_id;?>'><i class='fas fa-pencil-alt text-secondary'></i></a><a href='#' class="del" id="<?php echo $val->project_id;?>"><i class='fas fa-trash text-secondary'></i></a></td>
                          </tr>
                        <?php
                        $i++;
                      }
                    }
                    else
                    {
                        ?>
                        <tr>
                          <td colspan="3">&nbsp;</td>
                          <td colspan="7">No data found</td>
                        </tr>
                        <?php
                        
                    }
                    ?>
                  


                  
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <?php include_once('common/footer.php');?>
  <!-- Global Required Scripts End -->
  <!-- Page Specific Scripts Start -->
  
  <script src="<?php echo base_url();?>assets/admin/js/slick.min.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/moment.js"> </script>
  <script src="<?php echo base_url();?>assets/admin/js/jquery.webticker.min.js"> </script>
  <!-- Page Specific Scripts Start -->
  <!-- Page Specific Scripts End -->
 <!--  <script type="text/javascript">
    
    $('#example').DataTable({
        ajax: BASE_URL+"admin/callAjax",
    });
  </script> -->
   <script type="text/javascript">
    $(document).ready(function(){
      $(".del").click(function(){
         if(confirm("Are you sure you want to delete this service?"))
          {
            var serviceId=$(this).attr('id');
           // alert(serviceId);
            $.ajax({
              method:'POST',
              url:BASE_URL+"admin/projectDel",
              data:{'serviceDel':serviceId},
              success:function(data)
                        {
                            location.reload();
                            // alert(data);
                            //$('#employee_data').bootgrid('reload');
                        }
            });
          }
      })

    })
  </script>
</body>
</html>
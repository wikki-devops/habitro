<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0"/>
    <title>Habitro | Legal Information</title>
    <meta name="keywords" content="Habitro" />
    <meta name="description" content="Habitro" />
    <meta property="og:title" content="Habitro" />
    <meta property="og:description" content="Habitro" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="img/favicon/android-icon-192x192.png" />
    <meta name="twitter:title" content="Habitro"/>
    <meta name="twitter:description" content="Habitro"/>
    <meta name="twitter:image" content="img/favicon/android-icon-192x192.png"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <meta name="msapplication-TileColor" content="#FAFAFA">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#FAFAFA">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
         <?php include_once('header.php');?>
    </header>

    <main>
        <section class="topSection">
            <div class="temp15">
                <div class="container">
                    <div class="temp15-head">
                        <h1>Legal Information</h1>
                    </div>
                    <div class="temp15-list">
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>General Principles</h6>
                            <p>We are committed to protecting and respecting your privacy. We collect your personal information and process your personal data in accordance to the law which regulates the processing of personal data. Please read the following carefully to understand our views and practices regarding your personal data.</p> 
                            <p>This online privacy statement describes Habitro current online practices in respect of personal information collected through this website. If you do not agree with these terms, please do not disclose any personal information to us.</p>
                            <p>We collect your personal information in order to provide and continually improve our quality, approach, process and services that help you interact with the peanut community and us in a better way.</p>
                            <p>All our subsidiaries, associate companies, partner firms and any third party working with or for us, and who have access to personal information, will be expected to read and comply with this policy. No third party may access or process sensitive personal information held by us without having first entered into a confidentiality agreement.</p>  
                            <p>Habitro privacy policy is subject to change for improvement at any time without any notification. To make sure you are aware of any changes to the policy, you may review the policy periodically.</p>
                            <p>This privacy policy was last amended on 18th of September 2020.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Personal Data that We Collect</h6>
                            <p>We collect personal data that is relevant to our business and/or employment relationship with you.</p>
                            <p>If you are a shareholder, director, corporate officer, manager, employee or appointed contractor of any business entity or individual, we may collect your personal data if it is relevant to our business relationship with you or in that entity. </p>  
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>The personal data we collect includes:</h6>
                            <ul>
                                <li>Personal particulars (e.g., name, contact details, date of birth, identity card/passport details) </li>
                                <li>Contact information (e.g., address, telephone numbers, email address, fax numbers)</li>
                                <li>Education details (e.g., names of schools and institutions, types of qualification) </li>
                                <li>Medical details (e.g., prior medical history) </li>
                                <li>Financial details (e.g., income, expenses, banking) </li>
                                <li>Employment details (e.g., employment history, salary, benefits, title, tenure)</li>
                                <li>Marital status and spousal information</li>
                            </ul>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>How We Collect Information </h6>
                            <p>We may collect personal data directly from you. We may sometimes collect information about you through third party when they are duly authorized by you to provide personal data from you. This may be done in person when you meet our staff or representatives, or over the phone, by email or through websites. </p>
                            <p>We may also collect your personal data about you from third party sources without directly involving you. For example, we may obtain your personal data from your family members or a government agency. We may also obtain your personal data from market research organizations or publicly available resources such as telephone directories or business directories.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>We are likely to collect personal data in the following situations:</h6>
                            <ul>
                                <li>When you apply for a job with us</li>
                                <li>When you enter a business relationship with us </li>
                                <li>When you provide any services to us </li>
                                <li>When you perform any duties in the course of employment with us</li>
                                <li>When you visit our web sites</li>
                                <li>When you contact us with feedback, queries or complaints </li>
                                <li>When you request us to send you information or notify you of developments in the company via post, emails or telephone calls.</li>
                            </ul>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Cookies </h6>
                            <p>A cookie is a text-only string of information that is transferred to the cookie file of the browser on your computer's hard disk so that we can recognize you as a repeat visitor.</p>
                            <p>A cookie will typically contain the name of the domain from which the cookie has come, the "lifetime" of the cookie, and a value, usually a randomly generated, unique number. Cookies are commonly used by most major websites to arrange their content to match your preferred interests.</p>
                            <p>This website will automatically gather personal information, such as your first name and email address, through the use of cookies when accessing enhanced and premium areas of the website.</p>
                            <p>Two types of cookies are used on this website:</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Session Cookies </h6>
                            <p>These are temporary cookies that remain in the cookie file of your browser until you leave the site. We use session cookies:</p>
                            <ul>
                                <li>To allow you to carry information across the pages of our site, thus avoiding the need for you to re-enter information.</li>
                                <li>To maintain your logged in status and to allow you to access secured, enhanced and premium service.</li>
                            </ul>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Persistent Cookies</h6>
                            <p>These remain in the cookie file of your browser for much longer. We use persistent cookies:</p>
                            <ul>
                                <li>To help us recognize you as a unique visitor when you return to our website.</li>
                                <li>To allow us to tailor language and regional content or advertisements to match your preferred interests.</li>
                                <li>To compile anonymous, aggregated statistics that allow us to understand how visitors use our site and to help us improve the structure of our website.</li>
                                <li>To ensure you are not invited to complete a research or other questionnaire too often or after you have already done so.</li>
                            </ul>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>How Do We Use Your Information</h6>
                            <p>The key purpose for which we need your personal data is to process your application or request, to proceed with any employment offers or business relationship with you or to contact you to provide any information to you pertaining to the Habitro. These include:</p>
                            <ul>
                                <li>Develop and manage a business relationship with you or your business partners, agents, employees and your customers.</li>
                                <li>Considering your applications for employment with us and for the purpose of administering a recruitment purpose.</li>
                                <li>To communicate with you to offer our products and services or to respond to your enquiries, complaints or clarifications.</li>
                                <li>Complying with our legal and regulatory obligations &amp; requirements.</li>
                                <li>Establishing, exercising or defending legal claims.</li>
                            </ul>
                            <p>We do not provide your personal data to third parties outside the Habitro for purposes other than those set out above or purposed related to those set out above. We do not sell your personal data to any third parties.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>When We Disclose Your Information?</h6>
                            <p>We may disclose and/or share your information under the following circumstances: </p>
                            <ul>
                                <li><strong>Service Providers:</strong> We may disclose your information with third parties who perform services on our behalf, including without limitation, event management, candidate selection, marketing, customer support, data storage, data analysis &amp; processing, and legal services.</li>
                                <li><strong>Legal Compliance and Protection:</strong> We may disclose your information if required to do so by law or on a good faith belief that such disclosure is permitted by this Privacy Policy or reasonably necessary or appropriate for any of the following reasons: (a) to comply with legal process; (b) to enforce or apply our Master Terms and this Privacy Policy, or other contracts with you, including investigation of potential violations thereof; (c) enforce our Charter including the Code of Conduct and policies contained and incorporated therein, (d) to respond to your requests for customer service; and/or (e) to protect the rights, property, or personal safety of Habitro, our agents and affiliates, our users, and the public. This includes exchanging information with other companies and organizations for fraud protection, and spam/malware prevention, and similar purposes.</li>
                                <li><strong>Affiliated Companies:</strong> We may disclose your information with current or future affiliated companies.</li>
                                <li><strong>Business Transfers:</strong> As we continue to develop our business, we may engage in certain business transactions, such as the transfer or sale of our assets. In such transactions, (including in contemplation of such transactions, e.g., due diligence) your information may be disclosed. If any of Habitro’ assets are sold or transferred to a third party, customer information (including your email address) would likely be one of the transferred business assets.</li>
                                <li><strong>Consent:</strong> We may disclose your information to any third parties based on your consent to do so. </li>
                                <li><strong>Aggregate/De-identified Information:</strong> We may disclose de-identified and/or aggregated data for any purpose to third parties, including advertisers, promotional partners, and/or others.</li>
                            </ul>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>International Transfers</h6>
                            <p>Your personal information may be stored and processed in any country where we have offices or servers or in which we engage service providers. Your personal information may be transferred to countries outside your country of residence, which may have different data protection and data processing laws than those in your country. Any such transfer shall take place only in accordance with and as permitted by the law of your jurisdiction, but please be aware that the laws and practices relating to the protection of personal information are likely to be different, and in some cases may be weaker than those within your home jurisdiction. Regardless, in all events, we shall apply the provisions of this Privacy Policy to your personal information wherever it is located.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Security Measures</h6>
                            <p>We have implemented technical, physical, and organizational security measures to protect against the loss, misuse, and/or alteration of your information. These safeguards vary based on the sensitivity of the information that we collect and store. However, we cannot and do not guarantee that these measures will prevent every unauthorized attempt to access, use, or disclose your information since despite our efforts, no Internet and/or other electronic transmissions can be completely secure.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Children's Privacy</h6>
                            <p>Habitro does not knowingly collect personal information or any other identifying data from children under 13 years of age. If we become aware that we have collected personal information (as defined by the Children’s Online Privacy Protection Act) from children under the age of 13, or personal data (as defined by the EU GDPR) from children under the age of 16, we will take reasonable steps to delete it as soon as practicable.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Data Retention</h6>
                            <p>We retain the information we collect for as long as necessary to fulfil the purposes set forth in this Privacy Policy or as long as we are legally required or permitted to do so. Information may persist in copies made for backup and business continuity purposes for additional time.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Third-Party Links and Services</h6>
                            <p>Habitro website may contain links to third-party websites, third-party plug-ins. If you choose to use these sites or features, you may disclose your information not just to those third-parties, but also to their users and the public more generally depending on how their services function. Habitro is not responsible for the content or privacy practices of such third party websites or services. The collection, use and disclosure of your information will be subject to the privacy policies of the third party websites or services, and not this Privacy Policy. We encourage you to read the privacy statements of each and every site you visit.</p>
                        </div>
                        <div class="temp15-item" data-aos="fade-up" data-aos-duration="1000">
                            <h6>Changes to this Privacy Policy </h6>
                            <p>We will continue to evaluate this Privacy Policy as we update and expand our business and services, and we may make changes to the Privacy Policy accordingly. We will post any changes here and revise the date last updated above. We encourage you to check this page periodically for updates to stay informed on how we collect, use and share your information. If we make material changes to this Privacy Policy, we will provide you with notice as required by law.</p>
                        </div>
                    </div>

                </div>
            </div>
        </section>

    </main>

    <footer data-aos="fade-up" data-aos-duration="1000">
       <?php include_once('footer.php');?>
    </footer>
    
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/common.js"></script>
    <script src="js/gsap.min.js"></script>
	<script src="js/ScrollTrigger.min.js"></script>
    <script src="js/smoother.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // register gsap scrollTrigger
            gsap.registerPlugin(ScrollTrigger, SplitText);


           (function() {
                const split1 = new SplitText('.temp15-head h1', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp15",
                        start: "top bottom",
                        once: true,
                    },

                })
                .from(split1.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

            })(); 

        });

    </script>
</body>
</html>
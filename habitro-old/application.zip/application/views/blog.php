<?php 


$BlogData=$this->myclass->select("blog_id,blog_slug,blog_title,blog_banner,blog_short_description,blog_content,blog_page_title,blog_sorting,blog_meta_keyword,blog_meta_description,blog_status,blog_updated_on",'blog',"blog_status='Yes' ORDER BY blog_sorting ");

$Next=$BlogData[0]->blog_sorting+1;
//$Previous=$BlogData[0]->blog_sorting-1;
$NextBlog_Data=$this->myclass->select("blog_id,blog_slug,blog_title,blog_banner,blog_short_description,blog_content,blog_page_title,blog_sorting,blog_meta_keyword,blog_meta_description,blog_status,blog_updated_on",'blog',"blog_status='Yes' AND blog_sorting=".$Next." LIMIT 1");
if($NextBlog_Data=='no')
{
    $Next=1;
    $NextBlog_Data=$this->myclass->select("blog_id,blog_slug,blog_title,blog_banner,blog_short_description,blog_content,blog_page_title,blog_sorting,blog_meta_keyword,blog_meta_description,blog_status,blog_updated_on",'blog',"blog_status='Yes' AND blog_sorting=".$Next." LIMIT 1");
}

$blog_slug=str_replace(" ","-",$NextBlog_Data[0]->blog_slug);
// echo $projectName;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0"/>
   <title><?php echo $BlogData[0]->blog_page_title;?></title>
    <meta name="keywords" content="<?php echo $BlogData[0]->blog_meta_keyword;?>" />
    <meta name="description" content="<?php echo $BlogData[0]->blog_meta_description;?>" />
    <meta property="og:title" content="<?php echo $BlogData[0]->blog_page_title;?>" />
    <meta property="og:description" content="<?php echo $BlogData[0]->blog_meta_description;?>" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="img/favicon/android-icon-192x192.png" />
    <meta name="twitter:title" content="<?php echo $BlogData[0]->blog_page_title;?>"/>
    <meta name="twitter:description" content="<?php echo $BlogData[0]->blog_meta_description;?>"/>
    <meta name="twitter:image" content="img/favicon/android-icon-192x192.png"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <meta name="msapplication-TileColor" content="#FAFAFA">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#FAFAFA">
    <link rel="stylesheet" href="<?php echo base_url().'css/aos.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'css/style.css'?>">
</head>
<body>
    <header>
         <?php include_once('header.php');?>
    </header>

    <main>
        <section class="topSection">
            <div class="temp13">
                <div class="container">
                    <div class="temp13-inner">
                        <div class="temp13-top">
                            <a href="<?php echo base_url()."blog";?>" class="back-blog" data-aos="fade-up-left" data-aos-duration="1000">
                                <img src="<?php echo base_url();?>img/next.svg" alt="back">
                            </a>
                            <a href="#" class="share-blog" data-aos="fade-up-right" data-aos-duration="1000">
                                <img src="<?php echo base_url();?>img/share.svg" alt="share">
                            </a>
                        </div>

                        <div class="temp13-main">
                            <div class="temp13-banner">
                                <figure>
                                    <img src="<?php echo base_url()."img/".$BlogData[0]->blog_banner;?>" alt="" data-aos="fade-up" data-aos-duration="1000">
                                </figure>
                            </div>
                            <div class="temp13-txt">
                                <div class="temp13-opt1" data-aos="fade-up" data-aos-duration="1000">
                                    <h6 class="temp13-date"><?php echo date('l d M H:s a',strtotime($BlogData[0]->blog_updated_on));?></h6>
                                    <h1><?php echo $BlogData[0]->blog_title;?></h1>
                                    <p><?php echo $BlogData[0]->blog_short_description;?></p>
                                </div>
                                <div class="temp13-opt2" data-aos="fade-up" data-aos-duration="1000">
                                   <?php echo $BlogData[0]->blog_content;?>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>

        <section class="mb0">
            <div class="temp9">
                <div class="temp9-inner">
                    <div class="temp9-top" data-aos="fade-up" data-aos-duration="1000">
                        <a href="<?php echo base_url()."blogs/".$blog_slug ?>" class="btn-sml">
                            NEXT BLOG
                            <span><img src="<?php echo base_url();?>img/next.svg" alt="next"></span>
                        </a>
                    </div>
                    <div class="temp9-link">
                        <div class="temp9-marquee">
                            <a href="<?php echo base_url()."blogs/".$blog_slug ?>"><?php echo $NextBlog_Data[0]->blog_title;?></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer data-aos="fade-up" data-aos-duration="1000">
         <?php include_once('footer.php');?>
    </footer>
         
    <script src="<?php echo base_url().'js/jquery-3.6.0.min.js'?>"></script>
    <script src="<?php echo base_url().'js/aos.js'?>"></script>
    <script src="<?php echo base_url().'js/common.js'?>"></script>
    <script src="<?php echo base_url().'js/gsap.min.js'?>"></script>
    <script src="<?php echo base_url().'js/jquery.marquee.min.js'?>"></script>
    <script src="<?php echo base_url().'js/ScrollTrigger.min.js'?>"></script>
    <script src="<?php echo base_url().'js/smoother.js'?>"></script>
    <script>
        $(document).ready(function () {

            /*  marquee js  */
            if ($(window).width() >= 1025) {
                var temp9Marquee = $('.temp9-marquee').marquee({
                    speed: 200,
                    gap: 100,
                   // delayBeforeStart: 2100,
                    direction: 'left',
                    duplicated: true,
                    pauseOnHover: false,
                    startVisible: true,
                    duration: 10000,
                });
                temp9Marquee.marquee('pause');
                $('.temp9-marquee').mouseover(function(){
                    temp9Marquee.marquee('resume');
                });
                $('.temp9-marquee').mouseleave(function(){
                    temp9Marquee.marquee('pause');
                });
            } else {
                var temp9Marquee = $('.temp9-marquee').marquee({
                    speed: 100,
                    gap: 100,
                   // delayBeforeStart: 2100,
                    direction: 'left',
                    duplicated: true,
                    pauseOnHover: false,
                    startVisible: true,
                    duration: 10000,
                });
            }

        });


        document.addEventListener("DOMContentLoaded", function () {
            // register gsap scrollTrigger
            gsap.registerPlugin(ScrollTrigger, SplitText);


           /*  (function() {
                const split1 = new SplitText('.temp13-txt h1', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp13-opt1",
                        start: "top bottom",
                        once: true,
                    },

                })
                .from(split1.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

            })(); */


            /* (function() {
                const split2 = new SplitText('.temp13-opt2 h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp13-opt2",
                        start: "top bottom",
                        once: true,
                    },

                })
                .from(split2.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

            })();
            (function() {
                const split4 = new SplitText('.temp13-opt3 h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp13-opt3",
                        start: "top bottom",
                        once: true,
                    },

                })
                .from(split4.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

            })(); */


            (function() {
                const split3 = new SplitText('.temp9-marquee a', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp9-marquee",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split3.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split3Done() { split3.revert() }
            })();


        });


    </script>
</body>
</html>
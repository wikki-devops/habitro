  <?php 
    $ContactData=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on",'home',"home_page='Contact'");
    ?>
 <div class="container">
            <div class="fTop">
                <div class="fTop-left">
                    <div class="fTopL-left">
                        <p><?php echo $ContactData[3]->home_content;?></p>
                        <a href="#" target="_blank">
                            <img src="<?php echo base_url();?>img/instagram-white.svg" alt="instagram">
                        </a>
                    </div>
                    <div class="fTopL-right">
                        <ul>
                            <li><a href="<?php echo base_url();?>">HOME</a></li>
                            <li><a href="<?php echo base_url();?>project">PROJECT</a></li>
                            <li><a href="<?php echo base_url()."about-us";?>">ABOUT US</a></li>
                            <li><a href="<?php echo base_url()."blog";?>">BLOG</a></li>
                            <li><a href="<?php echo base_url()."contact";?>">CONTACT</a></li>
                        </ul>
                    </div>
                </div>
                <div class="fTop-right">
                    <a href="tel:+<?php echo $ContactData[2]->home_content;?>"><?php echo $ContactData[2]->home_content;?></a>
                </div>
            </div>

            <div class="fBtm">
                <div class="fBtm-img">
                    <div class="fLogo">
                        Habitro<span>.com</span>
                    </div>
                </div>
                <div class="fBtm-copy">
                    <ul>
                        <li>2022 © HABITRO</li>
                        <li><a href="<?php echo base_url()."legal-information";?>">LEGAL INFORMATION</a></li>
                        <li>EST.2007</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="fBtm-webBy">
            <div class="container">
                <p>WEBSITE BY <a href="https://dribbble.com/bhumikparmar" target="_blank">BHUMIK PARMAR</a></p>
            </div>
        </div>
        <img src="<?php echo base_url();?>img/plant.png" alt="" class="fBtm-plant">
    
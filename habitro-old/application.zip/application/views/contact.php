  <?php 
  $ContactData=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on",'home',"home_page='Contact'");
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0"/>
      <title>Habitro | Contact Us</title>
    <meta name="keywords" content="Habitro" />
    <meta name="description" content="Habitro" />
    <meta property="og:title" content="Habitro" />
    <meta property="og:description" content="Habitro" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="img/favicon/android-icon-192x192.png" />
    <meta name="twitter:title" content="Habitro"/>
    <meta name="twitter:description" content="Habitro"/>
    <meta name="twitter:image" content="img/favicon/android-icon-192x192.png"/>
    <meta name="twitter:image" content="img/favicon/android-icon-192x192.png"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <meta name="msapplication-TileColor" content="#FAFAFA">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#FAFAFA">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
         <?php include_once('header.php');?>
    </header>

    <main>
        <section class="topSection">
            <div class="temp14">
                <div class="container">
                    <div class="temp14-inner">
                        <div class="temp14-h2">
                            <h2>CONTACT <?php echo $ContactData[0]->home_content;?></h2>
                        </div>
                        <div class="temp14-link" data-aos="fade-down" data-aos-duration="1000" data-aos-delay="150">
                            <a href="mailto:<?php echo $ContactData[1]->home_content;?>" target="_blank"><?php echo $ContactData[1]->home_content;?></a>
                            <a href="tel:<?php echo $ContactData[2]->home_content;?>" target="_blank"><?php echo $ContactData[2]->home_content;?></a>
                            <a href="#"><?php echo $ContactData[3]->home_content;?></a>
                        </div>
                        <div class="temp14-h2-2">
                            <h2>FOR PROJECT ENQUIRIES</h2>
                        </div>
                    </div>
                </div>
                <div class="temp14-insta" data-aos="fade-up-right" data-aos-duration="1000">
                    <span class="temp14-label">FOLLOW US</span>
                    <a href="#" target="_blank"><img src="<?php echo base_url().'img/instagram-purple.svg';?>" alt="Habitro instagram"></a>
                </div>
            </div>
        </section>

    </main>

    <footer data-aos="fade-up" data-aos-duration="1000">
        <?php include_once('footer.php');?>
    </footer>
    
    <script src="<?php echo base_url().'js/jquery-3.6.0.min.js';?>"></script>
    <script src="<?php echo base_url().'js/aos.js';?>"></script>
    <script src="<?php echo base_url().'js/common.js';?>"></script>
    <script src="<?php echo base_url().'js/gsap.min.js';?>"></script>
	<script src="<?php echo base_url().'js/ScrollTrigger.min.js';?>"></script>
    <script src="<?php echo base_url().'js/smoother.js';?>"></script>
    <script>

        document.addEventListener("DOMContentLoaded", function () {
            // register gsap scrollTrigger
            gsap.registerPlugin(ScrollTrigger, SplitText);


            (function() {
                const split1 = new SplitText('.temp14-h2 h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp14-h2",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split1.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split1Done() { split1.revert() }
            })();


            (function() {
                const split1 = new SplitText('.temp14-h2-2 h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp14-h2-2",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split1.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 1,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split1Done() { split1.revert() }
            })();

     



        });


    </script>
</body>
</html>
<?php 
$homeData=$this->myclass->select("home_id,home_content_heading,home_content,home_content_type,home_updated_on",'home',"home_page='Home'");
// echo "<pre>";
// print_r($homeData);
// echo "</pre>";

?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0"/>
    <title><?php echo $homeData[15]->home_content;?> </title>
    <meta name="keywords" content="<?php echo $homeData[17]->home_content;?>" />
    <meta name="description" content="<?php echo $homeData[16]->home_content;?>" />
    <meta property="og:title" content="<?php echo $homeData[15]->home_content;?> " />
    <meta property="og:description" content="<?php echo $homeData[16]->home_content;?>" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="img/favicon/android-icon-192x192.png" />
    <meta name="twitter:title" content="<?php echo $homeData[16]->home_content;?>"/>
    <meta name="twitter:description" content="<?php echo $homeData[16]->home_content;?>"/>
    <meta name="twitter:image" content="img/favicon/android-icon-192x192.png"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <meta name="msapplication-TileColor" content="#FAFAFA">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#FAFAFA">
    <link rel="stylesheet" href="css/swiper-bundle.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>   
    <header>
        <a href="<?php echo base_url();?>" class="habitroLogo">
            <figure><img src="img/habitro-logo-lg.png" alt="Habitro logo"></figure>
        </a>
        <!-- <a href="index.html" class="habitroLogo" data-aos="fade-down" data-aos-duration="1000">
            <figure><img src="img/habitro-logo.png" alt="Habitro logo"></figure>
        </a> -->
        <nav data-aos="fade-down" data-aos-duration="1000">
            <ul>
                <li>
                    <a href="#home" data-scroll-nav="0" class="roll-link">
                        <span data-title="HOME">HOME</span>
                    </a>
                </li>
                <li>
                    <a href="#project" data-scroll-nav="1" class="roll-link">
                        <span data-title="PROJECT">PROJECT</span>
                    </a>
                </li>
                <li>
                    <a href="#about-us" data-scroll-nav="2" class="roll-link">
                        <span data-title="ABOUT US">ABOUT US</span>
                    </a>
                </li>
                <li>
                    <a href="#blog" data-scroll-nav="3" class="roll-link">
                        <span data-title="BLOG">BLOG</span>
                    </a>
                </li>
                <li>
                    <a href="#contact" data-scroll-nav="4" class="roll-link">
                        <span data-title="CONTACT">CONTACT</span>
                    </a>
                </li>
            </ul>
        </nav>
        <div class="navToggle" data-aos="fade-down" data-aos-duration="1000">
            <span></span>
            <span></span>
        </div>
        <div class="navArea">
            <ul class="navList">
                <li>
                    <a href="<?php echo base_url();?>" class="roll-link activebNav">
                        <span data-title="HOME">HOME</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>project" class="roll-link">
                        <span data-title="PROJECT">PROJECT</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."about-us";?>" class="roll-link">
                        <span data-title="ABOUT US">ABOUT US</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."blog";?>" class="roll-link">
                        <span data-title="BLOG">BLOG</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url()."contact";?>" class="roll-link">
                        <span data-title="CONTACT">CONTACT</span>
                    </a>
                </li>
            </ul>
        </div>
        <figure class="navFrame"><img src="img/menu-frame.svg" alt="frame"></figure>
        <div class="navOverlay"></div>
    </header>

    <main>
        <div class="habitroLogoLg"></div>
        <section class="topSection" id="home" data-scroll-index="0">
            <div class="temp1">
                <picture class="temp1-img" data-aos="zoom-out" data-aos-duration="1000">
                    <source srcset="<?php echo base_url()."img/".$homeData[0]->home_content;?>" media="(min-width: 650px)">
                    <source srcset="<?php echo base_url()."img/".$homeData[1]->home_content;?>" media="(min-width: 300px)">
                    <img src="<?php echo base_url()."img/".$homeData[0]->home_content;?>" alt="Its a peanut thing">
                </picture>
                <div class="container">
                    <div class="temp1-txt">
                        <p class="temp1-label" data-aos="fade-up" data-aos-duration="1000">KNOW MORE ABOUT US</p>
                        <h1 class="smlHead"><?php echo $homeData[2]->home_content;?></h1>
                    </div>
                </div>
            </div>
        </section>

        <section id="project" data-scroll-index="1">
            <div class="temp2">
                <div class="container">
                    <div class="temp2-head">
                        <h3 class="txtGreen"><?php echo $homeData[3]->home_content;?></h3>
                    </div>
                </div>
                <div class="temp2-wrap">
                    
                    <div class="temp2-slider">
                        <div class="swiper temp2Slider">
                            <div class="swiper-wrapper">
                                <?php 
$ProjectData=$this->myclass->select("project_id,project_name,project_banner,project_banner_text,project_description,project_homepage,project_sorting,project_slug",'project',"project_status='Yes' order by project_sorting");
                                if(isset($ProjectData) && is_array($ProjectData))
                                {
                                    foreach($ProjectData as $val)
                                    {
                                        $project_slug=str_replace(" ","-",$val->project_slug);
                                        ?>
                                        
                                <div class="temp2-sItem swiper-slide">
                                    <div class="temp2-sLeft">
                                        <h2><?php echo $val->project_name; ?></h2>
                                    </div>
                                    <div class="temp2-sRight">
                                        <figure class="temp2-sImg" data-aos="zoom-out" data-aos-duration="1000">
                                            <picture>
                                                <source srcset="<?php echo base_url()."img/".$val->project_banner;?>" media="(min-width: 650px)">
                                                <source srcset="<?php echo base_url()."img/".$val->project_banner;?>" media="(min-width: 300px)">
                                                <img src="<?php echo base_url()."img/".$val->project_banner;?>" alt="YOGA STUDIO WITH HAMMOCKS">
                                            </picture>
                                            <figcaption class="temp2-siTxt">
                                                <p><?php echo $val->project_banner_text; ?></p>
                                                <p><a href="<?php echo base_url()."projects/".$project_slug ?>" class="btn-whiteSml"><span>View Detail</span><img src="img/next.svg" alt="View"></a></p>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                                <?php
                                    }
                                }
                                ?>
                              
                            </div>
                            <div class="swiper-button-next">
                                <svg xmlns="http://www.w3.org/2000/svg" width="39.165" height="16.356" viewBox="0 0 39.165 16.356"><path d="M33.8,14.407H6.482a2.482,2.482,0,0,0,0,4.963H33.8v4.442a1.228,1.228,0,0,0,2.109.869l6.9-6.924a1.274,1.274,0,0,0,0-1.762l-6.9-6.924A1.233,1.233,0,0,0,33.8,9.94Z" transform="translate(-4 -8.701)" fill="#fafafa"/></svg>
                            </div>
                            <div class="swiper-button-prev">
                                <svg xmlns="http://www.w3.org/2000/svg" width="39.165" height="16.356" viewBox="0 0 39.165 16.356"><path d="M33.8,14.407H6.482a2.482,2.482,0,0,0,0,4.963H33.8v4.442a1.228,1.228,0,0,0,2.109.869l6.9-6.924a1.274,1.274,0,0,0,0-1.762l-6.9-6.924A1.233,1.233,0,0,0,33.8,9.94Z" transform="translate(-4 -8.701)" fill="#fafafa"/></svg>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <?php 
                    $project_slug=str_replace(" ","-",$ProjectData[0]->project_slug);

                    ?>
                    <div class="temp2-link" data-aos="fade-up" data-aos-duration="800">
                        <a href="<?php echo base_url()."projects/".$project_slug ?>" class="btn-large">
                            View all projects 
                            <span><img src="img/next.svg" alt="view"></span>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="temp3">
                <div class="container">
                    <div class="temp3-inner" data-aos="fade-up" data-aos-duration="1000">
                        <div class="temp3-beforeLabel">Before</div>
                        <div class="temp3-revealSlider">
                            <div class="revealSlider">
                                <img src="<?php echo base_url()."img/".$homeData[20]->home_content;?>" alt="Before">
                                <div class="img-reveal">
                                    <img src="<?php echo base_url()."img/".$homeData[19]->home_content;?>" alt="after">
                                </div>
                            </div>
                        </div>
                        <div class="temp3-afterLabel">After</div>
                    </div>
                </div>
            </div>
        </section>

        <section id="about-us" data-scroll-index="2">
            <div class="temp4">
                <div class="container">
                    <div class="temp4-inner">
                        <h2><?php echo $homeData[4]->home_content;?></h2>
                        <!-- <h2 data-aos="fade-up" data-aos-duration="1000">Bridging <br>the gap between timeless interior <br>design & Traditional craftmenship.</h2> -->
                        <div class="temp4-link" data-aos="fade-up" data-aos-duration="1000">
                            <a href="<?php echo base_url()."about-us";?>" class="btn-large">
                                ABOUT US
                                <span><img src="img/next.svg" alt="about us"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="temp5">
                <div class="temp5-img1"><img src="<?php echo base_url()."img/".$homeData[5]->home_content;?>" alt="" data-aos="zoom-in-left" data-aos-duration="1000"></div>
                <div class="temp5-img2"><img src="<?php echo base_url()."img/".$homeData[6]->home_content;?>" alt="" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="100"></div>
                <div class="temp5-img3"><img src="<?php echo base_url()."img/".$homeData[7]->home_content;?>" alt="" data-aos="zoom-in-right" data-aos-duration="1000"></div>
                <div class="temp5-img4"><img src="<?php echo base_url()."img/".$homeData[8]->home_content;?>" alt="" data-aos="zoom-in-left" data-aos-duration="1000"></div>
                <div class="temp5-img5"><img src="<?php echo base_url()."img/".$homeData[9]->home_content;?>" alt="" data-aos="zoom-in-left" data-aos-duration="1000"></div>
                <div class="temp5-img6"><img src="<?php echo base_url()."img/".$homeData[10]->home_content;?>" alt="" data-aos="zoom-in-right" data-aos-duration="1000"></div>
                <div class="temp5-img7"><img src="<?php echo base_url()."img/".$homeData[11]->home_content;?>" alt="" data-aos="fade-up" data-aos-duration="1000"></div>
                <div class="temp5-img8"><img src="<?php echo base_url()."img/".$homeData[12]->home_content;?>" alt="" data-aos="fade-up" data-aos-duration="1000"></div>
                <div class="temp5-txt">
                    <div class="container">
                        <!-- <div class="temp5-txtInner" data-aos="zoom-in" data-aos-duration="1000">
                            <h2>SURROUND YOURSELF WITH LOVE</h2>
                        </div> -->
                        <div class="temp5-txtInner">
                            <h2><?php echo $homeData[13]->home_content;?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="temp11">
                <div class="container">
                    <div class="temp11-inner">
                        <ul>
                                                            <?php 
$ServicesData=$this->myclass->select("services_id,services_name,services_description,services_icon,services_sorting",'services',"services_status='Yes' order by services_sorting");
                                if(isset($ServicesData) && is_array($ServicesData))
                                {
                                    foreach($ServicesData as $val)
                                    {
                                        ?>
                            <li data-aos="fade-up" data-aos-duration="1000">
                                <figure><img src="<?php echo base_url()."img/".$val->services_icon;?>" alt="<?php echo $val->services_name;?>"></figure>
                                <h3><?php echo $val->services_name;?></h3>
                                <p><?php echo $val->services_description;?></p>
                            </li>
                            <?php 

                                    }
                                }
                            ?>
                         
                        </ul>
                    </div>
                </div>
            </div>
        </section>
  <?php 
$BlogData=$this->myclass->select("blog_id,blog_slug,blog_title,blog_banner,blog_short_description,blog_content,blog_sorting,blog_status,blog_updated_on",'blog',"blog_status='Yes' order by blog_sorting LIMIT 4");
                                if(isset($BlogData) && is_array($BlogData))
                                {
                                        
                                    $blog_slug=str_replace(" ","-",$BlogData[0]->blog_slug);
                                    $blog_slug1=str_replace(" ","-",$BlogData[1]->blog_slug);
                                    $blog_slug2=str_replace(" ","-",$BlogData[2]->blog_slug);
                                    $blog_slug3=str_replace(" ","-",$BlogData[3]->blog_slug);
                                   
                                        ?>
        <section id="blog" data-scroll-index="3">
            <div class="temp6">
                <div class="container">
                    <div class="temp6-head">
                        <h2>THE BLOG</h2>
                    </div>
                    <!-- <div class="temp6-head" data-aos="fade-up" data-aos-duration="1000">
                        <h2>THE BLOG</h2>
                    </div> -->
                    <div class="temp6-left" data-aos="fade-up-right" data-aos-duration="1000">
                        <div class="temp6-bItem">
                            <a href="<?php echo base_url()."blogs/".$blog_slug;?>">
                                <figure class="temp6-img">

                                    <img src="<?php echo base_url()."img/".$BlogData[0]->blog_banner;?>" alt="">
                                </figure>
                                <div class="temp6-lTxt">
                                    <p class="temp6-date"><?php echo date('l d M H:s a',strtotime($BlogData[0]->blog_updated_on));?></p>
                                    <h4><?php echo $BlogData[0]->blog_title;?></h4>
                                    <p class="temp6-desc"><?php echo $BlogData[0]->blog_short_description;?></p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="temp6-right">
                        <div class="temp6-rbList">
                            <ul>
                                <li data-aos="fade-up-left" data-aos-duration="1000">
                                    <div class="temp6-bItem">
                                        <a href="<?php echo base_url()."blogs/".$blog_slug1;?>">
                                            <figure class="temp6-img">
                                                <img src="<?php echo base_url()."img/".$BlogData[1]->blog_banner;?>" alt="">
                                            </figure>
                                            <div class="temp6-lTxt">
                                                <p class="temp6-date"><?php echo date('l d M H:s a',strtotime($BlogData[1]->blog_updated_on));?></p>
                                                <h4><?php echo $BlogData[1]->blog_title;?></h4>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                                <li data-aos="fade-up-left" data-aos-duration="1000">
                                    <div class="temp6-bItem">
                                        <a href="<?php echo base_url()."blogs/".$blog_slug2;?>">
                                            <figure class="temp6-img">
                                                <img src="<?php echo base_url()."img/".$BlogData[2]->blog_banner;?>" alt="">
                                            </figure>
                                            <div class="temp6-lTxt">
                                                <p class="temp6-date"><?php echo date('l d M H:s a',strtotime($BlogData[2]->blog_updated_on));?></p>
                                                <h4><?php echo $BlogData[2]->blog_title;?></h4>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                                <li data-aos="fade-up-left" data-aos-duration="1000">
                                    <div class="temp6-bItem">
                                        <a href="<?php echo base_url()."blogs/".$blog_slug3;?>">
                                            <figure class="temp6-img">
                                                <img src="<?php echo base_url()."img/".$BlogData[3]->blog_banner;?>" alt="">
                                            </figure>
                                            <div class="temp6-lTxt">
                                                <p class="temp6-date"><?php echo date('l d M H:s a',strtotime($BlogData[3]->blog_updated_on));?></p>
                                                <h4><?php echo $BlogData[3]->blog_title;?></h4>
                                            </div>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>

                        <div class="temp6-link" data-aos="fade-up-left" data-aos-duration="1000">
                            <a href="<?php echo base_url()."blogs/".$blog_slug ?>" class="btn-large">
                                READ MORE
                                <span><img src="img/next.svg" alt="Blog"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php 
    }
        ?>

        <section class="mb0">
            <div class="temp7">
                <div class="container">
                    <div class="temp7-inner">
                        <div class="temp7-head">
                            <h2><?php echo $homeData[14]->home_content;?></h2>
                        </div>
                       
                        
                        <div class="temp7-img1" data-aos="fade-up-right" data-aos-duration="1000"><img src="<?php echo base_url()."img/".$homeData[22]->home_content;?>" alt=""></div>
                        <div class="temp7-img2Wrap">
                            <div class="temp7-img2" data-aos="fade-up" data-aos-duration="1000">
                                <figure>
                                    <img src="<?php echo base_url()."img/".$homeData[21]->home_content;?>" class="temp7-img2Lg" alt="">
                                    <figcaption class="temp7-img2Link">
                                        <a href="<?php echo base_url()."projects/".$project_slug ?>">
                                            <img src="<?php echo base_url()."img/next-green.svg"?>" alt="project">
                                        </a>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                        <div class="temp7-img3" data-aos="fade-up-left" data-aos-duration="1000"><img src="<?php echo base_url()."img/".$homeData[23]->home_content;?>" alt=""></div>
                    </div>
                </div>
            </div>
        </section>
    </main>
   

    <footer data-aos="fade-up" data-aos-duration="1000" id="contact" data-scroll-index="4">
       <?php include_once('footer.php');?>
    </footer>
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/revealslider.js"></script>
    <script src="js/swiper-bundle.min.js"></script>
    <script src="js/common.js"></script>
    <script src="js/gsap.min.js"></script>
    <script src="js/scrollIt.min.js"></script>
	<script src="js/ScrollTrigger.min.js"></script>
    <script src="js/smoother.js"></script>
    <script>
    $(document).ready(function () {

        $.scrollIt({
            upKey: 38,             
            downKey: 40,           
            easing: 'linear',      
            scrollTime: 600,       
            activeClass: 'activeNav', 
            onPageChange: null,   
            topOffset: 0,
        });

        /* Initialize Swiper */
        var swiper = new Swiper(".temp2Slider", {
            effect: "fade",
            pagination: {
                el: ".swiper-pagination",
                type: "fraction",
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });

        /* Reveal slider js */
        $.fn.BeerSlider = function (options) {
            options = options || {};
            return this.each(function () {
                new BeerSlider(this, options);
            });
        };
        $('.revealSlider').BeerSlider();

    });


    document.addEventListener("DOMContentLoaded", function () {
        // register gsap scrollTrigger
        gsap.registerPlugin(ScrollTrigger, SplitText);



            (function() {
                //ScrollTrigger.saveStyles(".temp1-txt");
                const split1 = new SplitText('.temp1-txt h1', { type: 'words, lines' });
                //TweenLite.set('.temp1-txt h1', { perspective: 400 });

                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp1-txt",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split1.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split1Done() { split1.revert() }
            })();


            (function() {
                const split2 = new SplitText('.temp2-sLeft h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp2-sLeft",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split2.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split2Done() { split2.revert() }
            })();


            (function() {
                const split3 = new SplitText('.temp4-inner h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp4-inner",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split3.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split3Done() { split3.revert() }
            })();


            (function() {
                const split4 = new SplitText('.temp5-txtInner h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp5-txtInner",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split4.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split4Done() { split4.revert() }
            })();


            (function() {
                const split5 = new SplitText('.temp6-head h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp6-head",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split5.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split5Done() { split5.revert() }
            })();


            (function() {
                const split6 = new SplitText('.temp7-head h2', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp7-head",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split6.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split6Done() { split6.revert() }
            })();


            (function() {
                const split7 = new SplitText('.temp2-head h3', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp2-head",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split7.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split7Done() { split7.revert() }
            })();


            (function() {
                const split8 = new SplitText('.temp3-beforeLabel', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp3-beforeLabel",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split8.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split8Done() { split8.revert() }
            })();


            (function() {
                const split9 = new SplitText('.temp3-afterLabel', { type: 'words, lines' });
                gsap.timeline({
                    scrollTrigger: {
                        trigger: ".temp3-afterLabel",
                        start: "top bottom",
                        once: true,
                        /* markers: true */
                    },

                })
                .from(split9.words, 1, {
                    opacity: 0,
                    force3D: true,
                    transformOrigin: '50% 50% 50%',
                    duration: .1,
                    delay: 0,
                    y: 100,
                    skewY: 7,
                    stagger: 0.08,
                    ease: "power2",
                }, 0.4);

                //function split9Done() { split9.revert() }
            })();


ScrollTrigger.matchMedia({
	
	// desktop
	"(min-width: 1001px)": function() {
        let habitroLogo = gsap.timeline({
            scrollTrigger: {
                // markers: true,
                trigger: ".habitroLogoLg",
                start: "top top",
                end: "bottom top",
                scrub: 1,
                //once: true,
                toggleActions: "play pause none none",
                onEnterBack: ({progress, direction, isActive}) => {
                console.log(progress, direction, isActive);
                },
                onLeave: ({progress, direction, isActive}) => {
                console.log(progress, direction, isActive);
                },
                invalidateOnRefresh: true,
            }
        });

        habitroLogo.addLabel("start")
            .fromTo(".habitroLogo", { scale: 4, left:"50%", xPercent:-50, transformOrigin: '50% 50%' }, { duration: 0.1, scale: 1, left:"2.5%", xPercent: 0,}, 0.0 )
            .addLabel("logoShrunkDown")
            .to(".habitroLogoLg", { duration: 0.9, height: 0 }, 0.1 )
            .fromTo(".habitroLogo", { yPercent: 300, transformOrigin: '50% 50% 50%'}, { duration: 0.9, yPercent: 0 }, 0.1 )
            .addLabel("logoFixedAndVideoVisible");
    }, 
  
	// mobile
	"(max-width: 1000px)": function() {
        let habitroLogo = gsap.timeline({
            scrollTrigger: {
                // markers: true,
                trigger: ".habitroLogoLg",
                start: "top top",
                end: "bottom top",
                scrub: 1,
                //once: true,
                toggleActions: "play pause none none",
                onEnterBack: ({progress, direction, isActive}) => {
                console.log(progress, direction, isActive);
                },
                onLeave: ({progress, direction, isActive}) => {
                console.log(progress, direction, isActive);
                },
                invalidateOnRefresh: true,
            }
        });

        habitroLogo.addLabel("start")
            .fromTo(".habitroLogo", { scale: 2, left:"50%", xPercent:-50, transformOrigin: '50% 50%' }, { duration: 0.1, scale: 1, left:"8%", xPercent: 0,}, 0.0 )
            .addLabel("logoShrunkDown")
            .to(".habitroLogoLg", { duration: 0.9, height: 0 }, 0.1 )
            .fromTo(".habitroLogo", { yPercent: 300, transformOrigin: '50% 50% 50%'}, { duration: 0.9, yPercent: 0 }, 0.1 )
            .addLabel("logoFixedAndVideoVisible");

    }
  
  
});








            




    });

    </script>
</body>
</html>
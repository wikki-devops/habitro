<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {
	
     public function __construct()
    {
        parent::__construct();
    }
	public function get_product()
    {
        
        $this->db->select('*');
        $this->db->from('product');
        $this->db->join('brand', 'product.brand_id=brand.brand_id');
        $this->db->where('product.brand_id',$brand);
        $query = $this->db->get();

        return $query->result();
    }

    function insert($table,$data)
    {
        $this->db->insert($table,$data);
        $ans=$this->db->insert_id();    
        return $ans;
    }
    
    function update_record($id,$table,$edit_data,$field)
    {
        $this->db->where($field,$id);
        $this->db->update($table,$edit_data);
        // return $this->db->last_query();
    }
    
    function delete_record($delete_id,$field,$table)
    {
        $this->db->where($field,$delete_id);
        $this->db->delete($table); 
    }
    function get_select_record($fields,$table)
    {
        $this->db->select($fields);
        $record = $this->db->get($table);
            return  $record->result();
    }

}
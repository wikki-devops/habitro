document.addEventListener("DOMContentLoaded", function () {
  // register gsap scrollTrigger
  gsap.registerPlugin(ScrollTrigger);

  // gsap settings:
  let animDuration = 0.6;
  let animDelay = 0.2;
  let animEasing = "cubic-bezier(0.65, 0, 0.35, 1)";

  const fadeUp = {
    duration: animDuration,
    autoAlpha: 0,
    y: 100,
    ease: "power2",
  };

  // aos settings
  // setTimeout(() => {
  //   AOS.init({
  //     disable: function () {
  //       var maxWidth = 1023;
  //       return window.innerWidth < maxWidth;
  //     },
  //     once: true,
  //     offset: -50,
  //     duration: 600,
  //     anchorPlacement: "top-bottom",
  //   });
  // }, 0);

  // tabs
  $(".tabs-wrapper").each(function () {
    let ths = $(this);
    ths.find(".tab-item").not(":first").hide();
    ths
      .find(".tab")
      .click(function () {
        ths
          .find(".tab")
          .removeClass("active")
          .eq($(this).index())
          .addClass("active");
        ths.find(".tab-item").hide().eq($(this).index()).fadeIn();
        ths
          .find(".tab-item")
          .removeClass("active")
          .eq($(this).index())
          .addClass("active");
      })
      .eq(0)
      .addClass("active");
  });

  // HOME PAGE - start
  if (document.querySelector("main").classList.contains("main-home")) {
    // Hero section marquee
    (function () {
      const marqueeParams = {
        duplicated: true,
        duration: 7000,
        gap: 100,
        startVisible: true,
        delayBeforeStart: 0,
      };

      if ($(window).width() < 580) {
        marqueeParams.duration = 2000;
        marqueeParams.gap = 0;
        marqueeParams.duplicated = false;
      }

      let $mq = $(".marquee-hero").marquee(marqueeParams);

      $mq.marquee("pause");

      function resumeMarquee() {
        if ($(this).scrollTop() > 200) {
          $mq.marquee("resume");
        }
      }
      resumeMarquee();
      $(window).scroll(resumeMarquee);
    })();

    // welcome section - slider
    $(".section-welcome .slider").slick({
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
    });

    // brands carousel
    $(".section-leader .brands__carousel").slick({
      dots: true,
      infinite: false,
      speed: 300,
      slidesToShow: 2,
      slidesToScroll: 2,
      slidesPerRow: 10,
      rows: 2,
      arrows: false,
      responsive: [
        {
          breakpoint: 769,
          settings: {
            slidesPerRow: 2,
          },
        },
        {
          breakpoint: 580,
          settings: {
            slidesPerRow: 1,
          },
        },
      ],
    });

    // play video by scroll
    $(window).on("scroll", function () {
      const $target = $(".block-video__video video");
      let $targetOffset = $target.offset().top,
        $targetHeight = $target.outerHeight(),
        $windowHeight = $(window).height(),
        $windowOffset = $(this).scrollTop();
      if ($windowOffset > $targetOffset + $targetHeight - $windowHeight - 100) {
        $(".block-video__video").addClass("play");
        $target[0].play();
        $target[0].controls = true;
        $(window).off("scroll");
      }
      // else {
      //   $target[0].currentTime = 0;
      //   $target[0].load();
      // }
    });

    // Player
    (function () {
      const player = new Plyr("#player", {
        controls: [
          "play",
          "progress",
          "current-time",
          "mute",
          "volume",
          "captions",
          "settings",
          "pip",
          "airplay",
          "fullscreen",
        ],
        fullscreen: {
          iosNative: true,
        },
      });

      player.toggleControls(false);

      player.on("play", (event) => {
        player.toggleControls(true);
      });

      player.on("click", () => {
        if (player.paused) {
          $(".block-video__video").removeClass("play");
        } else {
          $(".block-video__video").addClass("play");
        }
      });
    })();

    // block carousel
    $(".section-our-facilities .block-carousel").slick({
      infinite: false,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 1,
      arrows: true,
      variableWidth: true,
      responsive: [
        {
          breakpoint: 376,
          settings: {
            slidesToShow: 1,
            variableWidth: false,
          },
        },
        {
          breakpoint: 580,
          settings: {
            slidesToShow: 2,
            variableWidth: false,
          },
        },
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 3,
            variableWidth: false,
          },
        },
        {
          breakpoint: 1280,
          settings: {
            slidesToShow: 4,
            variableWidth: false,
          },
        },
      ],
    });

    // Hero section gsap
    (function () {
      ScrollTrigger.saveStyles(".section-hero *");
      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          let tl = gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-hero",
              },
            })
            .fromTo(
              ".section-hero .js-heading-title span",
              { y: 120, skewY: 7 },
              {
                y: 0,
                stagger: 0.08,
                duration: 0.4,
                skewY: 1,
                ease: animEasing,
                delay: animDelay,
              }
            )
            .fromTo(
              ".section-hero .js-heading-text",
              fadeUp,
              { autoAlpha: 1, y: 0 },
              "-=0.3"
            )
            .fromTo(
              ".section-hero .js-heading-button",
              fadeUp,
              { autoAlpha: 1, y: 0 },
              "-=0.4"
            );
        },
      });
    })();

    // Welcome section gsap
    (function () {
      ScrollTrigger.saveStyles(".section-welcome *");

      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          let tl = gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-welcome",
                start: "top bottom-=30%",
                once: true,
              },
            })
            .from(".section-welcome .section-in", fadeUp);
        },
      });
    })();

    // Leaders section
    (function () {
      ScrollTrigger.saveStyles(".section-leader *");
      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          // text timeline
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-leader",
                start: "top bottom-=13%",
                once: true,
              },
            })
            .from(".section-leader .js-product-image .image-circle", {
              scale: 0.9,
              autoAlpha: 0,
            })
            .from(
              ".section-leader .js-product-image img",
              { y: 80, autoAlpha: 0 },
              "-=0.3"
            )
            .from(".section-leader .js-product-title", fadeUp, "-=0.5")
            .from(
              ".section-leader .js-product-list li",
              {
                ...fadeUp,
                stagger: 0.1,
              },
              "-=0.5"
            )
            .from(".section-leader .js-product-text", fadeUp, "-=0.5");

          // image timeline
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-leader",
                start: "top bottom-=13%",
                scrub: true,
              },
            })
            .fromTo(".section-leader .js-product-image img", {
              yPercent: 40,
            }, {
							yPercent: -40,
							rotation: 4 * 2,
						});

          // cards timeline
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-leader .brands",
                start: "top bottom-=30%",
              },
            })
            .from(".section-leader .cards .cards-item", {
              ...fadeUp,
              stagger: 0.1,
            });
        },
      });
    })();

    // Our products section
    (function () {
      ScrollTrigger.saveStyles(".section-our-products *");
      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          // text timeline - start
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-our-products",
                start: "top bottom-=30%",
                once: true,
              },
            })
            .from(
              ".section-our-products .js-heading-title .text-overflow span",
              {
                y: 120,
                stagger: 0.08,
                duration: 0.4,
                skewY: 10,
                ease: animEasing,
              }
            );

          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-our-products .js-heading-title",
                start: "bottom bottom-=40%",
                once: true,
              },
            })
            .from(".section-our-products .js-block-info .text-overflow span", {
              y: 80,
              stagger: 0.08,
              duration: 0.4,
              skewY: 10,
              ease: animEasing,
            });
          // text timeline - end

          // product timeline - start
          gsap.utils
            .toArray(".section-our-products .js-product")
            .forEach((product) => {
              const productTitle = product.querySelector(
                ".js-product-title .text-overflow span"
              );
              const productText = product.querySelector(".js-product-text");
              const productButton = product.querySelector(".js-product-button");
              const productImage = product.querySelector(
                ".js-product-image img"
              );
              const productCircle = product.querySelector(
                ".js-product-image .image-circle"
              );

              // set rotate direction
              let rotateDirection = null;
              if (
                productImage.parentElement.classList.contains(
                  "product__image--type3"
                )
              ) {
                rotateDirection = -4 * 2;
              } else {
                rotateDirection = 4 * 2;
              }

              gsap
                .timeline({
                  scrollTrigger: {
                    trigger: product,
                    start: "top bottom-=13%",
                    once: true,
                  },
                })
                .fromTo(productCircle, { scale: 0.9, autoAlpha: 0 }, {scale: 1, autoAlpha: 1})
                .from(productImage, { y: 80, autoAlpha: 0 }, "-=0.3")
                .from(
                  productTitle,
                  {
                    y: 100,
                    duration: 0.4,
                    skewY: 10,
                    ease: animEasing,
                  },
                  "-=0.5"
                )
                .from(productText, fadeUp, "-=0.3")
                .from(productButton, fadeUp, "-=0.4");

              gsap
                .timeline({
                  scrollTrigger: {
                    trigger: product,
                    start: "top bottom-=13%",
                    scrub: true,
                  },
                })
								.fromTo(productImage, {
									yPercent: 40,
								}, {
									yPercent: -20,
									rotation: rotateDirection,
								});
            });

          // product timeline - end
        },
      });
    })();

    // More products section
    // (function () {
    //   ScrollTrigger.saveStyles(".section-more-products *");

    //   ScrollTrigger.matchMedia({
    //     "(min-width: 1023px)": function () {
    //       gsap.timeline({
    //         scrollTrigger: {
    //           trigger: ".section-more-products",
    //           start: "top top",
		// 					end: 'center top+=25%', 
    //           pin: true,
    //           pinSpacing: false,
    //         },
    //       })
		// 			gsap.timeline({
    //         scrollTrigger: {
    //           trigger: ".section-more-products",
    //           start: "bottom-=40% center",
    //           scrub: true,
						
    //         },
    //       })
		// 			.to(".section-more-products", {
		// 				yPercent: 15,
		// 			});
    //     },
    //   });
    // })();

    // Our facilities section
    (function () {
      ScrollTrigger.saveStyles(".section-our-facilities *");
      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          // text timeline - start
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-our-facilities",
                start: "top bottom-=30%",
                once: true,
              },
            })
            .from(
              ".section-our-facilities .js-heading-title .text-overflow span",
              {
                y: 120,
                stagger: 0.08,
                duration: 0.4,
                skewY: 10,
                ease: animEasing,
              }
            )
            .from(
              ".section-our-facilities .js-heading-text p",
              {
                ...fadeUp,
                stagger: 0.1,
              },
              "-=.3"
            );
          // text timeline - end

          // images/text timeline - start
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-our-facilities .block-info",
                start: "top-=10% bottom-=30%",
                once: true,
              },
            })
            .from(".section-our-facilities .js-block-info-title", fadeUp)
            .from(
              ".section-our-facilities .js-block-info-subtitle",
              fadeUp,
              "-=.5"
            )
            .from(
              ".section-our-facilities .js-block-info-text",
              fadeUp,
              "-=.4"
            );

          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-our-facilities .block-info",
                start: "top-=10% bottom-=30%",
                once: true,
              },
            })
            .to(".section-our-facilities .js-block-info-fly-img .cover", {
              y: "-100%",
              stagger: 0.1,
            })
            .from(
              ".section-our-facilities .js-block-info-fly-img",
              {
                y: 20,
              },
              "-=.6"
            );
          // images/text timeline - end
        },
      });
    })();

    // Inverstors section
    (function () {
      ScrollTrigger.saveStyles(".section-investors *");

      let tabItem = document.querySelector(
        ".section-investors .tab-item:first-child"
      );

      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          // text timeline - start
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-investors",
                start: "top bottom-=30%",
                once: true,
              },
            })
            .from(".section-investors .js-heading-title .text-overflow span", {
              y: 120,
              stagger: 0.08,
              duration: 0.4,
              skewY: 10,
              ease: animEasing,
            })
            .from(
              ".section-investors .js-heading-text p",
              {
                ...fadeUp,
                stagger: 0.1,
              },
              "-=.3"
            );
          // text timeline - end

          // image timeline - start
          gsap.timeline({
            scrollTrigger: {
              trigger: ".section-investors",
              start: "top+=20% bottom-=30%",
              onEnter() {
                tabItem.classList.add("active");
              },
            },
          });
          // image timeline - end
        },
      });
    })();

    // Leadrship section
    (function () {
      ScrollTrigger.saveStyles(".section-leadrship-team *");
      ScrollTrigger.matchMedia({
        "(min-width: 1023px)": function () {
          // text timeline - start
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".section-leadrship-team",
                start: "top bottom-=30%",
                once: true,
              },
            })
            .from(
              ".section-leadrship-team .js-heading-title .text-overflow span",
              {
                y: 120,
                stagger: 0.08,
                duration: 0.4,
                skewY: 10,
                ease: animEasing,
              }
            )
            .from(".section-leadrship-team .js-heading-subtitle", fadeUp, "-=.3")
            .from(".section-leadrship-team .js-heading-text", fadeUp, "-=.3");
          // text timeline - end

          // person timeline - start
          gsap.utils
            .toArray(".section-leadrship-team .js-person")
            .forEach((person) => {
              const personImg = person.querySelector(".block-team__img img");
              const personName = person.querySelector(".block-team__name");
              const personText = person.querySelector(".block-team__text");

              gsap
                .timeline({
                  scrollTrigger: {
                    trigger: person,
                    start: "top-=10% bottom-=30%",
                    once: true,
                  },
                })
                .fromTo(personImg, { scale: 1.2 }, { scale: 1 })
                .from(personName, fadeUp, "-=.5")
                .from(personText, fadeUp, "-=.5");
            });
          // person timeline - end
        },
      });
    })();
  }
  // HOME PAGE - end

  // HEADER - start

  // header burger
  $(".header__burger").click(function () {
    $(this).toggleClass("active");
    $(".header-nav").toggleClass("active");
  });
  // HEADER - end

  // Newsletter section - start
	(function(){
		ScrollTrigger.saveStyles(".section-newsletter *");
		gsap
	  .timeline({
	    scrollTrigger: {
	      trigger: ".section-newsletter",
	      start: "top bottom-=30%",
	      once: true,
	    },
	  })
	  .from(".section-newsletter .newsletter-block-bottom", {
	    y: 80,
	  });
	})();

  // Newsletter section - end

  // video popup
  // 	$('.popup-video').magnificPopup({
  // 		disableOn: 700,
  // 		type: 'iframe',
  // 		mainClass: 'mfp-fade',
  // 		removalDelay: 160,
  // 		preloader: true,
  // });
});

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-21 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:00:14 --> No URI present. Default controller set.
DEBUG - 2024-02-21 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:00:14 --> Total execution time: 0.2561
DEBUG - 2024-02-21 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-21 12:00:15 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-21 12:00:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:00:21 --> Total execution time: 0.0755
DEBUG - 2024-02-21 12:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-21 12:00:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-21 12:18:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:18:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:18:16 --> Total execution time: 0.1143
DEBUG - 2024-02-21 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:26:30 --> Total execution time: 0.1117
DEBUG - 2024-02-21 12:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-21 12:26:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-21 12:26:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:26:55 --> Total execution time: 0.1633
DEBUG - 2024-02-21 12:26:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-21 12:26:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-21 12:27:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-21 12:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-21 12:27:02 --> Total execution time: 0.1194
DEBUG - 2024-02-21 12:27:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-21 12:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-21 12:27:02 --> 404 Page Not Found: Assets/datatables

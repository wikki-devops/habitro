<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-24 07:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:28:01 --> No URI present. Default controller set.
DEBUG - 2024-02-24 07:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:28:01 --> Total execution time: 0.0963
DEBUG - 2024-02-24 07:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:28:01 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-24 07:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:30:04 --> No URI present. Default controller set.
DEBUG - 2024-02-24 07:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:30:04 --> Total execution time: 0.1264
DEBUG - 2024-02-24 07:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:30:04 --> 404 Page Not Found: Assets/images
DEBUG - 2024-02-24 07:30:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:30:26 --> No URI present. Default controller set.
DEBUG - 2024-02-24 07:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:30:26 --> Total execution time: 0.1049
DEBUG - 2024-02-24 07:32:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:32:30 --> No URI present. Default controller set.
DEBUG - 2024-02-24 07:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:32:30 --> Total execution time: 0.0561
DEBUG - 2024-02-24 07:32:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:32:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:32:41 --> Total execution time: 0.1557
DEBUG - 2024-02-24 07:32:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:32:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:32:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:32:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:32:56 --> Total execution time: 0.0682
DEBUG - 2024-02-24 07:32:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:32:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:34:37 --> Total execution time: 0.1176
DEBUG - 2024-02-24 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:34:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:35:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:35:44 --> Total execution time: 0.1121
DEBUG - 2024-02-24 07:35:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:35:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:36:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:36:38 --> Total execution time: 0.0772
DEBUG - 2024-02-24 07:36:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:36:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:37:07 --> Total execution time: 0.0735
DEBUG - 2024-02-24 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:37:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:37:23 --> Total execution time: 0.1027
DEBUG - 2024-02-24 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:37:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:38:35 --> Total execution time: 0.1463
DEBUG - 2024-02-24 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:38:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:40:12 --> Total execution time: 0.2223
DEBUG - 2024-02-24 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:40:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:40:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 07:40:54 --> Query error: Unknown column 'testimonial' in 'field list' - Invalid query: INSERT INTO `testimonials` (`thumbnail`, `video`, `testimonial`, `company`) VALUES ('', '', 'I recommend Habitro for any construction or interior design project. Highest quality work and they are incredibly organized and efficient in project management. They delivered our project on time, and their team was professional and trustworthy throughout. It was a stress-free experience with them.', '')
DEBUG - 2024-02-24 07:41:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:41:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 07:41:25 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\habitro\admin\application\views\testimonials.php 31
ERROR - 2024-02-24 07:41:25 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\habitro\admin\application\views\testimonials.php 31
ERROR - 2024-02-24 07:41:25 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\habitro\admin\application\views\testimonials.php 31
ERROR - 2024-02-24 07:41:25 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\habitro\admin\application\views\testimonials.php 31
ERROR - 2024-02-24 07:41:25 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\habitro\admin\application\views\testimonials.php 31
DEBUG - 2024-02-24 07:41:25 --> Total execution time: 0.1622
DEBUG - 2024-02-24 07:41:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:41:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:42:14 --> Total execution time: 0.1152
DEBUG - 2024-02-24 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:42:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:51:06 --> Total execution time: 0.0824
DEBUG - 2024-02-24 07:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:51:11 --> Total execution time: 0.1061
DEBUG - 2024-02-24 07:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:51:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:51:24 --> Total execution time: 0.1129
DEBUG - 2024-02-24 07:51:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:51:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:51:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:51:26 --> 404 Page Not Found: Welcome/leadform
DEBUG - 2024-02-24 07:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:51:33 --> Total execution time: 0.0683
DEBUG - 2024-02-24 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:53:45 --> Total execution time: 0.1360
DEBUG - 2024-02-24 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:53:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:53:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:53:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:54:13 --> Total execution time: 0.0811
DEBUG - 2024-02-24 07:54:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:54:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:54:51 --> Total execution time: 0.0755
DEBUG - 2024-02-24 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:54:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:55:05 --> Total execution time: 0.0751
DEBUG - 2024-02-24 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:55:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:57:11 --> Total execution time: 0.0710
DEBUG - 2024-02-24 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:57:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:57:11 --> 404 Page Not Found: Images/profile
DEBUG - 2024-02-24 07:57:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:57:33 --> Total execution time: 0.0857
DEBUG - 2024-02-24 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:57:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:58:01 --> Total execution time: 0.0959
DEBUG - 2024-02-24 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:58:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:58:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:58:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:58:45 --> Total execution time: 0.0732
DEBUG - 2024-02-24 07:58:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:58:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:58:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 07:59:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 07:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 07:59:27 --> Total execution time: 0.1058
DEBUG - 2024-02-24 07:59:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 07:59:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 07:59:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:01:12 --> Total execution time: 0.1228
DEBUG - 2024-02-24 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:01:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:01:15 --> Total execution time: 0.1123
DEBUG - 2024-02-24 08:01:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:01:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:01:26 --> Total execution time: 0.1488
DEBUG - 2024-02-24 08:01:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:01:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:01:41 --> Total execution time: 0.0774
DEBUG - 2024-02-24 08:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:01:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:01:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:01:52 --> Total execution time: 0.1532
DEBUG - 2024-02-24 08:01:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:01:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:05:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:05:06 --> Total execution time: 0.1993
DEBUG - 2024-02-24 08:05:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:05:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:05:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:05:34 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 44
ERROR - 2024-02-24 08:05:34 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 44
ERROR - 2024-02-24 08:05:34 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 44
ERROR - 2024-02-24 08:05:34 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 44
DEBUG - 2024-02-24 08:05:34 --> Total execution time: 0.0949
DEBUG - 2024-02-24 08:05:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:05:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:05:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:05:47 --> Total execution time: 0.1192
DEBUG - 2024-02-24 08:05:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:05:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:05:50 --> Total execution time: 0.1171
DEBUG - 2024-02-24 08:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:05:50 --> Total execution time: 0.1050
DEBUG - 2024-02-24 08:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:05:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:07:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:07:29 --> Total execution time: 0.1357
DEBUG - 2024-02-24 08:07:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:07:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:07:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:07:31 --> Total execution time: 0.0712
DEBUG - 2024-02-24 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:07:31 --> Total execution time: 0.0732
DEBUG - 2024-02-24 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:07:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:08:38 --> Total execution time: 0.1282
DEBUG - 2024-02-24 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:08:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:12:18 --> Total execution time: 0.1745
DEBUG - 2024-02-24 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:12:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:12:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:12:20 --> Total execution time: 0.0812
DEBUG - 2024-02-24 08:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:12:20 --> Total execution time: 0.0671
DEBUG - 2024-02-24 08:12:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:12:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:12:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:14:10 --> Total execution time: 0.1023
DEBUG - 2024-02-24 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:14:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:14:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:14:12 --> Total execution time: 0.0754
DEBUG - 2024-02-24 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:14:12 --> Total execution time: 0.0972
DEBUG - 2024-02-24 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:14:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:16:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:16:01 --> Total execution time: 0.0861
DEBUG - 2024-02-24 08:16:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:16:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:16:43 --> Total execution time: 0.0825
DEBUG - 2024-02-24 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:16:43 --> Total execution time: 0.0679
DEBUG - 2024-02-24 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:16:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:17:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:17:14 --> Total execution time: 0.0856
DEBUG - 2024-02-24 08:17:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:17:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:17:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:17:20 --> Total execution time: 0.0741
DEBUG - 2024-02-24 08:17:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:17:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:17:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:17:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:17:27 --> Total execution time: 0.0645
DEBUG - 2024-02-24 08:17:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:17:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:18:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:18:05 --> Severity: Notice --> Undefined variable: calltoaction C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 67
ERROR - 2024-02-24 08:18:05 --> Severity: Notice --> Undefined variable: calltoaction C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 67
ERROR - 2024-02-24 08:18:05 --> Severity: Notice --> Undefined variable: calltoaction C:\xampp\htdocs\habitro\admin\application\views\pages\leadform.php 67
DEBUG - 2024-02-24 08:18:05 --> Total execution time: 0.1212
DEBUG - 2024-02-24 08:18:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:18:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:18:12 --> Total execution time: 0.1500
DEBUG - 2024-02-24 08:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:18:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:18:15 --> Total execution time: 0.1319
DEBUG - 2024-02-24 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:18:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:18:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:20:58 --> Total execution time: 0.2651
DEBUG - 2024-02-24 08:21:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:21:01 --> Total execution time: 0.0742
DEBUG - 2024-02-24 08:21:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:21:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:23:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:23:16 --> Total execution time: 0.1466
DEBUG - 2024-02-24 08:23:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:23:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:23:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:23:18 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:23:29 --> 404 Page Not Found: Welcome/update_lead
DEBUG - 2024-02-24 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:23:39 --> Total execution time: 0.0898
DEBUG - 2024-02-24 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:23:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:23:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:23:46 --> 404 Page Not Found: Welcome/update_lead
DEBUG - 2024-02-24 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:23:57 --> Total execution time: 0.1398
DEBUG - 2024-02-24 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:23:57 --> Total execution time: 0.0775
DEBUG - 2024-02-24 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:23:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:24:00 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:24:03 --> Severity: error --> Exception: Too few arguments to function Welcome::update_lead(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 207
DEBUG - 2024-02-24 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:25:14 --> Severity: error --> Exception: Too few arguments to function Welcome::update_lead(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 207
DEBUG - 2024-02-24 08:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:25:17 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:26:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:26:36 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:27:03 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:27:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:27:06 --> Total execution time: 0.0706
DEBUG - 2024-02-24 08:27:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:27:07 --> Total execution time: 0.0608
DEBUG - 2024-02-24 08:27:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:27:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:27:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:27:10 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '1'
DEBUG - 2024-02-24 08:27:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:27:47 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '1'
DEBUG - 2024-02-24 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:28:05 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '1'
DEBUG - 2024-02-24 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:28:07 --> Total execution time: 0.0750
DEBUG - 2024-02-24 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:28:07 --> Total execution time: 0.0732
DEBUG - 2024-02-24 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:28:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:28:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:28:10 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:28:13 --> Total execution time: 0.0762
DEBUG - 2024-02-24 08:29:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:29:52 --> Total execution time: 0.1352
DEBUG - 2024-02-24 08:29:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:29:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:29:54 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:29:56 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:30:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:30:10 --> Total execution time: 0.0725
DEBUG - 2024-02-24 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:30:11 --> Total execution time: 0.0804
DEBUG - 2024-02-24 08:30:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:30:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:30:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:30:13 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:30:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:30:26 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:30:28 --> Total execution time: 0.0694
DEBUG - 2024-02-24 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:30:29 --> Total execution time: 0.1334
DEBUG - 2024-02-24 08:30:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:30:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:30:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:30:31 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:30:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:30:31 --> Query error: Table 'habitro.leadfrom' doesn't exist - Invalid query: SELECT *
FROM `leadfrom`
WHERE `id` = '4'
DEBUG - 2024-02-24 08:31:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:31:34 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 17
ERROR - 2024-02-24 08:31:34 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 17
ERROR - 2024-02-24 08:31:34 --> Severity: Notice --> Undefined variable: calltoaction C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 23
DEBUG - 2024-02-24 08:31:34 --> Total execution time: 0.3047
DEBUG - 2024-02-24 08:31:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:31:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:31:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:32:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:32:46 --> Severity: Notice --> Undefined variable: calltoaction C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 23
DEBUG - 2024-02-24 08:32:46 --> Total execution time: 0.1014
DEBUG - 2024-02-24 08:32:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:32:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:33:02 --> Severity: Notice --> Undefined index: page_title C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 23
DEBUG - 2024-02-24 08:33:02 --> Total execution time: 0.0930
DEBUG - 2024-02-24 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:33:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:33:09 --> Severity: Notice --> Undefined index: page_title C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 23
DEBUG - 2024-02-24 08:33:09 --> Total execution time: 0.0785
DEBUG - 2024-02-24 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:33:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:33:18 --> Total execution time: 0.0945
DEBUG - 2024-02-24 08:33:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:33:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:33:59 --> Total execution time: 0.0729
DEBUG - 2024-02-24 08:34:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:34:22 --> Total execution time: 0.0943
DEBUG - 2024-02-24 08:34:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:34:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:34:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:34:52 --> Total execution time: 0.1357
DEBUG - 2024-02-24 08:34:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:34:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:34:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:36:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:36:46 --> Total execution time: 0.0932
DEBUG - 2024-02-24 08:36:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:36:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:37:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:37:15 --> Total execution time: 0.1366
DEBUG - 2024-02-24 08:37:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:37:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:39:19 --> Total execution time: 0.1160
DEBUG - 2024-02-24 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:39:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:39:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:39:32 --> Total execution time: 0.0851
DEBUG - 2024-02-24 08:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:39:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:39:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:39:43 --> Total execution time: 0.0862
DEBUG - 2024-02-24 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:39:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:40:13 --> Severity: Notice --> Undefined variable: calltoaction C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 55
DEBUG - 2024-02-24 08:40:13 --> Total execution time: 0.0933
DEBUG - 2024-02-24 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:40:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:40:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:40:33 --> Total execution time: 0.0949
DEBUG - 2024-02-24 08:40:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:40:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:40:36 --> Total execution time: 0.0749
DEBUG - 2024-02-24 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:40:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 08:40:56 --> Severity: Notice --> Undefined index: emial C:\xampp\htdocs\habitro\admin\application\views\edit\editleadform.php 37
DEBUG - 2024-02-24 08:40:56 --> Total execution time: 0.0900
DEBUG - 2024-02-24 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:40:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:41:03 --> Total execution time: 0.0848
DEBUG - 2024-02-24 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:41:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:42:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:42:28 --> Total execution time: 0.1382
DEBUG - 2024-02-24 08:42:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:42:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:42:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:42:49 --> Total execution time: 0.0751
DEBUG - 2024-02-24 08:42:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:42:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:42:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:42:52 --> Total execution time: 0.1020
DEBUG - 2024-02-24 08:42:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:42:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:44:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:44:49 --> Total execution time: 0.0917
DEBUG - 2024-02-24 08:44:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:44:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:44:52 --> Total execution time: 0.1209
DEBUG - 2024-02-24 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:44:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:44:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:45:27 --> Total execution time: 0.0918
DEBUG - 2024-02-24 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:45:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:45:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:45:35 --> Total execution time: 0.0903
DEBUG - 2024-02-24 08:45:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:45:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:47:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:47:46 --> Total execution time: 0.2301
DEBUG - 2024-02-24 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:47:50 --> Total execution time: 0.0898
DEBUG - 2024-02-24 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:47:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:47:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:48:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:48:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:48:10 --> Total execution time: 0.0842
DEBUG - 2024-02-24 08:48:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:48:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:48:15 --> Total execution time: 0.1026
DEBUG - 2024-02-24 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:48:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:48:43 --> Total execution time: 0.1301
DEBUG - 2024-02-24 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:48:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:48:48 --> Total execution time: 0.0627
DEBUG - 2024-02-24 08:48:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:48:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:50:09 --> Total execution time: 0.1538
DEBUG - 2024-02-24 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:50:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:50:12 --> Total execution time: 0.0756
DEBUG - 2024-02-24 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:50:12 --> Total execution time: 0.0911
DEBUG - 2024-02-24 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:50:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:52:00 --> Total execution time: 0.1340
DEBUG - 2024-02-24 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:52:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:52:03 --> Total execution time: 0.0773
DEBUG - 2024-02-24 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:52:03 --> Total execution time: 0.0837
DEBUG - 2024-02-24 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:52:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:52:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:52:14 --> Total execution time: 0.0790
DEBUG - 2024-02-24 08:52:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:52:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:52:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:52:16 --> Total execution time: 0.0720
DEBUG - 2024-02-24 08:52:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:52:16 --> Total execution time: 0.0794
DEBUG - 2024-02-24 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:53:03 --> Total execution time: 0.0769
DEBUG - 2024-02-24 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:53:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:53:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:53:08 --> Total execution time: 0.0690
DEBUG - 2024-02-24 08:53:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:53:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:53:13 --> Total execution time: 0.0597
DEBUG - 2024-02-24 08:53:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:53:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:54:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:54:19 --> Total execution time: 0.0872
DEBUG - 2024-02-24 08:54:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:54:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:54:22 --> Total execution time: 0.1101
DEBUG - 2024-02-24 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:54:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:54:26 --> Total execution time: 0.0582
DEBUG - 2024-02-24 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:54:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:55:18 --> Total execution time: 0.0838
DEBUG - 2024-02-24 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:55:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:55:28 --> Total execution time: 0.0610
DEBUG - 2024-02-24 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:55:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:55:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:56:25 --> Total execution time: 0.0758
DEBUG - 2024-02-24 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:56:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:56:29 --> Total execution time: 0.0680
DEBUG - 2024-02-24 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:56:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:57:43 --> Total execution time: 0.0756
DEBUG - 2024-02-24 08:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:57:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:57:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:57:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:57:49 --> Total execution time: 0.0959
DEBUG - 2024-02-24 08:57:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:57:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:59:41 --> Total execution time: 0.0834
DEBUG - 2024-02-24 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:59:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 08:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 08:59:45 --> Total execution time: 0.0884
DEBUG - 2024-02-24 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 08:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 08:59:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:00:02 --> Total execution time: 0.0630
DEBUG - 2024-02-24 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:00:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:00:06 --> Total execution time: 0.0752
DEBUG - 2024-02-24 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:00:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:00:12 --> Total execution time: 0.0899
DEBUG - 2024-02-24 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:00:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:00:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:00:54 --> Total execution time: 0.1169
DEBUG - 2024-02-24 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:00:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:00:56 --> Total execution time: 0.0880
DEBUG - 2024-02-24 09:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:00:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:01:01 --> Total execution time: 0.0681
DEBUG - 2024-02-24 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:01:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:01:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:01:38 --> Total execution time: 0.1064
DEBUG - 2024-02-24 09:01:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:01:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:02:44 --> Total execution time: 0.1253
DEBUG - 2024-02-24 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:02:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:05:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:05:07 --> Total execution time: 0.1109
DEBUG - 2024-02-24 09:05:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:05:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:05:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:05:40 --> Total execution time: 0.0906
DEBUG - 2024-02-24 09:05:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:05:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:05:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:05:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:05:58 --> Total execution time: 0.0967
DEBUG - 2024-02-24 09:05:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:05:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:06:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:06:00 --> Total execution time: 0.0716
DEBUG - 2024-02-24 09:06:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:06:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:12:09 --> Total execution time: 0.3122
DEBUG - 2024-02-24 09:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:12:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:12:11 --> Total execution time: 0.0677
DEBUG - 2024-02-24 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:12:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:12:48 --> Total execution time: 0.1194
DEBUG - 2024-02-24 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:12:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:13:14 --> Total execution time: 0.0697
DEBUG - 2024-02-24 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:13:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:13:36 --> Total execution time: 0.0967
DEBUG - 2024-02-24 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:13:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:13:43 --> Total execution time: 0.0677
DEBUG - 2024-02-24 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:13:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:13:47 --> Total execution time: 0.0638
DEBUG - 2024-02-24 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:13:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 09:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 09:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 09:14:39 --> Total execution time: 0.0762
DEBUG - 2024-02-24 09:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 09:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 09:14:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:06:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:07 --> No URI present. Default controller set.
DEBUG - 2024-02-24 12:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:06:08 --> Total execution time: 1.0785
DEBUG - 2024-02-24 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:06:08 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-24 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:06:26 --> Total execution time: 0.1284
DEBUG - 2024-02-24 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:06:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:06:50 --> Total execution time: 0.1263
DEBUG - 2024-02-24 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:06:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:06:59 --> Total execution time: 0.1310
DEBUG - 2024-02-24 12:07:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:07:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:07:05 --> Total execution time: 0.0561
DEBUG - 2024-02-24 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:07:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:07:27 --> Total execution time: 0.1607
DEBUG - 2024-02-24 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:07:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:07:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:07:32 --> Total execution time: 0.0899
DEBUG - 2024-02-24 12:07:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:07:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:07:37 --> Total execution time: 0.0594
DEBUG - 2024-02-24 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:07:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:08:27 --> Total execution time: 0.0755
DEBUG - 2024-02-24 12:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:08:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:08:37 --> Total execution time: 0.0627
DEBUG - 2024-02-24 12:08:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:08:51 --> Total execution time: 0.0682
DEBUG - 2024-02-24 12:08:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:08:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:32:16 --> Total execution time: 0.0767
DEBUG - 2024-02-24 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:32:22 --> Total execution time: 0.0589
DEBUG - 2024-02-24 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:32:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:34:23 --> Total execution time: 0.1121
DEBUG - 2024-02-24 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:34:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:34:27 --> Total execution time: 0.0604
DEBUG - 2024-02-24 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:34:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:34:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:34:31 --> Total execution time: 0.0621
DEBUG - 2024-02-24 12:34:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:34:31 --> Total execution time: 0.0653
DEBUG - 2024-02-24 12:34:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:34:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:34:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:34:37 --> Total execution time: 0.0636
DEBUG - 2024-02-24 12:34:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:34:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:35:03 --> Total execution time: 0.0935
DEBUG - 2024-02-24 12:35:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:35:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:35:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:35:36 --> Total execution time: 0.0949
DEBUG - 2024-02-24 12:35:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:35:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:37:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:37:40 --> Total execution time: 0.1083
DEBUG - 2024-02-24 12:37:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:37:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:39:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 12:39:49 --> Severity: Notice --> Undefined variable: leads C:\xampp\htdocs\habitro\admin\application\views\dashboard.php 161
ERROR - 2024-02-24 12:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\dashboard.php 161
DEBUG - 2024-02-24 12:39:49 --> Total execution time: 0.1403
DEBUG - 2024-02-24 12:39:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:39:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:40:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:40:29 --> Total execution time: 0.1409
DEBUG - 2024-02-24 12:40:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:40:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:42:21 --> Total execution time: 0.0836
DEBUG - 2024-02-24 12:42:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:42:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:42:27 --> Total execution time: 0.0619
DEBUG - 2024-02-24 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:42:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:43:51 --> Total execution time: 0.1072
DEBUG - 2024-02-24 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:43:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:44:05 --> Total execution time: 0.0870
DEBUG - 2024-02-24 12:44:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:44:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:44:57 --> Total execution time: 0.0998
DEBUG - 2024-02-24 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:44:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:45:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:45:29 --> Total execution time: 0.1039
DEBUG - 2024-02-24 12:45:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:45:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:45:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:45:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:45:36 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:45:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:45:36 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:45:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:45:36 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-24 12:45:36 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:46:28 --> Total execution time: 0.1265
DEBUG - 2024-02-24 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:46:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:46:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:46:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:46:29 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 12:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:46:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:46:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:46:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:48:53 --> Total execution time: 0.1052
DEBUG - 2024-02-24 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:48:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:49:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:49:03 --> Total execution time: 0.0863
DEBUG - 2024-02-24 12:49:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:49:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:49:37 --> Total execution time: 0.1000
DEBUG - 2024-02-24 12:49:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:49:48 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:51:59 --> Total execution time: 0.1004
DEBUG - 2024-02-24 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:51:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:51:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:51:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:52:00 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:52:00 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:52:00 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:52:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:52:01 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:52:22 --> Total execution time: 0.0790
DEBUG - 2024-02-24 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:52:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:52:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:52:48 --> Total execution time: 0.0847
DEBUG - 2024-02-24 12:52:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:52:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:53:03 --> Total execution time: 0.0612
DEBUG - 2024-02-24 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:53:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:53:12 --> Total execution time: 0.0824
DEBUG - 2024-02-24 12:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:53:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:53:14 --> Total execution time: 0.0726
DEBUG - 2024-02-24 12:53:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:53:17 --> Total execution time: 0.0670
DEBUG - 2024-02-24 12:53:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:53:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:53:20 --> Total execution time: 0.0670
DEBUG - 2024-02-24 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:23 --> Total execution time: 0.1374
DEBUG - 2024-02-24 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:57:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:57:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:26 --> Total execution time: 0.0751
DEBUG - 2024-02-24 12:57:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:57:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:28 --> Total execution time: 0.0640
DEBUG - 2024-02-24 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:57:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:43 --> Total execution time: 0.0538
DEBUG - 2024-02-24 12:57:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:57:43 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-24 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:57:47 --> Total execution time: 0.0831
DEBUG - 2024-02-24 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:57:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:58:21 --> Total execution time: 0.0981
DEBUG - 2024-02-24 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:58:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:58:33 --> Total execution time: 0.0888
DEBUG - 2024-02-24 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:58:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:58:56 --> Total execution time: 0.1020
DEBUG - 2024-02-24 12:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:58:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:13 --> Total execution time: 0.0805
DEBUG - 2024-02-24 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:59:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:59:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:32 --> Total execution time: 0.0720
DEBUG - 2024-02-24 12:59:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:59:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:59:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:49 --> Total execution time: 0.0914
DEBUG - 2024-02-24 12:59:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:59:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:59:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:52 --> Total execution time: 0.0609
DEBUG - 2024-02-24 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:59:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:56 --> Total execution time: 0.0662
DEBUG - 2024-02-24 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 12:59:56 --> Total execution time: 0.0702
DEBUG - 2024-02-24 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 12:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 12:59:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:02:37 --> Total execution time: 0.1831
DEBUG - 2024-02-24 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:02:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:02:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:03:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:03:35 --> Total execution time: 0.0807
DEBUG - 2024-02-24 13:03:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:03:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:04:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:04:59 --> Total execution time: 0.0595
DEBUG - 2024-02-24 13:05:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:05:30 --> Total execution time: 0.0717
DEBUG - 2024-02-24 13:05:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:05:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:05:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:05:37 --> 404 Page Not Found: Welcome/leads
DEBUG - 2024-02-24 13:05:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:05:46 --> 404 Page Not Found: Welcome/leads
DEBUG - 2024-02-24 13:05:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:05:51 --> Total execution time: 0.0611
DEBUG - 2024-02-24 13:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:05:57 --> Total execution time: 0.0699
DEBUG - 2024-02-24 13:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:05:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:06:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:06:01 --> 404 Page Not Found: Welcome/leads
DEBUG - 2024-02-24 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:06:21 --> Total execution time: 0.0733
DEBUG - 2024-02-24 13:06:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:06:27 --> Total execution time: 0.0981
DEBUG - 2024-02-24 13:06:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:06:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:07:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:07:00 --> Total execution time: 0.0874
DEBUG - 2024-02-24 13:07:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:07:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:07:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:07:05 --> Total execution time: 0.0679
DEBUG - 2024-02-24 13:07:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:07:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:07:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:07:34 --> Total execution time: 0.0975
DEBUG - 2024-02-24 13:07:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:07:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:07:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:07:36 --> Total execution time: 0.0682
DEBUG - 2024-02-24 13:07:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:07:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:07:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:07:40 --> Total execution time: 0.0749
DEBUG - 2024-02-24 13:07:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:07:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:09:03 --> Total execution time: 0.0818
DEBUG - 2024-02-24 13:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:09:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:09:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:09:16 --> Total execution time: 0.0631
DEBUG - 2024-02-24 13:09:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:09:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:09:48 --> Total execution time: 0.1081
DEBUG - 2024-02-24 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:09:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:09:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:09:51 --> Total execution time: 0.0703
DEBUG - 2024-02-24 13:09:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:09:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:09:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:09:54 --> Total execution time: 0.0659
DEBUG - 2024-02-24 13:09:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:09:57 --> Total execution time: 0.0708
DEBUG - 2024-02-24 13:09:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:09:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:09:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:10:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:10:01 --> Total execution time: 0.0602
DEBUG - 2024-02-24 13:10:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:10:53 --> Total execution time: 0.0891
DEBUG - 2024-02-24 13:10:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:10:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:10:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:10:55 --> Total execution time: 0.0779
DEBUG - 2024-02-24 13:11:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:11:05 --> Total execution time: 0.0703
DEBUG - 2024-02-24 13:11:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:11:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:11:24 --> Total execution time: 0.0776
DEBUG - 2024-02-24 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:11:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:11:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:11:35 --> Total execution time: 0.1001
DEBUG - 2024-02-24 13:11:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:11:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:11:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:11:45 --> Total execution time: 0.0720
DEBUG - 2024-02-24 13:11:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:11:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:11:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:12:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:12:17 --> Total execution time: 0.0881
DEBUG - 2024-02-24 13:12:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:12:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:12:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:12:50 --> Total execution time: 0.0713
DEBUG - 2024-02-24 13:12:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:12:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:14:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:14:14 --> Total execution time: 0.0809
DEBUG - 2024-02-24 13:14:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:14:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:14:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:14:22 --> Total execution time: 0.0632
DEBUG - 2024-02-24 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:14:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:14:30 --> Total execution time: 0.0676
DEBUG - 2024-02-24 13:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:14:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:14:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:14:41 --> Total execution time: 0.0640
DEBUG - 2024-02-24 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:14:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:14:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:14:44 --> Total execution time: 0.0690
DEBUG - 2024-02-24 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:01 --> Total execution time: 0.1119
DEBUG - 2024-02-24 13:15:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:15:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:04 --> Total execution time: 0.0778
DEBUG - 2024-02-24 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:15:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:09 --> Total execution time: 0.0684
DEBUG - 2024-02-24 13:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:15:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:15:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:12 --> Total execution time: 0.0662
DEBUG - 2024-02-24 13:15:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:12 --> Total execution time: 0.0639
DEBUG - 2024-02-24 13:15:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:15:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:15:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:15:23 --> Total execution time: 0.0747
DEBUG - 2024-02-24 13:15:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:15:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:15:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:16:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:16:29 --> Total execution time: 0.0891
DEBUG - 2024-02-24 13:16:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:16:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:18:42 --> Total execution time: 0.0887
DEBUG - 2024-02-24 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:18:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:18:48 --> Total execution time: 0.0703
DEBUG - 2024-02-24 13:18:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:18:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:18:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:18:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:18:52 --> Total execution time: 0.0698
DEBUG - 2024-02-24 13:18:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:18:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:18:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:16 --> Total execution time: 0.0682
DEBUG - 2024-02-24 13:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:19:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:20 --> Total execution time: 0.0948
DEBUG - 2024-02-24 13:19:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:19:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:39 --> Total execution time: 0.0689
DEBUG - 2024-02-24 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:19:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:44 --> Total execution time: 0.0974
DEBUG - 2024-02-24 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:19:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:50 --> Total execution time: 0.0706
DEBUG - 2024-02-24 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:19:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:19:57 --> Total execution time: 0.0718
DEBUG - 2024-02-24 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:19:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:20:50 --> Total execution time: 0.1256
DEBUG - 2024-02-24 13:20:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:20:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:20:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:20:56 --> Total execution time: 0.0659
DEBUG - 2024-02-24 13:20:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:20:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:21:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:07 --> Total execution time: 0.0769
DEBUG - 2024-02-24 13:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:10 --> 404 Page Not Found: Profile/update
DEBUG - 2024-02-24 13:21:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:12 --> Total execution time: 0.0588
DEBUG - 2024-02-24 13:21:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:13 --> Total execution time: 0.0781
DEBUG - 2024-02-24 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:21:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:16 --> 404 Page Not Found: Profile/update
DEBUG - 2024-02-24 13:21:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:19 --> Total execution time: 0.0598
DEBUG - 2024-02-24 13:21:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:21 --> Total execution time: 0.0567
DEBUG - 2024-02-24 13:21:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:21:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:24 --> 404 Page Not Found: Profile/update
DEBUG - 2024-02-24 13:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:36 --> Total execution time: 0.0959
DEBUG - 2024-02-24 13:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:39 --> Total execution time: 0.0637
DEBUG - 2024-02-24 13:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:46 --> Total execution time: 0.0670
DEBUG - 2024-02-24 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:52 --> Total execution time: 0.0719
DEBUG - 2024-02-24 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:21:56 --> Total execution time: 0.0678
DEBUG - 2024-02-24 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:21:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:22:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:22:12 --> Total execution time: 0.0863
DEBUG - 2024-02-24 13:22:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:22:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:23:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:23:17 --> Total execution time: 0.0720
DEBUG - 2024-02-24 13:23:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:23:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:23:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:23:20 --> Total execution time: 0.0604
DEBUG - 2024-02-24 13:23:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:23:33 --> Total execution time: 0.0717
DEBUG - 2024-02-24 13:23:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:23:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:23:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:23:56 --> Total execution time: 0.1081
DEBUG - 2024-02-24 13:23:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:23:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:23:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:24:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:24:26 --> Total execution time: 0.0899
DEBUG - 2024-02-24 13:24:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:24:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:24:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:24:30 --> No URI present. Default controller set.
DEBUG - 2024-02-24 13:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:24:30 --> Total execution time: 0.0720
DEBUG - 2024-02-24 13:24:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:24:31 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-24 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:24:47 --> Total execution time: 0.0912
DEBUG - 2024-02-24 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:24:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:25:17 --> Total execution time: 0.0998
DEBUG - 2024-02-24 13:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:25:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:25:41 --> Total execution time: 0.0981
DEBUG - 2024-02-24 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:25:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:25:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:26:29 --> Total execution time: 0.0942
DEBUG - 2024-02-24 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:26:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:26:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:26:57 --> Total execution time: 0.0969
DEBUG - 2024-02-24 13:26:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:26:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:27:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:27:00 --> Total execution time: 0.0702
DEBUG - 2024-02-24 13:27:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:27:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:27:11 --> Total execution time: 0.0650
DEBUG - 2024-02-24 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:27:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:27:49 --> Total execution time: 0.0699
DEBUG - 2024-02-24 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:27:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:27:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:27:52 --> Total execution time: 0.0701
DEBUG - 2024-02-24 13:27:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:27:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:28:33 --> Total execution time: 0.0956
DEBUG - 2024-02-24 13:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:28:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:28:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:28:39 --> Total execution time: 0.0952
DEBUG - 2024-02-24 13:28:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:28:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:29:36 --> Total execution time: 0.0974
DEBUG - 2024-02-24 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:29:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:29:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:29:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:29:45 --> Total execution time: 0.0649
DEBUG - 2024-02-24 13:29:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:29:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:29:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:29:57 --> Total execution time: 0.0599
DEBUG - 2024-02-24 13:29:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:29:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:30:00 --> Total execution time: 0.0682
DEBUG - 2024-02-24 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:30:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:30:43 --> Total execution time: 0.0877
DEBUG - 2024-02-24 13:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:30:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:31:08 --> Total execution time: 0.0926
DEBUG - 2024-02-24 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:31:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:31:11 --> Total execution time: 0.0724
DEBUG - 2024-02-24 13:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:31:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:31:23 --> Total execution time: 0.0574
DEBUG - 2024-02-24 13:31:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:31:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:31:30 --> Total execution time: 0.0682
DEBUG - 2024-02-24 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:31:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:02 --> Total execution time: 0.0612
DEBUG - 2024-02-24 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:33:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:05 --> Total execution time: 0.0678
DEBUG - 2024-02-24 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:31 --> Total execution time: 0.0691
DEBUG - 2024-02-24 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:33:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:37 --> Total execution time: 0.0574
DEBUG - 2024-02-24 13:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:33:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:33:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:43 --> Total execution time: 0.0714
DEBUG - 2024-02-24 13:33:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:33:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:33:47 --> Total execution time: 0.0645
DEBUG - 2024-02-24 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:33:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:34:00 --> Total execution time: 0.0884
DEBUG - 2024-02-24 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:34:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:34:05 --> Total execution time: 0.0822
DEBUG - 2024-02-24 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:34:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:34:57 --> Total execution time: 0.0872
DEBUG - 2024-02-24 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:34:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:34:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:34:59 --> Total execution time: 0.0838
DEBUG - 2024-02-24 13:35:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:01 --> Total execution time: 0.0781
DEBUG - 2024-02-24 13:35:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:35:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:03 --> Total execution time: 0.0726
DEBUG - 2024-02-24 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:35:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:23 --> Total execution time: 0.0680
DEBUG - 2024-02-24 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:35:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:32 --> Total execution time: 0.0586
DEBUG - 2024-02-24 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:35:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:34 --> Total execution time: 0.0629
DEBUG - 2024-02-24 13:35:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:36 --> Total execution time: 0.0668
DEBUG - 2024-02-24 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:38 --> Total execution time: 0.0663
DEBUG - 2024-02-24 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:41 --> Total execution time: 0.0637
DEBUG - 2024-02-24 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:35:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:35:49 --> Total execution time: 0.0601
DEBUG - 2024-02-24 13:36:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:36:41 --> Total execution time: 0.0777
DEBUG - 2024-02-24 13:36:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:36:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:36:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:36:44 --> Total execution time: 0.0615
DEBUG - 2024-02-24 13:36:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:36:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:36:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:36:48 --> Total execution time: 0.0640
DEBUG - 2024-02-24 13:36:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:36:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:37:01 --> Total execution time: 0.0815
DEBUG - 2024-02-24 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:37:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:37:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:37:03 --> Total execution time: 0.0652
DEBUG - 2024-02-24 13:37:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:37:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:37:33 --> Total execution time: 0.0826
DEBUG - 2024-02-24 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:37:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:37:53 --> Total execution time: 0.0831
DEBUG - 2024-02-24 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:37:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:38:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:38:01 --> Total execution time: 0.0881
DEBUG - 2024-02-24 13:38:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:38:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:38:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:39:02 --> Total execution time: 0.0730
DEBUG - 2024-02-24 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:39:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:39:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:11 --> Total execution time: 0.0941
DEBUG - 2024-02-24 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:40:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:40 --> Total execution time: 0.0967
DEBUG - 2024-02-24 13:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:40:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:43 --> Total execution time: 0.1031
DEBUG - 2024-02-24 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:40:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:47 --> Total execution time: 0.0542
DEBUG - 2024-02-24 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:40:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:40:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:40:55 --> Total execution time: 0.1010
DEBUG - 2024-02-24 13:40:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:40:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:41:01 --> Total execution time: 0.0636
DEBUG - 2024-02-24 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:41:01 --> Total execution time: 0.0677
DEBUG - 2024-02-24 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:41:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:41 --> Total execution time: 0.0596
DEBUG - 2024-02-24 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:57:41 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-24 13:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:47 --> Total execution time: 0.0602
DEBUG - 2024-02-24 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:57:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:57:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:52 --> Total execution time: 0.0659
DEBUG - 2024-02-24 13:57:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:57:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:54 --> Total execution time: 0.0684
DEBUG - 2024-02-24 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:57:54 --> Total execution time: 0.0718
DEBUG - 2024-02-24 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:57:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:57:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:58:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:58:46 --> Total execution time: 0.1408
DEBUG - 2024-02-24 13:58:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:58:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:58:49 --> Total execution time: 0.0662
DEBUG - 2024-02-24 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:58:49 --> Total execution time: 0.0662
DEBUG - 2024-02-24 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:58:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:58:54 --> Total execution time: 0.0831
DEBUG - 2024-02-24 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:58:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:07 --> Total execution time: 0.0731
DEBUG - 2024-02-24 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:59:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:59:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:10 --> Total execution time: 0.0692
DEBUG - 2024-02-24 13:59:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:10 --> Total execution time: 0.0740
DEBUG - 2024-02-24 13:59:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:59:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:59:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:27 --> Total execution time: 0.1067
DEBUG - 2024-02-24 13:59:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:59:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:59:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:29 --> Total execution time: 0.0743
DEBUG - 2024-02-24 13:59:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:59:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 13:59:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 13:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 13:59:49 --> Total execution time: 0.0856
DEBUG - 2024-02-24 13:59:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 13:59:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 13:59:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:00:42 --> Total execution time: 0.0812
DEBUG - 2024-02-24 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:00:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:01:03 --> Total execution time: 0.0572
DEBUG - 2024-02-24 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:01:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:01:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:03:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:03:46 --> Total execution time: 0.0820
DEBUG - 2024-02-24 14:03:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:03:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:03:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:03:58 --> Total execution time: 0.0647
DEBUG - 2024-02-24 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:03:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:04:07 --> Total execution time: 0.1077
DEBUG - 2024-02-24 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:04:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:04:57 --> Total execution time: 0.0996
DEBUG - 2024-02-24 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:04:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:04:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:05:50 --> Total execution time: 0.1433
DEBUG - 2024-02-24 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:05:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:05:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:05:52 --> Total execution time: 0.0887
DEBUG - 2024-02-24 14:05:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:05:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:05:54 --> Total execution time: 0.0737
DEBUG - 2024-02-24 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:05:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:05:57 --> Total execution time: 0.0703
DEBUG - 2024-02-24 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:05:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:06:01 --> Total execution time: 0.0591
DEBUG - 2024-02-24 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:06:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:06:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:06:07 --> Total execution time: 0.0653
DEBUG - 2024-02-24 14:06:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:06:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:06:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:06:29 --> Total execution time: 0.1001
DEBUG - 2024-02-24 14:06:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:06:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:06:31 --> Total execution time: 0.0677
DEBUG - 2024-02-24 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:06:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:07:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:07:03 --> Total execution time: 0.0906
DEBUG - 2024-02-24 14:07:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:07:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:07:23 --> Total execution time: 0.0648
DEBUG - 2024-02-24 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:07:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:07:30 --> Total execution time: 0.0608
DEBUG - 2024-02-24 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:07:30 --> Total execution time: 0.0657
DEBUG - 2024-02-24 14:07:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:07:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:07:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:09:47 --> Total execution time: 0.2661
DEBUG - 2024-02-24 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:09:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:09:50 --> Total execution time: 0.0809
DEBUG - 2024-02-24 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:09:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:09:58 --> Total execution time: 0.1126
DEBUG - 2024-02-24 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:09:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:10:47 --> Total execution time: 0.0973
DEBUG - 2024-02-24 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:10:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:12:31 --> Total execution time: 0.0784
DEBUG - 2024-02-24 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:12:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:12:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:14:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:14:07 --> Total execution time: 0.0709
DEBUG - 2024-02-24 14:14:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:14:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:14:17 --> Total execution time: 0.0787
DEBUG - 2024-02-24 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:14:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:14:49 --> Total execution time: 0.1039
DEBUG - 2024-02-24 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:14:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:15:10 --> Total execution time: 0.1087
DEBUG - 2024-02-24 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:15:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:15:27 --> Total execution time: 0.0682
DEBUG - 2024-02-24 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:15:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:15:42 --> Total execution time: 0.1028
DEBUG - 2024-02-24 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:15:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:16:28 --> Total execution time: 0.0685
DEBUG - 2024-02-24 14:16:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:16:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:17:50 --> Total execution time: 0.1136
DEBUG - 2024-02-24 14:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:17:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:17:58 --> Total execution time: 0.0657
DEBUG - 2024-02-24 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:17:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:12 --> Total execution time: 0.0628
DEBUG - 2024-02-24 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:18:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:35 --> Total execution time: 0.0605
DEBUG - 2024-02-24 14:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:18:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:50 --> Total execution time: 0.0669
DEBUG - 2024-02-24 14:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:18:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:18:57 --> Total execution time: 0.0656
DEBUG - 2024-02-24 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:18:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:19:06 --> Total execution time: 0.0637
DEBUG - 2024-02-24 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:19:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:19:16 --> Total execution time: 0.0662
DEBUG - 2024-02-24 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:19:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:19:27 --> Total execution time: 0.0998
DEBUG - 2024-02-24 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:19:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:19:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:19:38 --> Total execution time: 0.0806
DEBUG - 2024-02-24 14:19:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:19:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:19:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:20:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:20:27 --> Total execution time: 0.1113
DEBUG - 2024-02-24 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:20:52 --> Total execution time: 0.0707
DEBUG - 2024-02-24 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:20:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:20:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:20:59 --> Total execution time: 0.0674
DEBUG - 2024-02-24 14:20:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:20:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:21:39 --> Total execution time: 0.1035
DEBUG - 2024-02-24 14:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:21:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:21:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:21:44 --> Total execution time: 0.0785
DEBUG - 2024-02-24 14:21:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:21:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:21:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:21:50 --> Total execution time: 0.0689
DEBUG - 2024-02-24 14:21:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:21:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:26:03 --> Total execution time: 0.1007
DEBUG - 2024-02-24 14:26:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:26:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:26:09 --> Total execution time: 0.0796
DEBUG - 2024-02-24 14:28:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:28:05 --> Total execution time: 0.0766
DEBUG - 2024-02-24 14:28:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:28:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:29:04 --> Total execution time: 0.0955
DEBUG - 2024-02-24 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:29:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:29:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:29:24 --> Total execution time: 0.0726
DEBUG - 2024-02-24 14:29:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:29:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:40:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:40:40 --> Total execution time: 0.0657
DEBUG - 2024-02-24 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:40:45 --> Total execution time: 0.0556
DEBUG - 2024-02-24 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:40:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:40:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:40:51 --> Total execution time: 0.0818
DEBUG - 2024-02-24 14:40:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:40:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:40:56 --> Total execution time: 0.0935
DEBUG - 2024-02-24 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:40:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:03 --> Total execution time: 0.0720
DEBUG - 2024-02-24 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:19 --> Total execution time: 0.0653
DEBUG - 2024-02-24 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:32 --> Total execution time: 0.0729
DEBUG - 2024-02-24 14:41:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:33 --> Total execution time: 0.0588
DEBUG - 2024-02-24 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:37 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:38 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:38 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:38 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:39 --> Total execution time: 0.0623
DEBUG - 2024-02-24 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:40 --> 404 Page Not Found: Welcome/list
DEBUG - 2024-02-24 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:51 --> Total execution time: 0.0691
DEBUG - 2024-02-24 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:41:51 --> Total execution time: 0.0699
DEBUG - 2024-02-24 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:41:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:41:51 --> 404 Page Not Found: Welcome/list
DEBUG - 2024-02-24 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:00 --> Total execution time: 0.0688
DEBUG - 2024-02-24 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:00 --> Total execution time: 0.0742
DEBUG - 2024-02-24 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:42:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:42:00 --> 404 Page Not Found: Welcome/list
DEBUG - 2024-02-24 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:47 --> Total execution time: 0.0689
DEBUG - 2024-02-24 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:47 --> Total execution time: 0.0634
DEBUG - 2024-02-24 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:47 --> UTF-8 Support Enabled
ERROR - 2024-02-24 14:42:47 --> 404 Page Not Found: Welcome/list
DEBUG - 2024-02-24 14:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:42:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:42:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:57 --> Total execution time: 0.0884
DEBUG - 2024-02-24 14:42:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:42:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-24 14:42:57 --> 404 Page Not Found: Welcome/list
DEBUG - 2024-02-24 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:59 --> Total execution time: 0.0830
DEBUG - 2024-02-24 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:42:59 --> Total execution time: 0.0738
DEBUG - 2024-02-24 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:42:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:42:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:43:16 --> Total execution time: 0.0672
DEBUG - 2024-02-24 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:21 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:21 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:21 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:21 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:21 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:22 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:22 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:22 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:22 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:22 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:22 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:43:26 --> Total execution time: 0.0685
DEBUG - 2024-02-24 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:26 --> 404 Page Not Found: Welcome/teststststs
DEBUG - 2024-02-24 14:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:43:59 --> Total execution time: 0.1120
DEBUG - 2024-02-24 14:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:43:59 --> 404 Page Not Found: Welcome/teststststs
DEBUG - 2024-02-24 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:44:04 --> Total execution time: 0.0651
DEBUG - 2024-02-24 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:44:04 --> Total execution time: 0.0677
DEBUG - 2024-02-24 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:44:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:47:04 --> Total execution time: 0.1354
DEBUG - 2024-02-24 14:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:47:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:47:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:47:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:47:04 --> 404 Page Not Found: Images/no_img_avatar.png
DEBUG - 2024-02-24 14:50:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:50:31 --> Total execution time: 0.1331
DEBUG - 2024-02-24 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:50:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:50:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:50:51 --> Total execution time: 0.1105
DEBUG - 2024-02-24 14:50:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:50:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:51:06 --> Total execution time: 0.1198
DEBUG - 2024-02-24 14:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:51:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:51:52 --> Total execution time: 0.1450
DEBUG - 2024-02-24 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:51:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:52:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:52:01 --> Total execution time: 0.1028
DEBUG - 2024-02-24 14:52:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:52:25 --> Total execution time: 0.1175
DEBUG - 2024-02-24 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:46 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:46 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:52:46 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:53:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:53:10 --> Total execution time: 0.1337
DEBUG - 2024-02-24 14:53:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:53:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:11 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:53:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:11 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:53:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:11 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:53:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:53:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:53:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:28 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:53:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:53:59 --> Total execution time: 0.1293
DEBUG - 2024-02-24 14:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:53:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:00 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:00 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:00 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:02 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:54:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:54:14 --> Total execution time: 0.1179
DEBUG - 2024-02-24 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:54:24 --> Total execution time: 0.1190
DEBUG - 2024-02-24 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:54:31 --> Total execution time: 0.1102
DEBUG - 2024-02-24 14:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:54:49 --> Total execution time: 0.1109
DEBUG - 2024-02-24 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:54:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:55:10 --> Total execution time: 0.1130
DEBUG - 2024-02-24 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:55:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:55:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:55:57 --> Total execution time: 0.1346
DEBUG - 2024-02-24 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:55:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:56:35 --> Total execution time: 0.1260
DEBUG - 2024-02-24 14:56:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:56:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:57:01 --> Total execution time: 0.0678
DEBUG - 2024-02-24 14:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:57:03 --> Total execution time: 0.0668
DEBUG - 2024-02-24 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:57:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:10 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:10 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:10 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:57:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:57:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:57:10 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:58:02 --> Total execution time: 0.0843
DEBUG - 2024-02-24 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:58:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:03 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-24 14:58:03 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:58:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:03 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:58:43 --> Total execution time: 0.0760
DEBUG - 2024-02-24 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:43 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:58:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:44 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 14:58:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 14:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 14:58:49 --> Total execution time: 0.0995
DEBUG - 2024-02-24 14:58:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 14:58:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 14:58:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:02:00 --> Total execution time: 0.1458
DEBUG - 2024-02-24 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:02:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:02:29 --> Total execution time: 0.1122
DEBUG - 2024-02-24 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:02:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:02:56 --> Total execution time: 0.1167
DEBUG - 2024-02-24 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:02:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:06:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:06:08 --> Total execution time: 0.1183
DEBUG - 2024-02-24 15:06:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:06:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:07:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:07:01 --> Total execution time: 0.1539
DEBUG - 2024-02-24 15:07:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:07:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:11:38 --> Total execution time: 0.1215
DEBUG - 2024-02-24 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:11:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:11:41 --> Total execution time: 0.0727
DEBUG - 2024-02-24 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:11:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:12:09 --> Total execution time: 0.1020
DEBUG - 2024-02-24 15:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:12:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:12:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:12:41 --> Total execution time: 0.1217
DEBUG - 2024-02-24 15:12:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:12:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:13:11 --> Total execution time: 0.1322
DEBUG - 2024-02-24 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:13:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:13:17 --> Total execution time: 0.0835
DEBUG - 2024-02-24 15:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:13:17 --> Total execution time: 0.0589
DEBUG - 2024-02-24 15:13:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:13:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:13:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:13:40 --> Total execution time: 0.1157
DEBUG - 2024-02-24 15:13:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:13:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:14:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:14:14 --> Total execution time: 0.1268
DEBUG - 2024-02-24 15:14:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:14:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:14:30 --> Total execution time: 0.1235
DEBUG - 2024-02-24 15:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:14:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:14:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:14:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:14:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:14:49 --> UTF-8 Support Enabled
ERROR - 2024-02-24 15:14:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 15:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:14:49 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:16:09 --> Total execution time: 0.0766
DEBUG - 2024-02-24 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:09 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:09 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:09 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:11 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:16:13 --> Total execution time: 0.0804
DEBUG - 2024-02-24 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:16:15 --> Total execution time: 0.0726
DEBUG - 2024-02-24 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:16:52 --> Total execution time: 0.0832
DEBUG - 2024-02-24 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:16:57 --> Total execution time: 0.0656
DEBUG - 2024-02-24 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:16:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:10 --> Total execution time: 0.0625
DEBUG - 2024-02-24 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:10 --> Total execution time: 0.0606
DEBUG - 2024-02-24 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:17:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:17 --> Total execution time: 0.0599
DEBUG - 2024-02-24 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:17 --> Total execution time: 0.0572
DEBUG - 2024-02-24 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:17:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:24 --> Total execution time: 0.0612
DEBUG - 2024-02-24 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:17:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:36 --> Total execution time: 0.0856
DEBUG - 2024-02-24 15:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:36 --> Total execution time: 0.0676
DEBUG - 2024-02-24 15:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:17:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:44 --> Total execution time: 0.0638
DEBUG - 2024-02-24 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:17:44 --> Total execution time: 0.0661
DEBUG - 2024-02-24 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:17:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:18:26 --> Total execution time: 0.0768
DEBUG - 2024-02-24 15:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:18:26 --> Total execution time: 0.0681
DEBUG - 2024-02-24 15:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:18:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:18:58 --> Total execution time: 0.1405
DEBUG - 2024-02-24 15:18:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:18:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:04 --> Total execution time: 0.0874
DEBUG - 2024-02-24 15:19:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:04 --> Total execution time: 0.0581
DEBUG - 2024-02-24 15:19:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:16 --> Total execution time: 0.0690
DEBUG - 2024-02-24 15:19:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:19 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:21 --> Total execution time: 0.0602
DEBUG - 2024-02-24 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:21 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:28 --> Total execution time: 0.1031
DEBUG - 2024-02-24 15:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:28 --> Total execution time: 0.0653
DEBUG - 2024-02-24 15:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:28 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:37 --> Total execution time: 0.0677
DEBUG - 2024-02-24 15:19:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:39 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:39 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:39 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:39 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:39 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:41 --> Total execution time: 0.0660
DEBUG - 2024-02-24 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:41 --> 404 Page Not Found: Welcome/dfdsf
ERROR - 2024-02-24 15:19:41 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:19:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:47 --> Total execution time: 0.0660
DEBUG - 2024-02-24 15:19:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:50 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:50 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:50 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:50 --> 404 Page Not Found: Add/residential_page
DEBUG - 2024-02-24 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:52 --> Total execution time: 0.0606
DEBUG - 2024-02-24 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:52 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:52 --> 404 Page Not Found: Welcome/dfdsf
DEBUG - 2024-02-24 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:52 --> 404 Page Not Found: Welcome/fdsf
DEBUG - 2024-02-24 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:58 --> Total execution time: 0.0642
DEBUG - 2024-02-24 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:19:58 --> Total execution time: 0.0624
DEBUG - 2024-02-24 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:58 --> UTF-8 Support Enabled
ERROR - 2024-02-24 15:19:58 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:19:58 --> 404 Page Not Found: Welcome/fdsf
ERROR - 2024-02-24 15:19:59 --> 404 Page Not Found: Welcome/dfdsf
DEBUG - 2024-02-24 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:21:28 --> Total execution time: 0.1145
DEBUG - 2024-02-24 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:28 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:28 --> 404 Page Not Found: Welcome/fdsf
DEBUG - 2024-02-24 15:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:28 --> 404 Page Not Found: Welcome/dfdsf
DEBUG - 2024-02-24 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:21:35 --> Total execution time: 0.0675
DEBUG - 2024-02-24 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:21:35 --> Total execution time: 0.0596
DEBUG - 2024-02-24 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:35 --> UTF-8 Support Enabled
ERROR - 2024-02-24 15:21:35 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:35 --> 404 Page Not Found: Welcome/dfdsf
DEBUG - 2024-02-24 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:35 --> 404 Page Not Found: Welcome/fdsf
DEBUG - 2024-02-24 15:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:21:52 --> Total execution time: 0.0656
DEBUG - 2024-02-24 15:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:21:52 --> Total execution time: 0.0574
DEBUG - 2024-02-24 15:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:52 --> UTF-8 Support Enabled
ERROR - 2024-02-24 15:21:52 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:21:52 --> 404 Page Not Found: Welcome/dfdsf
ERROR - 2024-02-24 15:21:52 --> 404 Page Not Found: Welcome/fdsf
DEBUG - 2024-02-24 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:23:22 --> Total execution time: 0.0951
DEBUG - 2024-02-24 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:23:22 --> Total execution time: 0.0666
DEBUG - 2024-02-24 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:23:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:23:23 --> 404 Page Not Found: Welcome/das
ERROR - 2024-02-24 15:23:23 --> 404 Page Not Found: Welcome/dfdsf
DEBUG - 2024-02-24 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:23:23 --> 404 Page Not Found: Welcome/fdsf
DEBUG - 2024-02-24 15:31:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:09 --> Total execution time: 0.1182
DEBUG - 2024-02-24 15:31:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:31:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:09 --> 404 Page Not Found: Welcome/dfdsf
ERROR - 2024-02-24 15:31:09 --> 404 Page Not Found: Welcome/das
ERROR - 2024-02-24 15:31:09 --> 404 Page Not Found: Welcome/fdsf
DEBUG - 2024-02-24 15:31:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:16 --> Total execution time: 0.0674
DEBUG - 2024-02-24 15:31:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:16 --> Total execution time: 0.0595
DEBUG - 2024-02-24 15:31:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:31:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:17 --> 404 Page Not Found: Welcome/dfdsf
DEBUG - 2024-02-24 15:31:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:17 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:31:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:23 --> Total execution time: 0.0616
DEBUG - 2024-02-24 15:31:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:24 --> Total execution time: 0.0646
DEBUG - 2024-02-24 15:31:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:31:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:24 --> 404 Page Not Found: Welcome/das
DEBUG - 2024-02-24 15:31:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:29 --> Total execution time: 0.0695
DEBUG - 2024-02-24 15:31:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:29 --> Total execution time: 0.0653
DEBUG - 2024-02-24 15:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:31:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:35 --> Total execution time: 0.0719
DEBUG - 2024-02-24 15:31:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:35 --> Total execution time: 0.0599
DEBUG - 2024-02-24 15:31:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:31:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:47 --> Total execution time: 0.1017
DEBUG - 2024-02-24 15:31:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:31:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:56 --> Total execution time: 0.0769
DEBUG - 2024-02-24 15:31:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:31:56 --> Total execution time: 0.0595
DEBUG - 2024-02-24 15:31:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:31:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:32:01 --> Total execution time: 0.0783
DEBUG - 2024-02-24 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:32:02 --> Total execution time: 0.0634
DEBUG - 2024-02-24 15:32:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:32:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:32:25 --> Total execution time: 0.0600
DEBUG - 2024-02-24 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:32:25 --> Total execution time: 0.0599
DEBUG - 2024-02-24 15:32:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:32:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:32:31 --> Total execution time: 0.0653
DEBUG - 2024-02-24 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:32:31 --> Total execution time: 0.0621
DEBUG - 2024-02-24 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:32:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:32:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:45:45 --> Total execution time: 0.1060
DEBUG - 2024-02-24 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:45:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:46:04 --> Total execution time: 0.0608
DEBUG - 2024-02-24 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:46:05 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-24 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:46:10 --> Total execution time: 0.0557
DEBUG - 2024-02-24 15:46:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:46:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:46:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:46:16 --> Total execution time: 0.0782
DEBUG - 2024-02-24 15:46:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:46:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:46:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:46:23 --> Total execution time: 0.1245
DEBUG - 2024-02-24 15:46:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:46:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:50:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:50:03 --> Total execution time: 0.0793
DEBUG - 2024-02-24 15:50:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:50:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:50:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:50:07 --> Total execution time: 0.0786
DEBUG - 2024-02-24 15:50:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:50:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:50:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:50:09 --> Total execution time: 0.0833
DEBUG - 2024-02-24 15:50:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:50:16 --> Total execution time: 0.0896
DEBUG - 2024-02-24 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:50:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:50:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:50:24 --> Total execution time: 0.0825
DEBUG - 2024-02-24 15:50:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:50:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:50:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:52:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:52:37 --> Total execution time: 0.1356
DEBUG - 2024-02-24 15:52:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:52:44 --> Total execution time: 0.0680
DEBUG - 2024-02-24 15:52:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:52:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:52:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:52:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:52:52 --> Total execution time: 0.0646
DEBUG - 2024-02-24 15:52:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:52:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:53:03 --> Total execution time: 0.0781
DEBUG - 2024-02-24 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:53:03 --> Total execution time: 0.0727
DEBUG - 2024-02-24 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:53:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:53:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 15:53:51 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\habitro\admin\application\views\pages\renovation.php 78
ERROR - 2024-02-24 15:53:51 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\habitro\admin\application\views\pages\renovation.php 81
ERROR - 2024-02-24 15:53:51 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\habitro\admin\application\views\pages\renovation.php 96
ERROR - 2024-02-24 15:53:51 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\habitro\admin\application\views\pages\renovation.php 78
ERROR - 2024-02-24 15:53:51 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\habitro\admin\application\views\pages\renovation.php 81
ERROR - 2024-02-24 15:53:51 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\habitro\admin\application\views\pages\renovation.php 96
DEBUG - 2024-02-24 15:53:51 --> Total execution time: 0.1376
DEBUG - 2024-02-24 15:53:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:53:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:53:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:54:34 --> Total execution time: 0.1211
DEBUG - 2024-02-24 15:54:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:54:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:54:40 --> Total execution time: 0.0718
DEBUG - 2024-02-24 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:54:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:54:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:54:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:54:51 --> Total execution time: 0.0644
DEBUG - 2024-02-24 15:54:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:54:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:54:58 --> Total execution time: 0.0666
DEBUG - 2024-02-24 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:54:58 --> Total execution time: 0.0596
DEBUG - 2024-02-24 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:54:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:10 --> Total execution time: 0.1043
DEBUG - 2024-02-24 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:55:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:55:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:19 --> Total execution time: 0.0613
DEBUG - 2024-02-24 15:55:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:19 --> Total execution time: 0.0626
DEBUG - 2024-02-24 15:55:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:55:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:24 --> Total execution time: 0.0641
DEBUG - 2024-02-24 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:24 --> Total execution time: 0.0611
DEBUG - 2024-02-24 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:55:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:49 --> Total execution time: 0.0974
DEBUG - 2024-02-24 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:55:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:55:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:55:53 --> Total execution time: 0.0831
DEBUG - 2024-02-24 15:55:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:55:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:56:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:56:21 --> Total execution time: 0.0679
DEBUG - 2024-02-24 15:56:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:56:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:56:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:57:02 --> Total execution time: 0.0976
DEBUG - 2024-02-24 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:57:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:57:20 --> Total execution time: 0.0699
DEBUG - 2024-02-24 15:57:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:57:22 --> Total execution time: 0.1378
DEBUG - 2024-02-24 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:57:25 --> Total execution time: 0.0621
DEBUG - 2024-02-24 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:57:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:59:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:59:27 --> Total execution time: 1.1033
DEBUG - 2024-02-24 15:59:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:59:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:59:38 --> Total execution time: 0.1574
DEBUG - 2024-02-24 15:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:59:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:59:46 --> Total execution time: 0.0630
DEBUG - 2024-02-24 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:59:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 15:59:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:59:58 --> Total execution time: 0.0895
DEBUG - 2024-02-24 15:59:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 15:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 15:59:58 --> Total execution time: 0.0570
DEBUG - 2024-02-24 15:59:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 15:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 15:59:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:00:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:00:05 --> Total execution time: 0.1080
DEBUG - 2024-02-24 16:00:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:00:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:00:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:00:34 --> Total execution time: 0.1102
DEBUG - 2024-02-24 16:00:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:00:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:00:36 --> Total execution time: 0.1245
DEBUG - 2024-02-24 16:00:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:00:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:00:53 --> Total execution time: 0.0964
DEBUG - 2024-02-24 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:00:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:00:57 --> Total execution time: 0.0745
DEBUG - 2024-02-24 16:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:00:57 --> Total execution time: 0.0611
DEBUG - 2024-02-24 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:00:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:01 --> Total execution time: 0.0805
DEBUG - 2024-02-24 16:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:01:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:01:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:20 --> Total execution time: 0.0676
DEBUG - 2024-02-24 16:01:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:01:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:01:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:24 --> Total execution time: 0.0690
DEBUG - 2024-02-24 16:01:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:24 --> Total execution time: 0.0670
DEBUG - 2024-02-24 16:01:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:01:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:01:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:40 --> Total execution time: 0.0593
DEBUG - 2024-02-24 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:01:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:01:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:48 --> Total execution time: 0.1014
DEBUG - 2024-02-24 16:01:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:01:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:01:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:01:57 --> Total execution time: 0.0869
DEBUG - 2024-02-24 16:01:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:01:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:02:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:02:43 --> Total execution time: 0.1281
DEBUG - 2024-02-24 16:02:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:02:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:02:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:02:49 --> Total execution time: 0.1132
DEBUG - 2024-02-24 16:02:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:02:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:03:06 --> Total execution time: 0.0918
DEBUG - 2024-02-24 16:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:03:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:06:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:06:43 --> Total execution time: 0.1121
DEBUG - 2024-02-24 16:06:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:06:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:06:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:06:55 --> Total execution time: 0.0716
DEBUG - 2024-02-24 16:06:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:06:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:06:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:06:58 --> Total execution time: 0.0723
DEBUG - 2024-02-24 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:10:33 --> Total execution time: 0.1115
DEBUG - 2024-02-24 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:10:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:10:33 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:10:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:10:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:10:34 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:10:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:10:40 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:10:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:10:43 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:11:14 --> Total execution time: 0.1086
DEBUG - 2024-02-24 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:14 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:14 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:19 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:22 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:11:42 --> Total execution time: 0.0922
DEBUG - 2024-02-24 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:42 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:43 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:11:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:11:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:11:47 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:12:28 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
DEBUG - 2024-02-24 16:12:28 --> Total execution time: 0.1598
DEBUG - 2024-02-24 16:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:12:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:12:28 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:12:29 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:12:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:12:33 --> 404 Page Not Found: Images/big
DEBUG - 2024-02-24 16:12:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:12:58 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
DEBUG - 2024-02-24 16:12:58 --> Total execution time: 0.1410
DEBUG - 2024-02-24 16:12:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:12:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:13:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 106
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 107
ERROR - 2024-02-24 16:13:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
DEBUG - 2024-02-24 16:13:12 --> Total execution time: 0.0864
DEBUG - 2024-02-24 16:13:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 108
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 109
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 108
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 109
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 108
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 109
ERROR - 2024-02-24 16:13:50 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
DEBUG - 2024-02-24 16:13:50 --> Total execution time: 0.1303
DEBUG - 2024-02-24 16:13:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:13:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 110
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 115
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 110
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 115
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 110
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:14:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 115
DEBUG - 2024-02-24 16:14:12 --> Total execution time: 0.1165
DEBUG - 2024-02-24 16:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:14:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 110
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 115
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 110
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 115
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 110
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:14:39 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 115
DEBUG - 2024-02-24 16:14:39 --> Total execution time: 0.1059
DEBUG - 2024-02-24 16:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:14:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:15:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:15:07 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:07 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:15:07 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:07 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:15:07 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:07 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
DEBUG - 2024-02-24 16:15:07 --> Total execution time: 0.1142
DEBUG - 2024-02-24 16:15:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:15:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:15:15 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:15:15 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:15 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:15:15 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:15 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:15:15 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
DEBUG - 2024-02-24 16:15:15 --> Total execution time: 0.1176
DEBUG - 2024-02-24 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:15:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:15:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:15:37 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:15:37 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:37 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:15:37 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:37 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 111
ERROR - 2024-02-24 16:15:37 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
DEBUG - 2024-02-24 16:15:37 --> Total execution time: 0.0704
DEBUG - 2024-02-24 16:15:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:15:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:15:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:15:53 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:53 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:15:53 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:53 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:15:53 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:15:53 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
DEBUG - 2024-02-24 16:15:53 --> Total execution time: 0.1082
DEBUG - 2024-02-24 16:15:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:15:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:15:58 --> Total execution time: 0.0810
DEBUG - 2024-02-24 16:15:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:15:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:15:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:16:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-24 16:16:00 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:16:00 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:16:00 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:16:00 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
ERROR - 2024-02-24 16:16:00 --> Severity: Warning --> Illegal string offset 'video' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 112
ERROR - 2024-02-24 16:16:00 --> Severity: Warning --> Illegal string offset 'image' C:\xampp\htdocs\habitro\admin\application\views\pages\commercial.php 113
DEBUG - 2024-02-24 16:16:00 --> Total execution time: 0.0746
DEBUG - 2024-02-24 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:16:21 --> Total execution time: 0.0921
DEBUG - 2024-02-24 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:16:38 --> Total execution time: 0.0975
DEBUG - 2024-02-24 16:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:16:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 16:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 16:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:56 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 16:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:16:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 16:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-24 16:17:13 --> Total execution time: 0.1141
DEBUG - 2024-02-24 16:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:17:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-24 16:17:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:17:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-24 16:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:17:14 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-24 16:17:14 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-24 16:17:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:17:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-24 16:17:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-24 16:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-24 16:17:15 --> 404 Page Not Found: Assets/vendor

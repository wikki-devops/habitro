<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-19 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:17:57 --> No URI present. Default controller set.
DEBUG - 2024-02-19 02:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:17:57 --> Total execution time: 0.1279
DEBUG - 2024-02-19 02:21:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:21:27 --> No URI present. Default controller set.
DEBUG - 2024-02-19 02:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:21:27 --> Total execution time: 0.0618
DEBUG - 2024-02-19 02:21:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:21:31 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-19 02:21:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:21:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:21:44 --> Total execution time: 0.0169
DEBUG - 2024-02-19 02:21:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:21:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:21:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:21:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:21:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:23:08 --> Total execution time: 0.0135
DEBUG - 2024-02-19 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:23:08 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:23:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:23:15 --> Total execution time: 0.0113
DEBUG - 2024-02-19 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 17
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 18
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 22
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 29
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 36
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 43
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 50
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 60
ERROR - 2024-02-19 02:23:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 67
DEBUG - 2024-02-19 02:23:15 --> Total execution time: 0.0086
DEBUG - 2024-02-19 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:23:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:23:42 --> Total execution time: 0.0058
DEBUG - 2024-02-19 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:23:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:23:43 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:24:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:24:33 --> Total execution time: 0.0256
DEBUG - 2024-02-19 02:24:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:24:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:24:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:24:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:24:43 --> Total execution time: 0.2808
DEBUG - 2024-02-19 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:24:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:24:44 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:25:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:25:03 --> Total execution time: 0.0117
DEBUG - 2024-02-19 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:25:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:25:04 --> Total execution time: 0.0067
DEBUG - 2024-02-19 02:26:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:26:52 --> Total execution time: 0.0802
DEBUG - 2024-02-19 02:26:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:26:53 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:26:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:26:56 --> Total execution time: 0.0156
DEBUG - 2024-02-19 02:28:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:28:02 --> Total execution time: 0.0127
DEBUG - 2024-02-19 02:28:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:28:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:28:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:28:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:28:25 --> Total execution time: 0.0149
DEBUG - 2024-02-19 02:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:28:26 --> Total execution time: 0.0050
DEBUG - 2024-02-19 02:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:28:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:28:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:28:45 --> Total execution time: 0.0095
DEBUG - 2024-02-19 02:28:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:28:50 --> Total execution time: 0.0109
DEBUG - 2024-02-19 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:28:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:28:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:30:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:30:10 --> Total execution time: 0.0250
DEBUG - 2024-02-19 02:30:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:30:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:30:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:30:10 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:30:20 --> Total execution time: 0.0052
DEBUG - 2024-02-19 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:30:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:30:20 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:31:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 02:31:42 --> Query error: Unknown column 'content_2' in 'field list' - Invalid query: INSERT INTO `residentialcard` (`image`, `content`, `descripition`, `content_2`, `descripition_2`) VALUES ('http://via.placeholder.com/400x500', 'Plan ', 'This stage of turnkey says, ‘Your wish is our command’. Your expectations and desires for your dream home are taken into account while we draft a plan.', NULL, NULL)
DEBUG - 2024-02-19 02:33:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:28 --> Total execution time: 0.0444
DEBUG - 2024-02-19 02:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:33:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:40 --> Total execution time: 0.0130
DEBUG - 2024-02-19 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:41 --> Total execution time: 0.0141
DEBUG - 2024-02-19 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:46 --> Total execution time: 0.0107
DEBUG - 2024-02-19 02:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:46 --> Total execution time: 0.0074
DEBUG - 2024-02-19 02:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:49 --> Total execution time: 0.0127
DEBUG - 2024-02-19 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:49 --> Total execution time: 0.0075
DEBUG - 2024-02-19 02:33:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:33:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:33:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:33:51 --> Total execution time: 0.0052
DEBUG - 2024-02-19 02:33:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:33:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:33:52 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:34:22 --> Total execution time: 0.0073
DEBUG - 2024-02-19 02:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:34:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:34:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:34:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:34:36 --> Total execution time: 0.0111
DEBUG - 2024-02-19 02:34:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:34:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:34:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:34:36 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:35:00 --> Total execution time: 0.0082
DEBUG - 2024-02-19 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:35:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:35:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:42:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:42:24 --> Total execution time: 0.0740
DEBUG - 2024-02-19 02:42:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:42:25 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-19 02:42:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:42:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:42:28 --> Total execution time: 0.0128
DEBUG - 2024-02-19 02:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:42:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:42:29 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:42:56 --> Total execution time: 0.0126
DEBUG - 2024-02-19 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:42:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:42:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:43:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:43:14 --> Total execution time: 0.0095
DEBUG - 2024-02-19 02:43:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:43:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:43:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:43:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:43:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:43:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:43:34 --> Total execution time: 0.0073
DEBUG - 2024-02-19 02:43:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:43:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:43:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:43:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:43:50 --> Total execution time: 0.0122
DEBUG - 2024-02-19 02:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:43:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 02:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:43:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:44:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 02:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 02:44:08 --> Total execution time: 0.0110
DEBUG - 2024-02-19 02:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:44:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:44:08 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 02:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 02:44:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 02:44:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:32 --> No URI present. Default controller set.
DEBUG - 2024-02-19 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:43:32 --> Total execution time: 0.1019
DEBUG - 2024-02-19 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:43:33 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-19 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:43:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:43:40 --> Total execution time: 0.0193
DEBUG - 2024-02-19 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:43:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:43:41 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-19 06:43:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:43:55 --> Total execution time: 0.0185
DEBUG - 2024-02-19 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:43:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:43:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:00 --> Total execution time: 0.0252
DEBUG - 2024-02-19 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 06:44:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 18
ERROR - 2024-02-19 06:44:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 22
ERROR - 2024-02-19 06:44:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 37
ERROR - 2024-02-19 06:44:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 44
DEBUG - 2024-02-19 06:44:00 --> Total execution time: 0.0072
DEBUG - 2024-02-19 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:16 --> Total execution time: 0.0093
DEBUG - 2024-02-19 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:27 --> Total execution time: 0.0272
DEBUG - 2024-02-19 06:44:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 06:44:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-19 06:44:28 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 18
ERROR - 2024-02-19 06:44:28 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 22
ERROR - 2024-02-19 06:44:28 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 37
ERROR - 2024-02-19 06:44:28 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 44
DEBUG - 2024-02-19 06:44:28 --> Total execution time: 0.0331
DEBUG - 2024-02-19 06:44:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:35 --> Total execution time: 0.0254
DEBUG - 2024-02-19 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:44:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:47 --> Total execution time: 0.0164
DEBUG - 2024-02-19 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 06:44:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 18
ERROR - 2024-02-19 06:44:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 22
ERROR - 2024-02-19 06:44:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 37
ERROR - 2024-02-19 06:44:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 44
DEBUG - 2024-02-19 06:44:48 --> Total execution time: 0.0114
DEBUG - 2024-02-19 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:44:53 --> Total execution time: 0.0093
DEBUG - 2024-02-19 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:44:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:45:19 --> Total execution time: 0.0117
DEBUG - 2024-02-19 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:45:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 06:45:21 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 18
ERROR - 2024-02-19 06:45:21 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 22
ERROR - 2024-02-19 06:45:21 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 37
ERROR - 2024-02-19 06:45:21 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/edittail.php 44
DEBUG - 2024-02-19 06:45:21 --> Total execution time: 0.0255
DEBUG - 2024-02-19 06:45:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:45:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:45:32 --> Total execution time: 0.0107
DEBUG - 2024-02-19 06:45:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:45:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:45:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:45:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:48:55 --> Total execution time: 0.0605
DEBUG - 2024-02-19 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:48:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:48:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:49:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:49:05 --> Total execution time: 0.0146
DEBUG - 2024-02-19 06:49:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:49:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:49:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:49:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:49:55 --> Total execution time: 0.0174
DEBUG - 2024-02-19 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:49:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:49:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:50:02 --> Total execution time: 0.0372
DEBUG - 2024-02-19 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:50:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 17
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 18
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 22
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 29
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 36
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 43
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 50
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 60
ERROR - 2024-02-19 06:50:04 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 67
DEBUG - 2024-02-19 06:50:04 --> Total execution time: 0.0183
DEBUG - 2024-02-19 06:50:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:50:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:50:15 --> Total execution time: 0.0076
DEBUG - 2024-02-19 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:50:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:50:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-19 06:50:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-19 06:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-19 06:50:29 --> Total execution time: 0.0142
DEBUG - 2024-02-19 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:50:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-19 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-19 06:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-19 06:50:30 --> 404 Page Not Found: Vendor/summernote

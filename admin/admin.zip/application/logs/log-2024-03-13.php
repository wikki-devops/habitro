<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-13 12:37:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:20 --> No URI present. Default controller set.
DEBUG - 2024-03-13 12:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-13 12:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-13 12:37:20 --> Total execution time: 0.0931
DEBUG - 2024-03-13 12:37:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-13 12:37:21 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-13 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-13 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-13 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-13 12:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-13 12:37:26 --> Total execution time: 0.1259
DEBUG - 2024-03-13 12:37:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-13 12:37:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-13 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-13 12:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-13 12:37:34 --> Total execution time: 0.0857
DEBUG - 2024-03-13 12:37:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-13 12:37:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-13 12:37:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-13 12:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-13 12:37:51 --> Total execution time: 0.1120
DEBUG - 2024-03-13 12:37:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-13 12:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-13 12:37:51 --> 404 Page Not Found: Assets/datatables

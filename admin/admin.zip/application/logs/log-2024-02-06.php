<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-06 13:13:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:13:46 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:13:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'habitro' C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:13:46 --> Unable to connect to the database
DEBUG - 2024-02-06 13:22:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:22:03 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:22:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'habitro' C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:22:03 --> Unable to connect to the database
DEBUG - 2024-02-06 13:22:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:22:09 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:22:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:22:09 --> Unable to connect to the database
DEBUG - 2024-02-06 13:23:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:23:09 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:23:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:23:09 --> Unable to connect to the database
DEBUG - 2024-02-06 13:23:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:23:40 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:23:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:23:40 --> Unable to connect to the database
DEBUG - 2024-02-06 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:25:20 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:25:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:25:21 --> Unable to connect to the database
DEBUG - 2024-02-06 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:30:42 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:30:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:30:42 --> Unable to connect to the database
DEBUG - 2024-02-06 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:33:13 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:33:13 --> Severity: error --> Exception: Call to undefined function mysql_connect() C:\xampp\htdocs\habitro\admin\application\config\database.php 29
DEBUG - 2024-02-06 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:33:32 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 13:33:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'habitro' C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-06 13:33:32 --> Unable to connect to the database
DEBUG - 2024-02-06 13:35:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:35:37 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:35:37 --> Total execution time: 0.0787
DEBUG - 2024-02-06 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:35:38 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-06 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:35:42 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:35:42 --> Total execution time: 0.1054
DEBUG - 2024-02-06 13:35:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:35:59 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:35:59 --> Total execution time: 0.0744
DEBUG - 2024-02-06 13:37:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:22 --> No URI present. Default controller set.
DEBUG - 2024-02-06 13:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:37:22 --> Total execution time: 0.0633
DEBUG - 2024-02-06 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:37:35 --> Total execution time: 0.0774
DEBUG - 2024-02-06 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:37:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:37:36 --> UTF-8 Support Enabled
ERROR - 2024-02-06 13:37:36 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:37:36 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:37:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:37:37 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:37:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:37:37 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:37:48 --> Total execution time: 0.0918
DEBUG - 2024-02-06 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:37:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:39:36 --> Total execution time: 0.0595
DEBUG - 2024-02-06 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:39:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:47:07 --> Total execution time: 0.0627
DEBUG - 2024-02-06 13:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:47:16 --> Total execution time: 0.0592
DEBUG - 2024-02-06 13:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:47:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:47:16 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:47:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:47:16 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:47:17 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-06 13:47:17 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:47:20 --> Total execution time: 0.0714
DEBUG - 2024-02-06 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:47:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:48:36 --> Total execution time: 0.0744
DEBUG - 2024-02-06 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:48:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:49:13 --> Total execution time: 0.0740
DEBUG - 2024-02-06 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:49:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:49:28 --> Total execution time: 0.0645
DEBUG - 2024-02-06 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:49:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:52:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:52:09 --> Total execution time: 0.0678
DEBUG - 2024-02-06 13:52:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:52:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:52:22 --> Total execution time: 0.0903
DEBUG - 2024-02-06 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:52:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:52:42 --> Total execution time: 0.0689
DEBUG - 2024-02-06 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:52:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:52:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:52:51 --> Total execution time: 0.1251
DEBUG - 2024-02-06 13:52:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:52:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:53:18 --> Total execution time: 0.0621
DEBUG - 2024-02-06 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:53:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:56:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 13:56:02 --> Total execution time: 0.0903
DEBUG - 2024-02-06 13:56:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:56:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 13:59:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 13:59:15 --> 404 Page Not Found: Welcome/home
DEBUG - 2024-02-06 14:00:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:00:47 --> Total execution time: 0.0752
DEBUG - 2024-02-06 14:00:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:00:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:00:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:00:55 --> Total execution time: 0.0632
DEBUG - 2024-02-06 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:00:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:00:57 --> Total execution time: 0.0789
DEBUG - 2024-02-06 14:00:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:00:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:01:56 --> Total execution time: 0.0850
DEBUG - 2024-02-06 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:01:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 14:01:59 --> Severity: error --> Exception: Call to undefined method GetData::update_menu() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 365
DEBUG - 2024-02-06 14:04:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:04:18 --> Total execution time: 0.0793
DEBUG - 2024-02-06 14:04:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:04:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:04:26 --> Total execution time: 0.0686
DEBUG - 2024-02-06 14:04:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:04:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:05:29 --> Total execution time: 0.0787
DEBUG - 2024-02-06 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:05:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:05:37 --> Total execution time: 0.0691
DEBUG - 2024-02-06 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:05:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:10 --> Total execution time: 0.0577
DEBUG - 2024-02-06 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:06:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:06:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:19 --> Total execution time: 0.0674
DEBUG - 2024-02-06 14:06:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:06:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:44 --> Total execution time: 0.0673
DEBUG - 2024-02-06 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:06:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:48 --> Total execution time: 0.0641
DEBUG - 2024-02-06 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:06:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:06:55 --> Total execution time: 0.0715
DEBUG - 2024-02-06 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:06:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:08:27 --> Total execution time: 0.0666
DEBUG - 2024-02-06 14:08:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:08:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:08:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:08:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:08:34 --> Total execution time: 0.0638
DEBUG - 2024-02-06 14:08:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:08:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:11:38 --> Total execution time: 2.1875
DEBUG - 2024-02-06 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:11:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:11:54 --> Total execution time: 0.1563
DEBUG - 2024-02-06 14:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:11:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:12:29 --> Total execution time: 0.1224
DEBUG - 2024-02-06 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:12:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:13:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:13:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:13:56 --> Total execution time: 0.0809
DEBUG - 2024-02-06 14:13:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:13:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:13:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:15:01 --> Total execution time: 0.0574
DEBUG - 2024-02-06 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:15:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:15:08 --> Total execution time: 0.0589
DEBUG - 2024-02-06 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:15:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:15:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:16:23 --> Total execution time: 0.0712
DEBUG - 2024-02-06 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:16:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:16:31 --> Total execution time: 0.0648
DEBUG - 2024-02-06 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:16:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-06 14:17:55 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\pages\home.php 45
ERROR - 2024-02-06 14:17:56 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\pages\home.php 45
ERROR - 2024-02-06 14:17:56 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\pages\home.php 45
ERROR - 2024-02-06 14:17:56 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\pages\home.php 45
DEBUG - 2024-02-06 14:17:56 --> Total execution time: 0.1043
DEBUG - 2024-02-06 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:17:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:19:12 --> Total execution time: 0.0621
DEBUG - 2024-02-06 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:19:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:19:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:19:20 --> Total execution time: 0.0479
DEBUG - 2024-02-06 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:19:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:20:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:20:05 --> Total execution time: 0.1027
DEBUG - 2024-02-06 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:20:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:21:04 --> Total execution time: 0.0592
DEBUG - 2024-02-06 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:21:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:21:10 --> Total execution time: 0.0530
DEBUG - 2024-02-06 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:21:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:25:54 --> Total execution time: 0.0679
DEBUG - 2024-02-06 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:25:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:26:02 --> Total execution time: 0.0527
DEBUG - 2024-02-06 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:26:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:26:26 --> Total execution time: 0.0533
DEBUG - 2024-02-06 14:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:26:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:26:58 --> Total execution time: 0.0582
DEBUG - 2024-02-06 14:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:26:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:30:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:30:35 --> Total execution time: 0.0601
DEBUG - 2024-02-06 14:30:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:30:43 --> Total execution time: 0.1044
DEBUG - 2024-02-06 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:43 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:43 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:30:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:49 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:30:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:31:42 --> Total execution time: 0.1164
DEBUG - 2024-02-06 14:31:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:31:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:31:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:45 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 14:31:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:49 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:31:49 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:38:11 --> Total execution time: 0.1252
DEBUG - 2024-02-06 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:38:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:38:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:38:12 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-06 14:38:12 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 14:38:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:38:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:38:33 --> Total execution time: 0.0802
DEBUG - 2024-02-06 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:38:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:40:35 --> Total execution time: 0.1089
DEBUG - 2024-02-06 14:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:40:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:42:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:42:54 --> Total execution time: 0.1466
DEBUG - 2024-02-06 14:42:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:42:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:43:04 --> Total execution time: 0.0697
DEBUG - 2024-02-06 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:43:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:43:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:43:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:43:13 --> Total execution time: 0.0588
DEBUG - 2024-02-06 14:43:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:43:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:43:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:43:20 --> Total execution time: 0.0573
DEBUG - 2024-02-06 14:43:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:43:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:55:58 --> Total execution time: 0.1035
DEBUG - 2024-02-06 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:55:58 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-06 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:56:06 --> Total execution time: 0.0568
DEBUG - 2024-02-06 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:56:21 --> Total execution time: 0.0479
DEBUG - 2024-02-06 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:56:22 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-06 14:56:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:56:22 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:56:23 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-06 14:56:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 14:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 14:56:29 --> Total execution time: 0.1037
DEBUG - 2024-02-06 14:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:56:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:59:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 14:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:59:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 14:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 14:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 14:59:30 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-06 14:59:30 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:01:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:01:17 --> Total execution time: 0.0567
DEBUG - 2024-02-06 15:01:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:01:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:01:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:01:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:01:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:01:27 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:02:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:02:12 --> Total execution time: 0.0560
DEBUG - 2024-02-06 15:02:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:02:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:02:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:02:13 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:02:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:02:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:02:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:04:21 --> Total execution time: 0.1064
DEBUG - 2024-02-06 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:04:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:04:38 --> Total execution time: 0.0921
DEBUG - 2024-02-06 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:04:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:05:23 --> Total execution time: 0.1220
DEBUG - 2024-02-06 15:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:05:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:06:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:06:44 --> Total execution time: 0.0635
DEBUG - 2024-02-06 15:06:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:06:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:07:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:07:26 --> Total execution time: 0.0877
DEBUG - 2024-02-06 15:07:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:07:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:07:37 --> Total execution time: 0.1597
DEBUG - 2024-02-06 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:07:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:08:25 --> Total execution time: 0.1116
DEBUG - 2024-02-06 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:08:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:08:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:08:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:08:38 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:08:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:10:02 --> Total execution time: 0.0619
DEBUG - 2024-02-06 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:10:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:10:02 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:10:02 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:10:02 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:15:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:15:11 --> Total execution time: 0.1006
DEBUG - 2024-02-06 15:15:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:15:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:15:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:15:12 --> UTF-8 Support Enabled
ERROR - 2024-02-06 15:15:12 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:15:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:15:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:15:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:16:11 --> Total execution time: 0.0884
DEBUG - 2024-02-06 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:16:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:16:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:20:19 --> Total execution time: 0.0498
DEBUG - 2024-02-06 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:20:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:20:23 --> Total execution time: 0.0745
DEBUG - 2024-02-06 15:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:20:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:20:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:20:32 --> Total execution time: 0.0575
DEBUG - 2024-02-06 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:21:32 --> Total execution time: 0.0948
DEBUG - 2024-02-06 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:21:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:21:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:21:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:21:46 --> Total execution time: 0.0657
DEBUG - 2024-02-06 15:21:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:21:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:22:22 --> Total execution time: 0.0691
DEBUG - 2024-02-06 15:22:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:22:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:22:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:22:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:22:52 --> Total execution time: 0.0625
DEBUG - 2024-02-06 15:22:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:22:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:25:17 --> Total execution time: 0.0923
DEBUG - 2024-02-06 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:25:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:38:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:38:43 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:38:48 --> Total execution time: 0.0530
DEBUG - 2024-02-06 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:38:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:38:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:38:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:38:49 --> Total execution time: 0.0575
DEBUG - 2024-02-06 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:38:53 --> Total execution time: 0.0524
DEBUG - 2024-02-06 15:38:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:38:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:38:56 --> Total execution time: 0.0484
DEBUG - 2024-02-06 15:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:38:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:39:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:39:00 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:06 --> Total execution time: 0.0510
DEBUG - 2024-02-06 15:39:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:39:09 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:39:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:11 --> Total execution time: 0.0514
DEBUG - 2024-02-06 15:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:12 --> Total execution time: 0.0615
DEBUG - 2024-02-06 15:39:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:14 --> Total execution time: 0.0695
DEBUG - 2024-02-06 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:17 --> Total execution time: 0.0571
DEBUG - 2024-02-06 15:39:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:19 --> Total execution time: 0.0724
DEBUG - 2024-02-06 15:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:22 --> Total execution time: 0.0460
DEBUG - 2024-02-06 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:23 --> Total execution time: 0.0508
DEBUG - 2024-02-06 15:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:39:27 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:39:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:29 --> Total execution time: 0.0448
DEBUG - 2024-02-06 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:32 --> Total execution time: 0.0584
DEBUG - 2024-02-06 15:39:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:34 --> Total execution time: 0.0588
DEBUG - 2024-02-06 15:39:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:39:41 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:39:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:42 --> Total execution time: 0.0517
DEBUG - 2024-02-06 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:39:45 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:39:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:47 --> Total execution time: 0.0601
DEBUG - 2024-02-06 15:39:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:49 --> Total execution time: 0.0574
DEBUG - 2024-02-06 15:39:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:39:51 --> Total execution time: 0.0584
DEBUG - 2024-02-06 15:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:40:53 --> Total execution time: 0.0608
DEBUG - 2024-02-06 15:40:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:40:55 --> Total execution time: 0.0580
DEBUG - 2024-02-06 15:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:40:57 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:40:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:40:59 --> Total execution time: 0.0559
DEBUG - 2024-02-06 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:41:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:41:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:41:04 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:41:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:41:09 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:29 --> Total execution time: 0.0512
DEBUG - 2024-02-06 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:29 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-06 15:42:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:31 --> Total execution time: 0.0568
DEBUG - 2024-02-06 15:42:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:31 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:42:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:36 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:39 --> Total execution time: 0.0616
DEBUG - 2024-02-06 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:40 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:40 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:40 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:43 --> Total execution time: 0.0462
DEBUG - 2024-02-06 15:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:43 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-06 15:42:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:45 --> Total execution time: 0.0843
DEBUG - 2024-02-06 15:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:46 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:46 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:46 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:50 --> Total execution time: 0.0572
DEBUG - 2024-02-06 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:50 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:50 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:51 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:52 --> Total execution time: 0.0762
DEBUG - 2024-02-06 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:52 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:52 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:53 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:42:58 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-06 15:42:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:42:59 --> Total execution time: 0.0636
DEBUG - 2024-02-06 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:43:00 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-06 15:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:43:00 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:43:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:43:00 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:43:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:43:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:43:05 --> Total execution time: 0.0515
DEBUG - 2024-02-06 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-06 15:43:06 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:43:06 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-06 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:44:13 --> Total execution time: 0.0577
DEBUG - 2024-02-06 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:13 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 15:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:13 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:44:16 --> Total execution time: 0.0905
DEBUG - 2024-02-06 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:44:18 --> Total execution time: 0.0676
DEBUG - 2024-02-06 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:44:21 --> Total execution time: 0.0742
DEBUG - 2024-02-06 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 15:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 15:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 15:44:24 --> Total execution time: 0.0668
DEBUG - 2024-02-06 15:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 15:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 15:44:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-06 16:03:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 16:03:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 16:03:21 --> Total execution time: 0.0724
DEBUG - 2024-02-06 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 16:05:44 --> Total execution time: 0.0510
DEBUG - 2024-02-06 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 16:05:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-06 16:05:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 16:05:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 16:05:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:05:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 16:05:45 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-06 16:05:45 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-06 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-06 16:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 16:05:51 --> Total execution time: 0.0531
DEBUG - 2024-02-06 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-06 16:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-06 16:05:51 --> 404 Page Not Found: Assets/datatables

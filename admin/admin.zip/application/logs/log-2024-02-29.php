<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-29 09:57:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:57:58 --> No URI present. Default controller set.
DEBUG - 2024-02-29 09:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-29 09:58:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-29 09:58:02 --> Unable to connect to the database
DEBUG - 2024-02-29 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:58:27 --> No URI present. Default controller set.
DEBUG - 2024-02-29 09:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-29 09:58:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-29 09:58:31 --> Unable to connect to the database
DEBUG - 2024-02-29 09:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:58:58 --> No URI present. Default controller set.
DEBUG - 2024-02-29 09:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-29 09:58:58 --> Total execution time: 0.0726
DEBUG - 2024-02-29 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:58:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-29 09:58:59 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-29 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-29 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-29 09:59:03 --> Total execution time: 0.1013
DEBUG - 2024-02-29 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-29 09:59:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-29 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-29 09:59:06 --> Total execution time: 0.0844
DEBUG - 2024-02-29 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-29 09:59:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-29 09:59:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-29 09:59:10 --> Total execution time: 0.0668
DEBUG - 2024-02-29 09:59:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-29 09:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-29 09:59:10 --> Total execution time: 0.0630
DEBUG - 2024-02-29 09:59:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-29 09:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-29 09:59:10 --> 404 Page Not Found: Assets/datatables

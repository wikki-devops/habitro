<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-20 02:50:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:50:48 --> No URI present. Default controller set.
DEBUG - 2024-02-20 02:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:50:48 --> Total execution time: 0.3840
DEBUG - 2024-02-20 02:50:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:50:49 --> No URI present. Default controller set.
DEBUG - 2024-02-20 02:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:50:49 --> Total execution time: 0.0119
DEBUG - 2024-02-20 02:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:51:02 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:51:04 --> Total execution time: 0.0258
DEBUG - 2024-02-20 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:51:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:51:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:51:26 --> Total execution time: 0.0182
DEBUG - 2024-02-20 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:51:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:51:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:52:22 --> Total execution time: 0.0163
DEBUG - 2024-02-20 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:52:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:52:22 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 02:54:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 02:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 02:54:03 --> Total execution time: 0.0805
DEBUG - 2024-02-20 02:54:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:54:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 02:54:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 02:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 02:54:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:08:02 --> Total execution time: 0.0104
DEBUG - 2024-02-20 03:08:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:08:04 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:08:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:08:10 --> Total execution time: 0.1568
DEBUG - 2024-02-20 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:08:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:08:12 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:08:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:08:18 --> Total execution time: 0.1628
DEBUG - 2024-02-20 03:08:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:08:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:08:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:08:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:09:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:09:47 --> Total execution time: 0.1439
DEBUG - 2024-02-20 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:09:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:09:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:13:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:13:48 --> Total execution time: 0.1084
DEBUG - 2024-02-20 03:13:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:13:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:13:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:13:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:13:52 --> Total execution time: 0.0100
DEBUG - 2024-02-20 03:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:13:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:13:52 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:14:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:14:21 --> Total execution time: 0.0213
DEBUG - 2024-02-20 03:14:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:14:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 03:14:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:14:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 03:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 03:14:23 --> Total execution time: 0.0140
DEBUG - 2024-02-20 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:14:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 03:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 03:14:24 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:25:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:25:36 --> No URI present. Default controller set.
DEBUG - 2024-02-20 10:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 10:25:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-20 10:25:36 --> Unable to connect to the database
DEBUG - 2024-02-20 10:29:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:29:39 --> No URI present. Default controller set.
DEBUG - 2024-02-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 10:29:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'manosprm_habitro'@'localhost' (using password: YES) C:\xampp\htdocs\habitro\admin\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-20 10:29:39 --> Unable to connect to the database
DEBUG - 2024-02-20 10:30:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:02 --> No URI present. Default controller set.
DEBUG - 2024-02-20 10:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:30:03 --> Total execution time: 0.1025
DEBUG - 2024-02-20 10:30:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:30:03 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:30:07 --> Total execution time: 0.1047
DEBUG - 2024-02-20 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:30:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:30:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:30:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:30:17 --> Total execution time: 0.0988
DEBUG - 2024-02-20 10:30:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:30:17 --> UTF-8 Support Enabled
ERROR - 2024-02-20 10:30:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:30:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:31:15 --> Total execution time: 0.1229
DEBUG - 2024-02-20 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:31:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:31:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:31:54 --> Total execution time: 0.1146
DEBUG - 2024-02-20 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:31:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:31:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:32:47 --> Total execution time: 0.1117
DEBUG - 2024-02-20 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:32:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:32:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:35:28 --> Total execution time: 0.1069
DEBUG - 2024-02-20 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:35:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:35:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:35:56 --> Total execution time: 0.0914
DEBUG - 2024-02-20 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:35:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 10:35:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:36:56 --> Total execution time: 0.1072
DEBUG - 2024-02-20 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:36:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:36:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:37:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:37:00 --> Total execution time: 0.1127
DEBUG - 2024-02-20 10:37:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:37:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:37:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:37:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:37:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:37:18 --> Total execution time: 0.0960
DEBUG - 2024-02-20 10:37:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:37:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:37:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:37:19 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:38:15 --> Total execution time: 0.1055
DEBUG - 2024-02-20 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:38:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:38:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:39:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:39:35 --> Total execution time: 0.1005
DEBUG - 2024-02-20 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:39:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:39:36 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:40:13 --> Total execution time: 0.1421
DEBUG - 2024-02-20 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:13 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:40:33 --> Total execution time: 0.1002
DEBUG - 2024-02-20 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:40:35 --> Total execution time: 0.0702
DEBUG - 2024-02-20 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:40:38 --> Total execution time: 0.1530
DEBUG - 2024-02-20 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:40:40 --> Total execution time: 0.1314
DEBUG - 2024-02-20 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:40 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:40:41 --> Total execution time: 0.1067
DEBUG - 2024-02-20 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:40:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:40:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:08 --> No URI present. Default controller set.
DEBUG - 2024-02-20 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:41:08 --> Total execution time: 0.0570
DEBUG - 2024-02-20 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:41:12 --> Total execution time: 0.0579
DEBUG - 2024-02-20 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:41:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:41:12 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:15 --> No URI present. Default controller set.
DEBUG - 2024-02-20 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:41:15 --> Total execution time: 0.0564
DEBUG - 2024-02-20 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:41:18 --> Total execution time: 0.0571
DEBUG - 2024-02-20 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:41:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 10:41:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:42:28 --> Total execution time: 0.1536
DEBUG - 2024-02-20 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:42:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 10:42:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:42:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:42:32 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:43:37 --> Total execution time: 0.1243
DEBUG - 2024-02-20 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:43:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 10:43:37 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:43:54 --> Total execution time: 0.0590
DEBUG - 2024-02-20 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:43:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:43:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 10:44:07 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\habitro\admin\application\views\blogs\blogs.php 18
ERROR - 2024-02-20 10:44:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\blogs\blogs.php 18
DEBUG - 2024-02-20 10:44:07 --> Total execution time: 0.0930
DEBUG - 2024-02-20 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:44:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:44:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:44:15 --> Total execution time: 0.0785
DEBUG - 2024-02-20 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:44:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 10:44:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:47:49 --> Total execution time: 0.0934
DEBUG - 2024-02-20 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:47:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:47:49 --> 404 Page Not Found: Images/property
DEBUG - 2024-02-20 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:47:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:47:49 --> 404 Page Not Found: Images/avatar
ERROR - 2024-02-20 10:47:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:47:54 --> Total execution time: 0.0708
DEBUG - 2024-02-20 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:47:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:47:54 --> UTF-8 Support Enabled
ERROR - 2024-02-20 10:47:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:47:54 --> 404 Page Not Found: Images/property
DEBUG - 2024-02-20 10:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:47:54 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:50:34 --> Total execution time: 0.0711
DEBUG - 2024-02-20 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:50:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:50:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:50:34 --> 404 Page Not Found: Images/property
ERROR - 2024-02-20 10:50:34 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:52:47 --> Total execution time: 0.1628
DEBUG - 2024-02-20 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:52:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:52:47 --> UTF-8 Support Enabled
ERROR - 2024-02-20 10:52:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:52:47 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:52:47 --> 404 Page Not Found: Images/property
DEBUG - 2024-02-20 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 10:54:04 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\habitro\admin\application\views\blogs\blogs.php 126
DEBUG - 2024-02-20 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:54:21 --> Total execution time: 0.0730
DEBUG - 2024-02-20 10:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:21 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:54:48 --> Total execution time: 0.0896
DEBUG - 2024-02-20 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 10:54:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:54:48 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:55:00 --> Total execution time: 0.0859
DEBUG - 2024-02-20 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:00 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:55:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:55:31 --> Total execution time: 0.0941
DEBUG - 2024-02-20 10:55:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:55:31 --> UTF-8 Support Enabled
ERROR - 2024-02-20 10:55:31 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:55:31 --> UTF-8 Support Enabled
ERROR - 2024-02-20 10:55:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:55:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:31 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-02-20 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:55:45 --> Total execution time: 0.0761
DEBUG - 2024-02-20 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:55:54 --> Total execution time: 0.0841
DEBUG - 2024-02-20 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:55:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:56:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 10:56:18 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\blogs\blogs.php 37
ERROR - 2024-02-20 10:56:18 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\blogs\blogs.php 37
ERROR - 2024-02-20 10:56:18 --> Severity: Notice --> Undefined variable: testimonial C:\xampp\htdocs\habitro\admin\application\views\blogs\blogs.php 37
DEBUG - 2024-02-20 10:56:18 --> Total execution time: 0.1339
DEBUG - 2024-02-20 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:56:18 --> UTF-8 Support Enabled
ERROR - 2024-02-20 10:56:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:56:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:56:30 --> Total execution time: 0.0705
DEBUG - 2024-02-20 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:56:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:56:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:58:18 --> Total execution time: 0.0879
DEBUG - 2024-02-20 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:58:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:58:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:58:26 --> Total execution time: 0.0792
DEBUG - 2024-02-20 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:58:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:58:26 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:58:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 10:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 10:58:46 --> Total execution time: 0.0831
DEBUG - 2024-02-20 10:58:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:58:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:58:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:58:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:58:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:59:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:59:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 10:59:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:59:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 10:59:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:59:17 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 10:59:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:59:17 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 10:59:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 10:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 10:59:17 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 11:00:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:00:20 --> Total execution time: 0.0845
DEBUG - 2024-02-20 11:00:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:00:20 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:00:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:00:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:00:21 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-20 11:00:21 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:00:21 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:01:27 --> Total execution time: 0.0769
DEBUG - 2024-02-20 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:01:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 11:01:27 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:01:29 --> Total execution time: 0.0683
DEBUG - 2024-02-20 11:01:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:01:45 --> Total execution time: 0.0613
DEBUG - 2024-02-20 11:01:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:01:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:01:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:01:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:01:47 --> Total execution time: 0.0802
DEBUG - 2024-02-20 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:01:55 --> Total execution time: 0.0760
DEBUG - 2024-02-20 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:01:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:01:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:01:57 --> 404 Page Not Found: Welcome/add_blog
DEBUG - 2024-02-20 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:03:01 --> Total execution time: 0.1018
DEBUG - 2024-02-20 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:03:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:03:01 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:03:39 --> Total execution time: 0.0738
DEBUG - 2024-02-20 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:03:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 11:03:39 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:03:57 --> Total execution time: 0.0661
DEBUG - 2024-02-20 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:03:57 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:03:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:04:14 --> Total execution time: 0.0731
DEBUG - 2024-02-20 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:04:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:04:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:04:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:04:37 --> Total execution time: 0.0718
DEBUG - 2024-02-20 11:04:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:04:37 --> UTF-8 Support Enabled
ERROR - 2024-02-20 11:04:37 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:04:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:07:55 --> Total execution time: 0.1315
DEBUG - 2024-02-20 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:07:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:07:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:08:00 --> Total execution time: 0.0715
DEBUG - 2024-02-20 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:08:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:08:00 --> Total execution time: 0.1747
DEBUG - 2024-02-20 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:08:05 --> Total execution time: 0.0691
DEBUG - 2024-02-20 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:08:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:08:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:08:11 --> Total execution time: 0.0793
DEBUG - 2024-02-20 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:08:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:08:11 --> Total execution time: 0.0918
DEBUG - 2024-02-20 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:09:04 --> Total execution time: 0.0740
DEBUG - 2024-02-20 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:09:04 --> UTF-8 Support Enabled
ERROR - 2024-02-20 11:09:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:09:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:09:07 --> Total execution time: 0.0985
DEBUG - 2024-02-20 11:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:09:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:09:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:11:54 --> Total execution time: 0.0877
DEBUG - 2024-02-20 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:11:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:11:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:12:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:12:49 --> Total execution time: 0.1042
DEBUG - 2024-02-20 11:12:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:12:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:12:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:12:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:13:15 --> Total execution time: 0.0982
DEBUG - 2024-02-20 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:13:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:13:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:13:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:13:17 --> Total execution time: 0.0633
DEBUG - 2024-02-20 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:13:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:13:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:13:45 --> Total execution time: 0.0958
DEBUG - 2024-02-20 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:13:45 --> UTF-8 Support Enabled
ERROR - 2024-02-20 11:13:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:13:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:13:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:14:10 --> Total execution time: 0.0851
DEBUG - 2024-02-20 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:14:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:14:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:14:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:14:10 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:16:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:16:40 --> Total execution time: 0.1014
DEBUG - 2024-02-20 11:16:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:16:41 --> UTF-8 Support Enabled
ERROR - 2024-02-20 11:16:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:16:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:17:27 --> Total execution time: 0.1163
DEBUG - 2024-02-20 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:27 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:17:29 --> Total execution time: 0.0586
DEBUG - 2024-02-20 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 11:17:29 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:17:55 --> Total execution time: 0.0839
DEBUG - 2024-02-20 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:17:56 --> Total execution time: 0.0577
DEBUG - 2024-02-20 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:17:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:18:17 --> Total execution time: 0.0968
DEBUG - 2024-02-20 11:18:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:18:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:18:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:18:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:18:31 --> Total execution time: 0.0734
DEBUG - 2024-02-20 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:18:31 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:18:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:18:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:18:37 --> Total execution time: 0.0759
DEBUG - 2024-02-20 11:18:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:18:37 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:18:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:20:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:20:10 --> Total execution time: 0.1164
DEBUG - 2024-02-20 11:20:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:20:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:20:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:20:10 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:21:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:04 --> Total execution time: 0.0691
DEBUG - 2024-02-20 11:21:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:04 --> UTF-8 Support Enabled
ERROR - 2024-02-20 11:21:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:21:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:08 --> Total execution time: 0.0656
DEBUG - 2024-02-20 11:21:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:21:08 --> Total execution time: 0.1050
DEBUG - 2024-02-20 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:12 --> Total execution time: 0.0774
DEBUG - 2024-02-20 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:12 --> Total execution time: 0.1172
DEBUG - 2024-02-20 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:16 --> Total execution time: 0.0758
DEBUG - 2024-02-20 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:19 --> Total execution time: 0.0634
DEBUG - 2024-02-20 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:19 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:48 --> Total execution time: 0.0657
DEBUG - 2024-02-20 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 11:21:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:21:50 --> Total execution time: 0.0650
DEBUG - 2024-02-20 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:21:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:22:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:22:57 --> Total execution time: 0.1107
DEBUG - 2024-02-20 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:22:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 11:22:57 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:27 --> 404 Page Not Found: Welcome/t
DEBUG - 2024-02-20 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:27 --> 404 Page Not Found: Welcome/te
DEBUG - 2024-02-20 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:27 --> 404 Page Not Found: Welcome/tes
DEBUG - 2024-02-20 11:26:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:27 --> 404 Page Not Found: Welcome/test
DEBUG - 2024-02-20 11:26:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:29 --> 404 Page Not Found: Welcome/tes
DEBUG - 2024-02-20 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:30 --> 404 Page Not Found: Welcome/te
DEBUG - 2024-02-20 11:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:30 --> 404 Page Not Found: Welcome/t
DEBUG - 2024-02-20 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:58 --> 404 Page Not Found: Welcome/t
DEBUG - 2024-02-20 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:58 --> 404 Page Not Found: Welcome/ti
DEBUG - 2024-02-20 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:58 --> 404 Page Not Found: Welcome/tit
DEBUG - 2024-02-20 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:58 --> 404 Page Not Found: Welcome/titl
DEBUG - 2024-02-20 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:26:58 --> 404 Page Not Found: Welcome/title
DEBUG - 2024-02-20 11:27:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 11:27:07 --> Severity: error --> Exception: Call to undefined method GetData::addblog() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 682
DEBUG - 2024-02-20 11:28:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 11:28:19 --> Query error: Unknown column 'thumbnail' in 'field list' - Invalid query: INSERT INTO `blogs` (`thumbnail`, `title`, `content`) VALUES ('title', NULL, '<p>test test</p>')
DEBUG - 2024-02-20 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 11:28:33 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `blogs` (`image`, `title`, `content`) VALUES ('title', NULL, '<p>test test</p>')
DEBUG - 2024-02-20 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:23 --> Total execution time: 0.1579
DEBUG - 2024-02-20 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:23 --> Total execution time: 0.1579
DEBUG - 2024-02-20 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:28 --> Total execution time: 0.0642
DEBUG - 2024-02-20 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:29 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:34 --> Total execution time: 0.0675
DEBUG - 2024-02-20 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:46 --> Total execution time: 0.0689
DEBUG - 2024-02-20 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:29:54 --> Total execution time: 0.0752
DEBUG - 2024-02-20 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:29:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:31:05 --> Total execution time: 0.0673
DEBUG - 2024-02-20 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:31:05 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 11:31:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:31:11 --> Total execution time: 0.0732
DEBUG - 2024-02-20 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:31:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:31:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:31:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:31:14 --> Total execution time: 0.0580
DEBUG - 2024-02-20 11:31:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:31:14 --> UTF-8 Support Enabled
ERROR - 2024-02-20 11:31:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:31:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:40:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:40:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:40:25 --> Total execution time: 0.0705
DEBUG - 2024-02-20 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:40:26 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:40:31 --> Total execution time: 0.0594
DEBUG - 2024-02-20 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:40:31 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 11:40:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:40:35 --> Total execution time: 0.0928
DEBUG - 2024-02-20 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:40:35 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 11:40:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:40:37 --> Total execution time: 0.0798
DEBUG - 2024-02-20 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:40:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:40:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:40:37 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:41:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:41:07 --> Total execution time: 0.0674
DEBUG - 2024-02-20 11:41:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:41:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:41:07 --> Total execution time: 0.0951
DEBUG - 2024-02-20 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:41:35 --> Total execution time: 0.0699
DEBUG - 2024-02-20 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:41:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:41:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:41:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:45:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:45:11 --> Total execution time: 0.0844
DEBUG - 2024-02-20 11:45:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:45:11 --> Total execution time: 0.0689
DEBUG - 2024-02-20 11:45:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:45:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:45:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:45:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:45:15 --> Total execution time: 0.0699
DEBUG - 2024-02-20 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:45:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:45:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:45:41 --> Total execution time: 0.0743
DEBUG - 2024-02-20 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:45:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:45:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:50:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:50:38 --> Total execution time: 0.0895
DEBUG - 2024-02-20 11:50:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:50:38 --> Total execution time: 0.0686
DEBUG - 2024-02-20 11:50:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:50:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:50:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:50:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:50:41 --> Total execution time: 0.0662
DEBUG - 2024-02-20 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:50:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:50:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 11:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 11:51:00 --> Total execution time: 0.0634
DEBUG - 2024-02-20 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:51:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 11:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 11:51:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:06:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:09 --> No URI present. Default controller set.
DEBUG - 2024-02-20 12:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:06:09 --> Total execution time: 0.0795
DEBUG - 2024-02-20 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:06:13 --> Total execution time: 0.0551
DEBUG - 2024-02-20 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:06:13 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:06:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:06:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:06:16 --> Total execution time: 0.0634
DEBUG - 2024-02-20 12:06:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:06:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 12:06:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:06:23 --> Total execution time: 0.0662
DEBUG - 2024-02-20 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:06:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:06:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:16:51 --> Total execution time: 0.0533
DEBUG - 2024-02-20 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:16:56 --> Total execution time: 0.0541
DEBUG - 2024-02-20 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:16:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:16:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:00 --> Total execution time: 0.0654
DEBUG - 2024-02-20 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 12:17:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:09 --> Total execution time: 0.0648
DEBUG - 2024-02-20 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:09 --> Total execution time: 0.0649
DEBUG - 2024-02-20 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:09 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:13 --> Total execution time: 0.0646
DEBUG - 2024-02-20 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:13 --> Total execution time: 0.0640
DEBUG - 2024-02-20 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:13 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:15 --> Total execution time: 0.0910
DEBUG - 2024-02-20 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:15 --> Total execution time: 0.0824
DEBUG - 2024-02-20 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:18 --> Total execution time: 0.0632
DEBUG - 2024-02-20 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:18 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:17:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:17:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:17:48 --> Total execution time: 0.0778
DEBUG - 2024-02-20 12:17:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:17:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:18:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:18:01 --> Total execution time: 0.0858
DEBUG - 2024-02-20 12:18:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:18:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:18:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:18:01 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:18:24 --> Total execution time: 0.0659
DEBUG - 2024-02-20 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:18:24 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:18:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:20:46 --> Total execution time: 0.1083
DEBUG - 2024-02-20 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:20:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:20:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:20:49 --> Total execution time: 0.0710
DEBUG - 2024-02-20 12:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:20:49 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:20:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:22:43 --> Total execution time: 0.0933
DEBUG - 2024-02-20 12:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:22:43 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:22:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:23:00 --> Total execution time: 0.0643
DEBUG - 2024-02-20 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:23:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 12:23:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:24:50 --> Total execution time: 0.1333
DEBUG - 2024-02-20 12:24:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:24:50 --> UTF-8 Support Enabled
ERROR - 2024-02-20 12:24:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:24:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:26:20 --> Total execution time: 0.1195
DEBUG - 2024-02-20 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:26:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:26:20 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:26:48 --> Total execution time: 0.1072
DEBUG - 2024-02-20 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:26:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:26:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:27:55 --> Total execution time: 0.1077
DEBUG - 2024-02-20 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:27:55 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:27:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:28:33 --> Total execution time: 0.1079
DEBUG - 2024-02-20 12:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:28:33 --> UTF-8 Support Enabled
ERROR - 2024-02-20 12:28:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:28:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:29:30 --> Total execution time: 0.1341
DEBUG - 2024-02-20 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:29:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 12:29:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:29:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:29:33 --> Total execution time: 0.0553
DEBUG - 2024-02-20 12:29:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:29:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:29:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:29:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:29:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:29:44 --> Total execution time: 0.0934
DEBUG - 2024-02-20 12:29:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:29:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:29:44 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:29:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:42:34 --> Total execution time: 0.0729
DEBUG - 2024-02-20 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:42:39 --> Total execution time: 0.0898
DEBUG - 2024-02-20 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:42:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:42:39 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:42:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:42:42 --> Total execution time: 0.0575
DEBUG - 2024-02-20 12:42:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:42:42 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:42:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:42:44 --> Total execution time: 0.0718
DEBUG - 2024-02-20 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:42:44 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:42:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:43:03 --> Total execution time: 0.0996
DEBUG - 2024-02-20 12:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:43:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:43:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:43:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:43:38 --> Total execution time: 0.1090
DEBUG - 2024-02-20 12:43:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:43:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:43:38 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:43:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:46:07 --> Total execution time: 0.0975
DEBUG - 2024-02-20 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:46:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:46:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:46:24 --> Total execution time: 0.0923
DEBUG - 2024-02-20 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:46:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:46:24 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:47:04 --> Total execution time: 0.1084
DEBUG - 2024-02-20 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:47:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:47:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 12:47:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:47:06 --> Total execution time: 0.0563
DEBUG - 2024-02-20 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:47:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:47:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:48:00 --> Total execution time: 0.0907
DEBUG - 2024-02-20 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:48:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:48:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:48:03 --> Total execution time: 0.0764
DEBUG - 2024-02-20 12:48:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:48:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:48:12 --> Total execution time: 0.0584
DEBUG - 2024-02-20 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:48:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:12 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:48:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:48:55 --> Total execution time: 0.0619
DEBUG - 2024-02-20 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:48:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:49:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:49:30 --> Total execution time: 0.1185
DEBUG - 2024-02-20 12:49:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:49:30 --> UTF-8 Support Enabled
ERROR - 2024-02-20 12:49:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:49:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:52:34 --> Total execution time: 0.0682
DEBUG - 2024-02-20 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:52:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:52:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:54:05 --> Total execution time: 0.0993
DEBUG - 2024-02-20 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:54:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:54:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:54:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:54:07 --> Total execution time: 0.0661
DEBUG - 2024-02-20 12:54:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:54:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:54:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:54:21 --> Total execution time: 0.0989
DEBUG - 2024-02-20 12:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:54:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:54:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:56:39 --> Total execution time: 0.0872
DEBUG - 2024-02-20 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:56:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:56:39 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:57:47 --> Total execution time: 0.1252
DEBUG - 2024-02-20 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:57:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:57:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:58:14 --> Total execution time: 0.0686
DEBUG - 2024-02-20 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:58:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:58:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:58:15 --> Total execution time: 0.0607
DEBUG - 2024-02-20 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:58:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 12:58:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:58:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 12:58:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 12:58:47 --> Total execution time: 0.1063
DEBUG - 2024-02-20 12:58:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 12:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 12:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 12:58:47 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 12:58:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:16:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:16:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:16:33 --> Total execution time: 0.0545
DEBUG - 2024-02-20 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:16:34 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 13:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:16:38 --> Total execution time: 0.0621
DEBUG - 2024-02-20 13:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:16:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 13:16:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:16:43 --> Total execution time: 0.0681
DEBUG - 2024-02-20 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:16:44 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:16:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:16:45 --> Total execution time: 0.0686
DEBUG - 2024-02-20 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:16:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:16:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:17:11 --> Total execution time: 0.0881
DEBUG - 2024-02-20 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:17:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 13:17:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:17:33 --> Total execution time: 0.0600
DEBUG - 2024-02-20 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:17:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:17:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:18:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:18:46 --> Total execution time: 0.0717
DEBUG - 2024-02-20 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:18:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:18:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:18:50 --> Total execution time: 0.0592
DEBUG - 2024-02-20 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:18:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:18:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:18:50 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 13:18:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:19:06 --> Total execution time: 0.0582
DEBUG - 2024-02-20 13:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:19:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:19:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:19:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:19:15 --> Total execution time: 0.0638
DEBUG - 2024-02-20 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:19:15 --> UTF-8 Support Enabled
ERROR - 2024-02-20 13:19:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:19:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:19:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:21:55 --> Total execution time: 0.0690
DEBUG - 2024-02-20 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:21:55 --> UTF-8 Support Enabled
ERROR - 2024-02-20 13:21:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:21:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:21:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:21:57 --> Total execution time: 0.0583
DEBUG - 2024-02-20 13:21:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:21:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:21:58 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:21:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:23:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:23:35 --> Total execution time: 0.0575
DEBUG - 2024-02-20 13:23:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:23:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:23:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:23:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:23:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:25:53 --> Total execution time: 0.0817
DEBUG - 2024-02-20 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:25:53 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:25:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:26:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:26:09 --> Total execution time: 0.0671
DEBUG - 2024-02-20 13:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:26:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:26:09 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:26:16 --> Total execution time: 0.0654
DEBUG - 2024-02-20 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:26:16 --> Total execution time: 0.0658
DEBUG - 2024-02-20 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:26:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:26:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:26:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:26:22 --> Total execution time: 0.0666
DEBUG - 2024-02-20 13:26:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:26:22 --> Total execution time: 0.0630
DEBUG - 2024-02-20 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:26:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:26:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:26:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:27:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:27:56 --> No URI present. Default controller set.
DEBUG - 2024-02-20 13:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:27:56 --> Total execution time: 0.0787
DEBUG - 2024-02-20 13:27:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:27:56 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 13:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:00 --> Total execution time: 0.0571
DEBUG - 2024-02-20 13:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:28:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:20 --> Total execution time: 0.0645
DEBUG - 2024-02-20 13:28:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:28:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:28:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:23 --> Total execution time: 0.0759
DEBUG - 2024-02-20 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 13:28:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:26 --> Total execution time: 0.0785
DEBUG - 2024-02-20 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:28:26 --> Total execution time: 0.0771
DEBUG - 2024-02-20 13:28:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:30 --> Total execution time: 0.0677
DEBUG - 2024-02-20 13:28:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:32 --> Total execution time: 0.1196
DEBUG - 2024-02-20 13:28:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:32 --> Total execution time: 0.1057
DEBUG - 2024-02-20 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:28:58 --> Total execution time: 0.0624
DEBUG - 2024-02-20 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:28:58 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:29:39 --> Total execution time: 0.0801
DEBUG - 2024-02-20 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:39 --> UTF-8 Support Enabled
ERROR - 2024-02-20 13:29:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:39 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:29:47 --> Total execution time: 0.0837
DEBUG - 2024-02-20 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:29:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:29:51 --> Total execution time: 0.0627
DEBUG - 2024-02-20 13:29:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:29:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:29:55 --> Total execution time: 0.0840
DEBUG - 2024-02-20 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 13:29:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:29:59 --> Total execution time: 0.0691
DEBUG - 2024-02-20 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:29:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:29:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:30:02 --> Total execution time: 0.0794
DEBUG - 2024-02-20 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:30:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:02 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:30:06 --> Total execution time: 0.0633
DEBUG - 2024-02-20 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:30:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-20 13:30:46 --> Query error: Table 'habitro.blog' doesn't exist - Invalid query: SELECT `id`
FROM `blog`
DEBUG - 2024-02-20 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:30:50 --> Total execution time: 0.1333
DEBUG - 2024-02-20 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:30:58 --> Total execution time: 0.1730
DEBUG - 2024-02-20 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:30:58 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:31:16 --> Total execution time: 0.1343
DEBUG - 2024-02-20 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:31:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:31:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:33:16 --> Total execution time: 0.1023
DEBUG - 2024-02-20 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:33:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:33:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:51:39 --> Total execution time: 0.0673
DEBUG - 2024-02-20 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:51:43 --> Total execution time: 0.0873
DEBUG - 2024-02-20 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:51:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:51:44 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:52:15 --> Total execution time: 0.0698
DEBUG - 2024-02-20 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:52:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:52:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:53:12 --> Total execution time: 0.1184
DEBUG - 2024-02-20 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:12 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:53:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:53:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:53:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:53:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:33 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 13:53:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:53:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:53:55 --> Total execution time: 0.0989
DEBUG - 2024-02-20 13:53:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:55 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:56 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:53:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:54:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:54:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:54:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 13:54:19 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:54:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:54:19 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:54:20 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:54:20 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:55:07 --> Total execution time: 0.0946
DEBUG - 2024-02-20 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:55:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:55:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:55:08 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:55:08 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:55:08 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:58:32 --> Total execution time: 0.1038
DEBUG - 2024-02-20 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:58:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:58:32 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:58:33 --> UTF-8 Support Enabled
ERROR - 2024-02-20 13:58:33 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-20 13:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:58:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:58:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-20 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:58:53 --> Total execution time: 0.0664
DEBUG - 2024-02-20 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:58:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:58:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:58:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:58:53 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:59:38 --> Total execution time: 0.0879
DEBUG - 2024-02-20 13:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:59:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:59:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:59:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:59:51 --> Total execution time: 0.1911
DEBUG - 2024-02-20 13:59:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:59:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 13:59:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 13:59:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 13:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 13:59:57 --> Total execution time: 0.1714
DEBUG - 2024-02-20 13:59:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:59:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 13:59:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 13:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 13:59:57 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:00:00 --> Total execution time: 0.1017
DEBUG - 2024-02-20 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:00:23 --> Total execution time: 0.1061
DEBUG - 2024-02-20 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:00:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:00:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:00:25 --> Total execution time: 0.0625
DEBUG - 2024-02-20 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:00:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:00:25 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:00:27 --> Total execution time: 0.0760
DEBUG - 2024-02-20 14:01:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:01:38 --> Total execution time: 0.1122
DEBUG - 2024-02-20 14:01:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:01:38 --> UTF-8 Support Enabled
ERROR - 2024-02-20 14:01:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:01:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:02:00 --> Total execution time: 0.0856
DEBUG - 2024-02-20 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:02:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 14:02:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:28:26 --> Total execution time: 0.0698
DEBUG - 2024-02-20 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:28:30 --> Total execution time: 0.0819
DEBUG - 2024-02-20 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:28:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:28:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:29:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:29:31 --> Total execution time: 0.0969
DEBUG - 2024-02-20 14:29:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:29:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:29:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:29:31 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:30:04 --> Total execution time: 0.1027
DEBUG - 2024-02-20 14:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:30:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:30:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:31:45 --> Total execution time: 0.1083
DEBUG - 2024-02-20 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:31:45 --> UTF-8 Support Enabled
ERROR - 2024-02-20 14:31:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:31:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:32:19 --> Total execution time: 0.1086
DEBUG - 2024-02-20 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:32:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:32:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-20 14:32:19 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:33:00 --> Total execution time: 0.1114
DEBUG - 2024-02-20 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:33:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:33:01 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:33:37 --> Total execution time: 0.1088
DEBUG - 2024-02-20 14:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:33:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:33:37 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-20 14:33:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:35:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:35:37 --> Total execution time: 0.0825
DEBUG - 2024-02-20 14:35:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:35:37 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:35:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:35:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:35:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:35:43 --> Total execution time: 0.0859
DEBUG - 2024-02-20 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:35:49 --> Total execution time: 0.0627
DEBUG - 2024-02-20 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:35:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:35:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:37:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:37:30 --> Total execution time: 0.1054
DEBUG - 2024-02-20 14:37:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:37:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:37:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:37:50 --> Total execution time: 0.0919
DEBUG - 2024-02-20 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:37:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:37:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:37:58 --> Total execution time: 0.1311
DEBUG - 2024-02-20 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:37:58 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:37:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:38:07 --> Total execution time: 0.0809
DEBUG - 2024-02-20 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:38:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:38:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:40:06 --> Total execution time: 0.1481
DEBUG - 2024-02-20 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:40:06 --> UTF-8 Support Enabled
ERROR - 2024-02-20 14:40:06 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:06 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:40:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:40:22 --> Total execution time: 0.1105
DEBUG - 2024-02-20 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:40:23 --> UTF-8 Support Enabled
ERROR - 2024-02-20 14:40:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:23 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:23 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:40:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:40:28 --> Total execution time: 0.0759
DEBUG - 2024-02-20 14:40:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:40:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:28 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:40:28 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:41:09 --> Total execution time: 0.1316
DEBUG - 2024-02-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:41:09 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:41:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:41:09 --> 404 Page Not Found: Vendor/toastr
ERROR - 2024-02-20 14:41:09 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:41:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:41:09 --> 404 Page Not Found: Js/plugins_init
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            DEBUG - 2024-02-20 14:44:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:44:59 --> No URI present. Default controller set.
DEBUG - 2024-02-20 14:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:44:59 --> Total execution time: 0.3154
DEBUG - 2024-02-20 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:45:00 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 14:45:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:45:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:45:04 --> Total execution time: 0.0825
DEBUG - 2024-02-20 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:45:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:45:05 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:45:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-20 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:45:05 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:45:05 --> 404 Page Not Found: Js/plugins_init
DEBUG - 2024-02-20 14:48:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:48:33 --> Total execution time: 0.1207
DEBUG - 2024-02-20 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:48:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:48:33 --> 404 Page Not Found: Vendor/toastr
ERROR - 2024-02-20 14:48:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:48:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:48:33 --> 404 Page Not Found: Js/plugins_init
DEBUG - 2024-02-20 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:48:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:48:33 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:49:18 --> Total execution time: 0.0832
DEBUG - 2024-02-20 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:49:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:49:18 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:49:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:49:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:49:19 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:49:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:49:19 --> 404 Page Not Found: Js/plugins_init
DEBUG - 2024-02-20 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:00 --> Total execution time: 0.1201
DEBUG - 2024-02-20 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:00 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:00 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:04 --> Total execution time: 0.0670
DEBUG - 2024-02-20 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:04 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:04 --> 404 Page Not Found: Vendor/toastr
DEBUG - 2024-02-20 14:51:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:29 --> Total execution time: 0.1055
DEBUG - 2024-02-20 14:51:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:51:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:48 --> Total execution time: 0.0771
DEBUG - 2024-02-20 14:51:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:52 --> Total execution time: 0.0561
DEBUG - 2024-02-20 14:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:51:55 --> Total execution time: 0.0563
DEBUG - 2024-02-20 14:51:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:51:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:51:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:52:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:52:13 --> Total execution time: 0.0846
DEBUG - 2024-02-20 14:52:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:52:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:52:17 --> Total execution time: 0.0651
DEBUG - 2024-02-20 14:52:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:52:22 --> Total execution time: 0.0680
DEBUG - 2024-02-20 14:52:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:52:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:52:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:52:34 --> Total execution time: 0.9573
DEBUG - 2024-02-20 14:52:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:52:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:55:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:55:13 --> Total execution time: 0.0950
DEBUG - 2024-02-20 14:55:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:55:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:55:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:55:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:55:17 --> Total execution time: 0.0818
DEBUG - 2024-02-20 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:55:22 --> Total execution time: 0.0548
DEBUG - 2024-02-20 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:55:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:56:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:56:24 --> Total execution time: 0.0906
DEBUG - 2024-02-20 14:56:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:56:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:56:28 --> Total execution time: 0.0558
DEBUG - 2024-02-20 14:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:56:31 --> Total execution time: 0.0591
DEBUG - 2024-02-20 14:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:56:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:57:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:57:49 --> Total execution time: 0.1082
DEBUG - 2024-02-20 14:57:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:57:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:57:52 --> Total execution time: 0.0817
DEBUG - 2024-02-20 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:57:55 --> Total execution time: 0.0580
DEBUG - 2024-02-20 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:57:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:58:36 --> Total execution time: 0.0980
DEBUG - 2024-02-20 14:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:58:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:59:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:26 --> Total execution time: 0.1048
DEBUG - 2024-02-20 14:59:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:59:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:29 --> Total execution time: 0.0724
DEBUG - 2024-02-20 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:35 --> Total execution time: 0.0569
DEBUG - 2024-02-20 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:59:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:59:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:50 --> Total execution time: 0.0793
DEBUG - 2024-02-20 14:59:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:59:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:53 --> Total execution time: 0.0584
DEBUG - 2024-02-20 14:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 14:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 14:59:56 --> Total execution time: 0.0522
DEBUG - 2024-02-20 14:59:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 14:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 14:59:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:00:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:00:45 --> Total execution time: 0.1185
DEBUG - 2024-02-20 15:00:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:00:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:00:49 --> Total execution time: 0.0535
DEBUG - 2024-02-20 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:00:54 --> Total execution time: 0.0622
DEBUG - 2024-02-20 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:00:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:01:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:01:24 --> Total execution time: 0.0793
DEBUG - 2024-02-20 15:01:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:01:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:02:14 --> Total execution time: 0.1107
DEBUG - 2024-02-20 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:02:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:02:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:02:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:02:17 --> Total execution time: 0.0519
DEBUG - 2024-02-20 15:02:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:02:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:02:23 --> Total execution time: 0.0510
DEBUG - 2024-02-20 15:02:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:02:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:02:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:03:05 --> Total execution time: 0.0524
DEBUG - 2024-02-20 15:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:03:10 --> Total execution time: 0.0535
DEBUG - 2024-02-20 15:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:03:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:04:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:04:15 --> Total execution time: 0.0980
DEBUG - 2024-02-20 15:04:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:04:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:04:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:04:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:04:18 --> Total execution time: 0.0608
DEBUG - 2024-02-20 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:04:23 --> Total execution time: 0.0540
DEBUG - 2024-02-20 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:04:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:05:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:05:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:05:58 --> Total execution time: 0.0762
DEBUG - 2024-02-20 15:06:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:06:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:06:03 --> Total execution time: 0.0869
DEBUG - 2024-02-20 15:06:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:06:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:06:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:06:52 --> Total execution time: 0.0625
DEBUG - 2024-02-20 15:06:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:06:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:06:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:06:54 --> Total execution time: 0.0656
DEBUG - 2024-02-20 15:06:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:06:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:07:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:07:00 --> Total execution time: 0.0583
DEBUG - 2024-02-20 15:07:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:07:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:07:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:07:34 --> Total execution time: 0.0949
DEBUG - 2024-02-20 15:07:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:07:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:07:57 --> Total execution time: 0.0576
DEBUG - 2024-02-20 15:08:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:08:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:08:03 --> Total execution time: 0.0930
DEBUG - 2024-02-20 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:08:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:08:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:08:11 --> Total execution time: 0.0557
DEBUG - 2024-02-20 15:08:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:08:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:08:39 --> Total execution time: 0.0594
DEBUG - 2024-02-20 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:08:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:10:08 --> Total execution time: 0.0647
DEBUG - 2024-02-20 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:10:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:11:41 --> Total execution time: 0.0892
DEBUG - 2024-02-20 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:11:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:11:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:11:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:11:49 --> Total execution time: 0.0648
DEBUG - 2024-02-20 15:11:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:11:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:11:53 --> Total execution time: 0.0599
DEBUG - 2024-02-20 15:11:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:11:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:12:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:12:27 --> Total execution time: 0.0977
DEBUG - 2024-02-20 15:12:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:12:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:12:30 --> Total execution time: 0.0585
DEBUG - 2024-02-20 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:12:35 --> Total execution time: 0.0528
DEBUG - 2024-02-20 15:12:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:12:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:13:31 --> Total execution time: 0.0935
DEBUG - 2024-02-20 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:13:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:13:34 --> Total execution time: 0.0656
DEBUG - 2024-02-20 15:13:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:13:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:13:39 --> Total execution time: 0.0561
DEBUG - 2024-02-20 15:13:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:13:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:13:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:16:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:16:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:16:02 --> Total execution time: 0.0675
DEBUG - 2024-02-20 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:16:03 --> Total execution time: 0.0566
DEBUG - 2024-02-20 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:16:08 --> Total execution time: 0.1008
DEBUG - 2024-02-20 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:16:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:17:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:05 --> Total execution time: 0.1272
DEBUG - 2024-02-20 15:17:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:17:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:07 --> Total execution time: 0.0702
DEBUG - 2024-02-20 15:17:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:12 --> Total execution time: 0.0975
DEBUG - 2024-02-20 15:17:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:17:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:45 --> Total execution time: 0.0642
DEBUG - 2024-02-20 15:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:17:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:17:59 --> Total execution time: 0.0609
DEBUG - 2024-02-20 15:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:17:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:10 --> Total execution time: 0.1045
DEBUG - 2024-02-20 15:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:18:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:35 --> Total execution time: 0.0591
DEBUG - 2024-02-20 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:18:36 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-20 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:39 --> Total execution time: 0.0783
DEBUG - 2024-02-20 15:18:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:18:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:56 --> Total execution time: 0.0757
DEBUG - 2024-02-20 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:18:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:18:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:18:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:00 --> Total execution time: 0.0617
DEBUG - 2024-02-20 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:05 --> Total execution time: 0.0549
DEBUG - 2024-02-20 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:19:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:19:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:30 --> Total execution time: 0.0718
DEBUG - 2024-02-20 15:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:36 --> Total execution time: 0.0564
DEBUG - 2024-02-20 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:19:44 --> Total execution time: 0.0814
DEBUG - 2024-02-20 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:19:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:21:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:21:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:21:24 --> Total execution time: 0.0603
DEBUG - 2024-02-20 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:21:40 --> Total execution time: 0.0752
DEBUG - 2024-02-20 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:21:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-20 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:33:23 --> Total execution time: 0.0715
DEBUG - 2024-02-20 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-20 15:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-20 15:33:35 --> Total execution time: 0.0597
DEBUG - 2024-02-20 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-20 15:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-20 15:33:35 --> 404 Page Not Found: Assets/datatables

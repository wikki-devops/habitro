<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-04 07:59:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 07:59:41 --> No URI present. Default controller set.
DEBUG - 2024-03-04 07:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 07:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 07:59:41 --> Total execution time: 0.1323
DEBUG - 2024-03-04 07:59:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 07:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 07:59:42 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-04 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 08:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 08:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 08:55:29 --> Total execution time: 0.2720
DEBUG - 2024-03-04 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 08:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 08:55:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 08:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 08:55:46 --> Total execution time: 0.1050
DEBUG - 2024-03-04 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 08:55:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 08:55:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:15:20 --> Total execution time: 0.0613
DEBUG - 2024-03-04 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:15:20 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-04 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:15:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:15:26 --> Total execution time: 0.0625
DEBUG - 2024-03-04 09:15:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:15:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:15:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:19:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:19:13 --> Total execution time: 0.1530
DEBUG - 2024-03-04 09:19:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:19:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:21:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:21:47 --> Total execution time: 0.1129
DEBUG - 2024-03-04 09:21:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:21:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:21:51 --> Total execution time: 0.0723
DEBUG - 2024-03-04 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:21:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:21:55 --> Total execution time: 0.0737
DEBUG - 2024-03-04 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:21:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:21:58 --> Total execution time: 0.0545
DEBUG - 2024-03-04 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:22:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:22:04 --> Total execution time: 0.0569
DEBUG - 2024-03-04 09:22:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:22:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:22:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:22:08 --> Total execution time: 0.0731
DEBUG - 2024-03-04 09:22:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:22:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:28:01 --> Total execution time: 0.0681
DEBUG - 2024-03-04 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:28:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:28:06 --> Total execution time: 0.1244
DEBUG - 2024-03-04 09:28:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:28:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:28:08 --> Total execution time: 0.0706
DEBUG - 2024-03-04 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:28:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:28:11 --> Total execution time: 0.0590
DEBUG - 2024-03-04 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:28:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:29:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:29:07 --> Total execution time: 0.0652
DEBUG - 2024-03-04 09:29:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:29:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:29:10 --> Total execution time: 0.0767
DEBUG - 2024-03-04 09:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:29:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:30:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:30:46 --> Total execution time: 0.0659
DEBUG - 2024-03-04 09:30:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:30:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:30:52 --> Total execution time: 0.0648
DEBUG - 2024-03-04 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:30:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:31:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:31:33 --> Total execution time: 0.0701
DEBUG - 2024-03-04 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:31:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:31:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:32:08 --> Total execution time: 0.1246
DEBUG - 2024-03-04 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:32:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:32:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:32:19 --> Total execution time: 0.0942
DEBUG - 2024-03-04 09:32:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:32:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:32:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:32:22 --> Total execution time: 0.0694
DEBUG - 2024-03-04 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:32:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:33:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:33:03 --> Total execution time: 0.0885
DEBUG - 2024-03-04 09:33:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:33:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:33:52 --> Total execution time: 0.0539
DEBUG - 2024-03-04 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:34:00 --> Total execution time: 0.0591
DEBUG - 2024-03-04 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:34:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:34:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:59:36 --> Total execution time: 0.0703
DEBUG - 2024-03-04 09:59:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:59:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:59:41 --> Total execution time: 0.0564
DEBUG - 2024-03-04 09:59:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:59:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 09:59:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 09:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 09:59:44 --> Total execution time: 0.0780
DEBUG - 2024-03-04 09:59:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 09:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 09:59:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:41 --> Total execution time: 0.0668
DEBUG - 2024-03-04 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:46 --> Total execution time: 0.0491
DEBUG - 2024-03-04 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:04:46 --> 404 Page Not Found: Welcome/images
DEBUG - 2024-03-04 10:04:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:51 --> Total execution time: 0.0547
DEBUG - 2024-03-04 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:04:55 --> Total execution time: 0.0517
DEBUG - 2024-03-04 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:05:49 --> Total execution time: 0.0652
DEBUG - 2024-03-04 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:05:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:08:07 --> Total execution time: 0.0651
DEBUG - 2024-03-04 10:08:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:08:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:08:12 --> Total execution time: 0.0610
DEBUG - 2024-03-04 10:08:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:08:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:09:08 --> Total execution time: 0.0666
DEBUG - 2024-03-04 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:09:13 --> Total execution time: 0.0546
DEBUG - 2024-03-04 10:09:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:09:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:09:15 --> Total execution time: 0.0926
DEBUG - 2024-03-04 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:09:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:09:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:09:37 --> Total execution time: 0.0763
DEBUG - 2024-03-04 10:09:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:09:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:10:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:10:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:10:12 --> Total execution time: 0.1342
DEBUG - 2024-03-04 10:10:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:10:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:10:16 --> Total execution time: 0.0588
DEBUG - 2024-03-04 10:10:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:10:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:11:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:04 --> Total execution time: 0.0617
DEBUG - 2024-03-04 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:08 --> Total execution time: 0.0555
DEBUG - 2024-03-04 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:11:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:11:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:11 --> Total execution time: 0.0793
DEBUG - 2024-03-04 10:11:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:11:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:11:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:49 --> Total execution time: 0.0694
DEBUG - 2024-03-04 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:11:54 --> Total execution time: 0.0541
DEBUG - 2024-03-04 10:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:11:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:12:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:12:04 --> Total execution time: 0.0632
DEBUG - 2024-03-04 10:12:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:12:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:13:45 --> Total execution time: 0.0503
DEBUG - 2024-03-04 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:13:50 --> Total execution time: 0.0580
DEBUG - 2024-03-04 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:13:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:14:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:14:27 --> Total execution time: 0.0650
DEBUG - 2024-03-04 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:14:32 --> Total execution time: 0.0573
DEBUG - 2024-03-04 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:14:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:14:34 --> Total execution time: 0.0964
DEBUG - 2024-03-04 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:14:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:16:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:16:13 --> Total execution time: 0.0646
DEBUG - 2024-03-04 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:16:18 --> Total execution time: 0.0582
DEBUG - 2024-03-04 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:16:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:20:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:20:45 --> Total execution time: 0.0686
DEBUG - 2024-03-04 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:20:49 --> Total execution time: 0.0532
DEBUG - 2024-03-04 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:25:50 --> Total execution time: 0.0575
DEBUG - 2024-03-04 10:27:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:27:06 --> No URI present. Default controller set.
DEBUG - 2024-03-04 10:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:27:06 --> Total execution time: 0.1205
DEBUG - 2024-03-04 10:27:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:27:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:27:15 --> Total execution time: 0.0532
DEBUG - 2024-03-04 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:00 --> No URI present. Default controller set.
DEBUG - 2024-03-04 10:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:00 --> Total execution time: 0.1235
DEBUG - 2024-03-04 10:28:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:04 --> No URI present. Default controller set.
DEBUG - 2024-03-04 10:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:04 --> Total execution time: 0.0530
DEBUG - 2024-03-04 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:08 --> No URI present. Default controller set.
DEBUG - 2024-03-04 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:08 --> Total execution time: 0.0578
DEBUG - 2024-03-04 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:13 --> Total execution time: 0.0698
DEBUG - 2024-03-04 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:28:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:28:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:16 --> Total execution time: 0.0739
DEBUG - 2024-03-04 10:28:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:28:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:28:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:20 --> Total execution time: 0.0582
DEBUG - 2024-03-04 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:24 --> Total execution time: 0.0532
DEBUG - 2024-03-04 10:28:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:26 --> Total execution time: 0.0699
DEBUG - 2024-03-04 10:28:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:28 --> Total execution time: 0.0832
DEBUG - 2024-03-04 10:28:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:28:40 --> Total execution time: 0.0927
DEBUG - 2024-03-04 10:28:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:28:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:29:24 --> Total execution time: 0.0719
DEBUG - 2024-03-04 10:29:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:29:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:29:27 --> Total execution time: 0.0550
DEBUG - 2024-03-04 10:29:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:29:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:33:20 --> Total execution time: 0.0675
DEBUG - 2024-03-04 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:33:29 --> Total execution time: 0.0830
DEBUG - 2024-03-04 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:33:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:33:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:33:32 --> 404 Page Not Found: Welcome/pricing
DEBUG - 2024-03-04 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:33:48 --> Total execution time: 0.0878
DEBUG - 2024-03-04 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:33:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:33:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:34:17 --> Total execution time: 0.0765
DEBUG - 2024-03-04 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:34:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:34:51 --> Total execution time: 0.1096
DEBUG - 2024-03-04 10:34:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:34:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 10:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 10:35:01 --> Total execution time: 0.0790
DEBUG - 2024-03-04 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 10:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 10:35:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:31:54 --> Total execution time: 0.0521
DEBUG - 2024-03-04 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:32:00 --> Total execution time: 0.0533
DEBUG - 2024-03-04 11:32:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:32:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:32:05 --> Total execution time: 0.0618
DEBUG - 2024-03-04 11:32:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:32:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:32:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:32:10 --> Total execution time: 0.1184
DEBUG - 2024-03-04 11:32:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:32:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:32:50 --> Total execution time: 0.0942
DEBUG - 2024-03-04 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:32:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:38:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:38:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:38:38 --> Total execution time: 0.0678
DEBUG - 2024-03-04 11:38:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:38:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:38:42 --> Total execution time: 0.0547
DEBUG - 2024-03-04 11:38:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:38:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:38:46 --> Total execution time: 0.0953
DEBUG - 2024-03-04 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:38:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:39:17 --> Total execution time: 0.0958
DEBUG - 2024-03-04 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:39:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:39:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:39:40 --> Total execution time: 0.0903
DEBUG - 2024-03-04 11:39:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:39:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:39:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:39:45 --> Total execution time: 0.1301
DEBUG - 2024-03-04 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:39:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:40:04 --> Total execution time: 0.0911
DEBUG - 2024-03-04 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:40:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:40:38 --> Total execution time: 0.1066
DEBUG - 2024-03-04 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:40:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:40:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:41:13 --> Total execution time: 0.1000
DEBUG - 2024-03-04 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:41:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:41:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:41:27 --> Total execution time: 0.0839
DEBUG - 2024-03-04 11:41:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:41:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:41:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:41:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:41:47 --> Total execution time: 0.1189
DEBUG - 2024-03-04 11:41:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:41:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:26 --> Total execution time: 0.0584
DEBUG - 2024-03-04 11:44:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:29 --> Total execution time: 0.0567
DEBUG - 2024-03-04 11:44:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:44:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:32 --> Total execution time: 0.0709
DEBUG - 2024-03-04 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:44:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:44:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:36 --> Total execution time: 0.0670
DEBUG - 2024-03-04 11:44:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:44:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:44:50 --> Total execution time: 0.0881
DEBUG - 2024-03-04 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:44:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 11:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 11:45:05 --> Total execution time: 0.0801
DEBUG - 2024-03-04 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 11:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 11:45:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:46:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:46:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:46:40 --> Total execution time: 0.0538
DEBUG - 2024-03-04 15:46:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:46:40 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-04 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:46:44 --> Total execution time: 0.0582
DEBUG - 2024-03-04 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:46:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-04 15:46:49 --> Severity: Notice --> Undefined variable: pricing C:\xampp\htdocs\habitro\admin\application\views\pricing.php 74
ERROR - 2024-03-04 15:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\pricing.php 74
DEBUG - 2024-03-04 15:46:49 --> Total execution time: 0.1100
DEBUG - 2024-03-04 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:46:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:47:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-04 15:47:47 --> Query error: Table 'habitro.pricing' doesn't exist - Invalid query: SELECT *
FROM `pricing`
DEBUG - 2024-03-04 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:48:04 --> Total execution time: 0.0938
DEBUG - 2024-03-04 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:48:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:48:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:48:33 --> Total execution time: 0.0854
DEBUG - 2024-03-04 15:48:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:48:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:48:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:54:56 --> Total execution time: 0.0487
DEBUG - 2024-03-04 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:55:02 --> Total execution time: 0.0611
DEBUG - 2024-03-04 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:55:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:55:04 --> Total execution time: 0.0892
DEBUG - 2024-03-04 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:55:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:57:11 --> Total execution time: 0.0960
DEBUG - 2024-03-04 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:57:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:58:58 --> Total execution time: 0.1170
DEBUG - 2024-03-04 15:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:58:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:58:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:59:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:59:28 --> Total execution time: 0.1113
DEBUG - 2024-03-04 15:59:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:59:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 15:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 15:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 15:59:53 --> Total execution time: 0.1127
DEBUG - 2024-03-04 15:59:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 15:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 15:59:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 16:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 16:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 16:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 16:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 16:00:21 --> Total execution time: 0.0488
DEBUG - 2024-03-04 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 16:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 16:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 16:00:25 --> Total execution time: 0.0519
DEBUG - 2024-03-04 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 16:00:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 16:00:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 16:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 16:00:28 --> Total execution time: 0.1192
DEBUG - 2024-03-04 16:00:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 16:00:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-04 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-04 16:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-04 16:01:41 --> Total execution time: 0.0754
DEBUG - 2024-03-04 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-04 16:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-04 16:01:41 --> 404 Page Not Found: Assets/datatables

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-18 07:29:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:03 --> No URI present. Default controller set.
DEBUG - 2024-03-18 07:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:29:03 --> Total execution time: 0.0907
DEBUG - 2024-03-18 07:29:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:29:04 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-18 07:29:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:29:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:29:09 --> Total execution time: 0.0808
DEBUG - 2024-03-18 07:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:29:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:29:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:29:12 --> Total execution time: 0.0774
DEBUG - 2024-03-18 07:29:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:29:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:29:19 --> Total execution time: 0.0885
DEBUG - 2024-03-18 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:29:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:30:09 --> Total execution time: 0.1939
DEBUG - 2024-03-18 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:30:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:30:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:30:33 --> Total execution time: 0.1328
DEBUG - 2024-03-18 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:30:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:30:49 --> Total execution time: 0.1344
DEBUG - 2024-03-18 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:30:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:33:11 --> Total execution time: 0.7800
DEBUG - 2024-03-18 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:33:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 07:33:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 07:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 07:33:58 --> Total execution time: 0.0580
DEBUG - 2024-03-18 07:33:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 07:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 07:33:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:04:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:33 --> No URI present. Default controller set.
DEBUG - 2024-03-18 10:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:04:33 --> Total execution time: 0.1855
DEBUG - 2024-03-18 10:04:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:04:34 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-18 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:04:37 --> Total execution time: 0.0898
DEBUG - 2024-03-18 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:04:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:04:41 --> Total execution time: 0.2327
DEBUG - 2024-03-18 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:04:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:04:45 --> Total execution time: 0.0603
DEBUG - 2024-03-18 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:04:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:05:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:05:42 --> Total execution time: 0.1545
DEBUG - 2024-03-18 10:05:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:05:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:06:10 --> Total execution time: 0.1203
DEBUG - 2024-03-18 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:06:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:06:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:06:12 --> Total execution time: 0.0750
DEBUG - 2024-03-18 10:06:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:06:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:06:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:06:49 --> Total execution time: 0.1461
DEBUG - 2024-03-18 10:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:06:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:06:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:07:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:07:06 --> Total execution time: 0.0568
DEBUG - 2024-03-18 10:07:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:07:25 --> Total execution time: 0.1312
DEBUG - 2024-03-18 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:50 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-18 10:07:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:51 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-18 10:07:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:51 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-18 10:07:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:07:51 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-18 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:09:43 --> Total execution time: 0.1453
DEBUG - 2024-03-18 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:09:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:09:43 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-18 10:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:09:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-18 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:09:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-18 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:09:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:09:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-18 10:10:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:10:06 --> Total execution time: 0.1211
DEBUG - 2024-03-18 10:10:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:10:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:10:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:10:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:10:53 --> Total execution time: 0.1455
DEBUG - 2024-03-18 10:10:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:10:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:11:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:11:21 --> Total execution time: 0.1153
DEBUG - 2024-03-18 10:11:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:11:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:11:30 --> Total execution time: 0.1193
DEBUG - 2024-03-18 10:11:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:11:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:11:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:11:58 --> Total execution time: 0.1217
DEBUG - 2024-03-18 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:11:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:12:17 --> Total execution time: 0.1276
DEBUG - 2024-03-18 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:12:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:12:25 --> Total execution time: 0.1297
DEBUG - 2024-03-18 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:12:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:12:30 --> Total execution time: 0.1107
DEBUG - 2024-03-18 10:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:12:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:13:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:13:01 --> Total execution time: 0.1156
DEBUG - 2024-03-18 10:13:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:13:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:13:52 --> Total execution time: 0.1218
DEBUG - 2024-03-18 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:13:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:14:01 --> Total execution time: 0.1266
DEBUG - 2024-03-18 10:14:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:14:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:14:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:14:27 --> Total execution time: 0.1334
DEBUG - 2024-03-18 10:14:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:14:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:14:51 --> Total execution time: 0.1256
DEBUG - 2024-03-18 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:14:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:15:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:15:02 --> Total execution time: 0.1261
DEBUG - 2024-03-18 10:15:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:15:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:15:41 --> Total execution time: 0.1292
DEBUG - 2024-03-18 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:15:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:15:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:15:49 --> Total execution time: 0.1287
DEBUG - 2024-03-18 10:15:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:15:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:16:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:16:20 --> Total execution time: 0.2282
DEBUG - 2024-03-18 10:16:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:16:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:16:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:16:53 --> Total execution time: 0.1332
DEBUG - 2024-03-18 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:16:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:18:36 --> Total execution time: 0.0999
DEBUG - 2024-03-18 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:18:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:19:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:19:15 --> Total execution time: 0.0670
DEBUG - 2024-03-18 10:19:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:19:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:19:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:19:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:19:29 --> Total execution time: 0.0915
DEBUG - 2024-03-18 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:19:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:20:14 --> Total execution time: 0.1201
DEBUG - 2024-03-18 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:20:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:20:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:20:26 --> Total execution time: 0.0898
DEBUG - 2024-03-18 10:20:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:20:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:23:19 --> Total execution time: 0.1204
DEBUG - 2024-03-18 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:23:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:24:09 --> Total execution time: 0.1135
DEBUG - 2024-03-18 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:24:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:24:20 --> Total execution time: 0.0991
DEBUG - 2024-03-18 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:24:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:25:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:25:06 --> Total execution time: 0.1254
DEBUG - 2024-03-18 10:25:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:25:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:25:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:25:56 --> Total execution time: 0.1461
DEBUG - 2024-03-18 10:25:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:25:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:26:09 --> Total execution time: 0.1074
DEBUG - 2024-03-18 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:26:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:26:30 --> Total execution time: 0.1133
DEBUG - 2024-03-18 10:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:26:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:38:10 --> Total execution time: 0.0745
DEBUG - 2024-03-18 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:38:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:38:12 --> Total execution time: 0.0594
DEBUG - 2024-03-18 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:38:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:38:19 --> Total execution time: 0.0678
DEBUG - 2024-03-18 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:38:19 --> Total execution time: 0.0560
DEBUG - 2024-03-18 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:38:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:43:19 --> Total execution time: 0.0657
DEBUG - 2024-03-18 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:43:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:47:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:47:45 --> Total execution time: 0.0863
DEBUG - 2024-03-18 10:47:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:47:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:47:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:47:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:47:48 --> Total execution time: 0.0889
DEBUG - 2024-03-18 10:47:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:47:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:47:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:58:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:35 --> No URI present. Default controller set.
DEBUG - 2024-03-18 10:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:58:35 --> Total execution time: 0.0590
DEBUG - 2024-03-18 10:58:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:58:35 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-18 10:58:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:58:39 --> Total execution time: 0.0587
DEBUG - 2024-03-18 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:58:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:58:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:58:41 --> Total execution time: 0.0851
DEBUG - 2024-03-18 10:58:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:58:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:58:43 --> Total execution time: 0.0734
DEBUG - 2024-03-18 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:58:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 10:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 10:58:45 --> Total execution time: 0.0849
DEBUG - 2024-03-18 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 10:58:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 10:58:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:00:19 --> Total execution time: 0.0834
DEBUG - 2024-03-18 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:00:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:00:40 --> Total execution time: 0.0572
DEBUG - 2024-03-18 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:00:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:27:47 --> Total execution time: 0.0806
DEBUG - 2024-03-18 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:27:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:31:32 --> Total execution time: 0.0673
DEBUG - 2024-03-18 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:31:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:31:34 --> Total execution time: 0.1009
DEBUG - 2024-03-18 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:31:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:31:36 --> Total execution time: 0.0717
DEBUG - 2024-03-18 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:31:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:31:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:31:46 --> Total execution time: 0.0627
DEBUG - 2024-03-18 11:31:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-18 11:31:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-18 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-18 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-18 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-18 11:49:23 --> Total execution time: 0.0589

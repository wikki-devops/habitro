<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-07 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:42 --> No URI present. Default controller set.
DEBUG - 2024-03-07 07:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:33:42 --> Total execution time: 0.0925
DEBUG - 2024-03-07 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:33:42 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-07 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:33:46 --> Total execution time: 0.0806
DEBUG - 2024-03-07 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:33:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:33:53 --> Total execution time: 0.0570
DEBUG - 2024-03-07 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:33:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:34:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:34:52 --> Total execution time: 0.1190
DEBUG - 2024-03-07 07:34:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:34:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:34:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:34:59 --> Total execution time: 0.0559
DEBUG - 2024-03-07 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:34:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:35:08 --> No URI present. Default controller set.
DEBUG - 2024-03-07 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:35:08 --> Total execution time: 0.0535
DEBUG - 2024-03-07 07:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:40:57 --> Total execution time: 0.0481
DEBUG - 2024-03-07 07:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:03 --> Total execution time: 0.0535
DEBUG - 2024-03-07 07:41:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:41:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:05 --> Total execution time: 0.1008
DEBUG - 2024-03-07 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:41:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:41:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:06 --> Total execution time: 0.0636
DEBUG - 2024-03-07 07:41:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:41:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:10 --> Total execution time: 0.0779
DEBUG - 2024-03-07 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:41:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:13 --> Total execution time: 0.0600
DEBUG - 2024-03-07 07:41:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:41:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:41:19 --> Total execution time: 0.0567
DEBUG - 2024-03-07 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:41:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:42:46 --> Total execution time: 0.0765
DEBUG - 2024-03-07 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:42:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:44:01 --> Total execution time: 0.0796
DEBUG - 2024-03-07 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:44:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:45:21 --> Total execution time: 0.0823
DEBUG - 2024-03-07 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:45:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:45:31 --> Total execution time: 0.0861
DEBUG - 2024-03-07 07:45:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:45:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:45:36 --> Total execution time: 0.0588
DEBUG - 2024-03-07 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:45:47 --> Total execution time: 0.0611
DEBUG - 2024-03-07 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:45:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 07:45:52 --> Total execution time: 0.0591
DEBUG - 2024-03-07 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 07:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 07:45:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:23:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:23:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:23:49 --> Total execution time: 0.0722
DEBUG - 2024-03-07 08:23:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:23:54 --> Total execution time: 0.1127
DEBUG - 2024-03-07 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:23:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:23:57 --> Total execution time: 0.0655
DEBUG - 2024-03-07 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:23:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:24:00 --> Total execution time: 0.1307
DEBUG - 2024-03-07 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:24:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:24:31 --> Total execution time: 0.1393
DEBUG - 2024-03-07 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:24:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:24:39 --> Total execution time: 0.1097
DEBUG - 2024-03-07 08:24:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:24:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:33:25 --> Total execution time: 0.0643
DEBUG - 2024-03-07 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:33:25 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-07 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:33:28 --> Total execution time: 0.0677
DEBUG - 2024-03-07 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:33:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 08:33:31 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\habitro\admin\application\views\pricing.php 63
DEBUG - 2024-03-07 08:33:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:33:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 08:34:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\habitro\admin\application\views\pricing.php 63
DEBUG - 2024-03-07 08:34:28 --> Total execution time: 0.1109
DEBUG - 2024-03-07 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:34:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:35:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 08:35:40 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\habitro\admin\application\views\pricing.php 63
DEBUG - 2024-03-07 08:35:40 --> Total execution time: 0.1763
DEBUG - 2024-03-07 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:35:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:36:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 08:36:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\habitro\admin\application\views\pricing.php 63
DEBUG - 2024-03-07 08:36:08 --> Total execution time: 0.0946
DEBUG - 2024-03-07 08:36:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:36:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:36:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 08:36:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\habitro\admin\application\views\pricing.php 63
DEBUG - 2024-03-07 08:36:15 --> Total execution time: 0.1080
DEBUG - 2024-03-07 08:36:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:36:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:40:53 --> Total execution time: 0.0548
DEBUG - 2024-03-07 08:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:40:57 --> Total execution time: 0.0577
DEBUG - 2024-03-07 08:40:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:40:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:40:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 08:40:59 --> Query error: Table 'habitro.master-pricing' doesn't exist - Invalid query: SELECT *
FROM `master-pricing`
DEBUG - 2024-03-07 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:41:18 --> Total execution time: 0.1353
DEBUG - 2024-03-07 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:41:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:41:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:41:48 --> Total execution time: 0.1166
DEBUG - 2024-03-07 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:41:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:42:25 --> Total execution time: 0.1451
DEBUG - 2024-03-07 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:42:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:42:44 --> Total execution time: 0.1127
DEBUG - 2024-03-07 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:42:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:43:30 --> Total execution time: 0.1493
DEBUG - 2024-03-07 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:43:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:43:50 --> Total execution time: 0.1255
DEBUG - 2024-03-07 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:43:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:43:58 --> Total execution time: 0.1203
DEBUG - 2024-03-07 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:43:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:44:08 --> Total execution time: 0.1426
DEBUG - 2024-03-07 08:44:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:44:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:44:16 --> Total execution time: 0.1258
DEBUG - 2024-03-07 08:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:44:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:44:33 --> Total execution time: 0.1295
DEBUG - 2024-03-07 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:44:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:45:52 --> Total execution time: 0.1288
DEBUG - 2024-03-07 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:45:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:46:00 --> Total execution time: 0.0632
DEBUG - 2024-03-07 08:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:46:00 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-07 08:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:46:04 --> Total execution time: 0.0562
DEBUG - 2024-03-07 08:46:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:46:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:46:06 --> Total execution time: 0.1961
DEBUG - 2024-03-07 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:46:21 --> Total execution time: 0.1481
DEBUG - 2024-03-07 08:46:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:46:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:48:55 --> Total execution time: 0.1638
DEBUG - 2024-03-07 08:48:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:48:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:48:59 --> Total execution time: 0.0554
DEBUG - 2024-03-07 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:48:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:49:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:49:06 --> Total execution time: 0.1322
DEBUG - 2024-03-07 08:49:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:49:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:49:15 --> Total execution time: 0.1354
DEBUG - 2024-03-07 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:49:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:49:15 --> Total execution time: 0.0684
DEBUG - 2024-03-07 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:49:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:49:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:49:17 --> Total execution time: 0.0757
DEBUG - 2024-03-07 08:49:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:49:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:49:19 --> Total execution time: 0.0630
DEBUG - 2024-03-07 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:49:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:00 --> Total execution time: 0.1217
DEBUG - 2024-03-07 08:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:51:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:02 --> Total execution time: 0.0552
DEBUG - 2024-03-07 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:06 --> Total execution time: 0.0548
DEBUG - 2024-03-07 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:51:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:10 --> Total execution time: 0.0661
DEBUG - 2024-03-07 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:51:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:19 --> Total execution time: 0.1010
DEBUG - 2024-03-07 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:51:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:51:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:23 --> Total execution time: 0.0567
DEBUG - 2024-03-07 08:51:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:51:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:51:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:51:25 --> Total execution time: 0.0585
DEBUG - 2024-03-07 08:51:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:51:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:52:25 --> Total execution time: 0.1109
DEBUG - 2024-03-07 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:52:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:52:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:52:28 --> Total execution time: 0.0578
DEBUG - 2024-03-07 08:52:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:52:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:53:20 --> Total execution time: 0.1562
DEBUG - 2024-03-07 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:53:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:53:29 --> Total execution time: 0.1068
DEBUG - 2024-03-07 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:53:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:53:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:53:37 --> Total execution time: 0.0591
DEBUG - 2024-03-07 08:53:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:53:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:53:54 --> Total execution time: 0.0841
DEBUG - 2024-03-07 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:53:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:54:07 --> Total execution time: 0.0872
DEBUG - 2024-03-07 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:54:14 --> Total execution time: 0.0609
DEBUG - 2024-03-07 08:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:54:17 --> Total execution time: 0.1096
DEBUG - 2024-03-07 08:54:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:54:20 --> Total execution time: 0.0507
DEBUG - 2024-03-07 08:54:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:27 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 08:54:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:54:48 --> Total execution time: 0.1379
DEBUG - 2024-03-07 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:54:48 --> UTF-8 Support Enabled
ERROR - 2024-03-07 08:54:48 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 08:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 08:54:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:54:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:55:15 --> Total execution time: 0.1278
DEBUG - 2024-03-07 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:55:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:55:25 --> Total execution time: 0.1222
DEBUG - 2024-03-07 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:55:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:55:39 --> Total execution time: 0.1427
DEBUG - 2024-03-07 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:55:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:55:59 --> Total execution time: 0.1349
DEBUG - 2024-03-07 08:55:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:55:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:56:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:06 --> Total execution time: 0.0504
DEBUG - 2024-03-07 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:10 --> Total execution time: 0.0529
DEBUG - 2024-03-07 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:56:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:12 --> Total execution time: 0.0801
DEBUG - 2024-03-07 08:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:56:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:28 --> Total execution time: 0.1398
DEBUG - 2024-03-07 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:56:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:56:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:36 --> Total execution time: 0.1139
DEBUG - 2024-03-07 08:56:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:56:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:56:48 --> Total execution time: 0.1440
DEBUG - 2024-03-07 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:56:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:58:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:58:22 --> Total execution time: 0.1548
DEBUG - 2024-03-07 08:58:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:58:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:58:54 --> Total execution time: 0.0897
DEBUG - 2024-03-07 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:58:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:58:56 --> Total execution time: 0.1729
DEBUG - 2024-03-07 08:59:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 08:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 08:59:01 --> Total execution time: 0.1169
DEBUG - 2024-03-07 08:59:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:59:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:59:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 08:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 08:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 08:59:04 --> 404 Page Not Found: Welcome/add_includes
DEBUG - 2024-03-07 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:40 --> Total execution time: 0.0666
DEBUG - 2024-03-07 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:44 --> Total execution time: 0.0558
DEBUG - 2024-03-07 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:01:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:46 --> Total execution time: 0.1774
DEBUG - 2024-03-07 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:54 --> Total execution time: 0.1023
DEBUG - 2024-03-07 09:01:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:01:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:01:59 --> Total execution time: 0.0643
DEBUG - 2024-03-07 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:01:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:02:10 --> Total execution time: 0.0515
DEBUG - 2024-03-07 09:02:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:02:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:03:28 --> Total execution time: 0.0807
DEBUG - 2024-03-07 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:03:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 09:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:09:04 --> Total execution time: 0.1176
DEBUG - 2024-03-07 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:09:09 --> Total execution time: 0.0610
DEBUG - 2024-03-07 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:09:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 09:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 09:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 09:09:24 --> Total execution time: 0.0536
DEBUG - 2024-03-07 09:09:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 09:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 09:09:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:10:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:10:41 --> No URI present. Default controller set.
DEBUG - 2024-03-07 10:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:10:41 --> Total execution time: 0.7616
DEBUG - 2024-03-07 10:10:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:10:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:10:45 --> Total execution time: 0.0834
DEBUG - 2024-03-07 10:10:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:10:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:10:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:10:47 --> Total execution time: 0.0961
DEBUG - 2024-03-07 10:10:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:10:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:13:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:13:03 --> Severity: Notice --> Undefined variable: pricingItem C:\xampp\htdocs\habitro\admin\application\views\pricing.php 81
DEBUG - 2024-03-07 10:13:03 --> Total execution time: 0.1529
DEBUG - 2024-03-07 10:13:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:13:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:13:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:13:36 --> Total execution time: 0.1055
DEBUG - 2024-03-07 10:13:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:13:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:14:12 --> Total execution time: 0.1150
DEBUG - 2024-03-07 10:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:14:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:14:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:14:42 --> Total execution time: 0.0965
DEBUG - 2024-03-07 10:14:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:14:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:14:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:14:55 --> Total execution time: 0.0924
DEBUG - 2024-03-07 10:14:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:14:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:14:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:15:11 --> Total execution time: 0.0919
DEBUG - 2024-03-07 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:15:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:15:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:15:23 --> Total execution time: 0.0759
DEBUG - 2024-03-07 10:15:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:15:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:15:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:15:25 --> Total execution time: 0.0761
DEBUG - 2024-03-07 10:15:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:15:27 --> Total execution time: 0.0638
DEBUG - 2024-03-07 10:15:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:15:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:15:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:15:33 --> Total execution time: 0.4943
DEBUG - 2024-03-07 10:15:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:15:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:16:51 --> Severity: Notice --> Undefined variable: standard C:\xampp\htdocs\habitro\admin\application\views\pricing.php 73
ERROR - 2024-03-07 10:16:51 --> Severity: Notice --> Undefined variable: standard C:\xampp\htdocs\habitro\admin\application\views\pricing.php 77
ERROR - 2024-03-07 10:16:51 --> Severity: Notice --> Undefined variable: standard C:\xampp\htdocs\habitro\admin\application\views\pricing.php 79
DEBUG - 2024-03-07 10:16:51 --> Total execution time: 0.1344
DEBUG - 2024-03-07 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:16:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:16:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:17:15 --> Severity: Notice --> Undefined variable: standard C:\xampp\htdocs\habitro\admin\application\views\pricing.php 77
ERROR - 2024-03-07 10:17:15 --> Severity: Notice --> Undefined variable: standard C:\xampp\htdocs\habitro\admin\application\views\pricing.php 79
DEBUG - 2024-03-07 10:17:15 --> Total execution time: 0.1010
DEBUG - 2024-03-07 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:17:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:17:38 --> Severity: Notice --> Undefined variable: standard C:\xampp\htdocs\habitro\admin\application\views\pricing.php 76
DEBUG - 2024-03-07 10:17:38 --> Total execution time: 0.0990
DEBUG - 2024-03-07 10:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:17:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:17:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:17:44 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\pricing.php 76
DEBUG - 2024-03-07 10:17:44 --> Total execution time: 0.1056
DEBUG - 2024-03-07 10:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:17:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:17:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:17:53 --> Total execution time: 0.0991
DEBUG - 2024-03-07 10:17:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:17:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:17:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:18:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:18:22 --> Total execution time: 0.0997
DEBUG - 2024-03-07 10:18:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:18:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:18:46 --> Total execution time: 0.0972
DEBUG - 2024-03-07 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:18:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:18:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:19:21 --> Total execution time: 0.1307
DEBUG - 2024-03-07 10:19:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:19:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:20:47 --> Total execution time: 0.1092
DEBUG - 2024-03-07 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:20:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:21:12 --> Total execution time: 0.1023
DEBUG - 2024-03-07 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:21:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:21:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:21:18 --> Total execution time: 0.0655
DEBUG - 2024-03-07 10:21:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:21:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:21:20 --> Total execution time: 0.0801
DEBUG - 2024-03-07 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:21:35 --> Total execution time: 0.0980
DEBUG - 2024-03-07 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:21:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:21:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:21:38 --> 404 Page Not Found: Welcome/update_pricing
DEBUG - 2024-03-07 10:24:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:24:33 --> 404 Page Not Found: Welcome/update_pricing
DEBUG - 2024-03-07 10:24:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:24:42 --> 404 Page Not Found: Welcome/update_pricing
DEBUG - 2024-03-07 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:24:44 --> 404 Page Not Found: Welcome/update_pricing
DEBUG - 2024-03-07 10:25:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:25:07 --> Total execution time: 0.1136
DEBUG - 2024-03-07 10:25:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:25:26 --> Total execution time: 0.0586
DEBUG - 2024-03-07 10:25:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:25:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:25:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:25:45 --> Total execution time: 0.0670
DEBUG - 2024-03-07 10:25:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:25:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:26:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:26:33 --> Severity: Notice --> Undefined variable: masterpricing C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 17
ERROR - 2024-03-07 10:26:33 --> Severity: Notice --> Undefined variable: masterpricing C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 18
ERROR - 2024-03-07 10:26:33 --> Severity: Notice --> Undefined variable: masterpricing C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 22
DEBUG - 2024-03-07 10:26:33 --> Total execution time: 0.0787
DEBUG - 2024-03-07 10:26:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:26:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:27:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:27:01 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 17
ERROR - 2024-03-07 10:27:01 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 18
ERROR - 2024-03-07 10:27:01 --> Severity: Notice --> Undefined index: variant C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 22
ERROR - 2024-03-07 10:27:01 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 29
DEBUG - 2024-03-07 10:27:01 --> Total execution time: 0.0974
DEBUG - 2024-03-07 10:27:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:27:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:27:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:27:25 --> Severity: error --> Exception: Call to undefined method GetData::getmasterpricing() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 215
DEBUG - 2024-03-07 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:27:31 --> Total execution time: 0.0880
DEBUG - 2024-03-07 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:27:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:27:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:27:46 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 29
DEBUG - 2024-03-07 10:27:46 --> Total execution time: 0.0986
DEBUG - 2024-03-07 10:27:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:27:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:27:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:27:57 --> Total execution time: 0.0665
DEBUG - 2024-03-07 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:27:59 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 29
DEBUG - 2024-03-07 10:27:59 --> Total execution time: 0.0738
DEBUG - 2024-03-07 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:28:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:32:04 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 39
DEBUG - 2024-03-07 10:32:04 --> Total execution time: 0.0997
DEBUG - 2024-03-07 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:32:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:32:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:32:18 --> Total execution time: 0.0649
DEBUG - 2024-03-07 10:32:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:32:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:32:21 --> Total execution time: 0.0775
DEBUG - 2024-03-07 10:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:32:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:32:26 --> Total execution time: 0.0620
DEBUG - 2024-03-07 10:32:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:32:44 --> Total execution time: 0.0724
DEBUG - 2024-03-07 10:32:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:32:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:32:47 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 39
DEBUG - 2024-03-07 10:32:47 --> Total execution time: 0.0938
DEBUG - 2024-03-07 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:32:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:32:57 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 29
DEBUG - 2024-03-07 10:32:57 --> Total execution time: 0.0704
DEBUG - 2024-03-07 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:32:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:33:17 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 29
DEBUG - 2024-03-07 10:33:17 --> Total execution time: 0.0782
DEBUG - 2024-03-07 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:33:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:34:04 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 29
DEBUG - 2024-03-07 10:34:04 --> Total execution time: 0.0745
DEBUG - 2024-03-07 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:34:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:34:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:34:29 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 36
DEBUG - 2024-03-07 10:34:29 --> Total execution time: 0.0778
DEBUG - 2024-03-07 10:34:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:34:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:35:02 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 43
DEBUG - 2024-03-07 10:35:02 --> Total execution time: 0.0824
DEBUG - 2024-03-07 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:35:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:37:22 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 43
DEBUG - 2024-03-07 10:37:22 --> Total execution time: 0.0800
DEBUG - 2024-03-07 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:37:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:37:34 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 43
DEBUG - 2024-03-07 10:37:34 --> Total execution time: 0.0707
DEBUG - 2024-03-07 10:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:37:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:37:45 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 43
DEBUG - 2024-03-07 10:37:45 --> Total execution time: 0.0799
DEBUG - 2024-03-07 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:37:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:38:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:38:02 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 43
DEBUG - 2024-03-07 10:38:02 --> Total execution time: 0.0784
DEBUG - 2024-03-07 10:38:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:38:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:38:27 --> Total execution time: 0.0841
DEBUG - 2024-03-07 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:38:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:38:35 --> Total execution time: 0.0674
DEBUG - 2024-03-07 10:38:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:38:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:38:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:38:41 --> Total execution time: 0.0597
DEBUG - 2024-03-07 10:43:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:43:00 --> Total execution time: 0.1176
DEBUG - 2024-03-07 10:43:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:43:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:43:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:43:04 --> Severity: error --> Exception: Call to undefined method GetData::update_pricing() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 235
DEBUG - 2024-03-07 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:44:51 --> Total execution time: 0.0568
DEBUG - 2024-03-07 10:44:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:44:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:44:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:44:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:44:54 --> Total execution time: 0.0820
DEBUG - 2024-03-07 10:44:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:44:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:45:24 --> Total execution time: 0.0644
DEBUG - 2024-03-07 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:45:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:45:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:48:34 --> Total execution time: 0.0839
DEBUG - 2024-03-07 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:48:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:48:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:48:36 --> Total execution time: 0.0890
DEBUG - 2024-03-07 10:48:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:48:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:48:51 --> Total execution time: 0.0714
DEBUG - 2024-03-07 10:48:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:48:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:49:13 --> Severity: error --> Exception: syntax error, unexpected '?', expecting end of file C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 37
DEBUG - 2024-03-07 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:49:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:49:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:49:25 --> Total execution time: 0.0769
DEBUG - 2024-03-07 10:49:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:49:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:49:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:49:39 --> Total execution time: 0.0615
DEBUG - 2024-03-07 10:49:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:49:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:49:53 --> Total execution time: 0.0593
DEBUG - 2024-03-07 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:49:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:10 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:10 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:10 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:10 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:50:53 --> Total execution time: 0.0830
DEBUG - 2024-03-07 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:53 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:53 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:53 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:50:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:50:55 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:51:12 --> Total execution time: 0.0727
DEBUG - 2024-03-07 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:12 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 10:51:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:51:29 --> Total execution time: 0.0727
DEBUG - 2024-03-07 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:30 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:51:43 --> Total execution time: 0.0954
DEBUG - 2024-03-07 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:43 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-07 10:51:43 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:51:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:53:12 --> Total execution time: 0.0830
DEBUG - 2024-03-07 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:12 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 10:53:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:53:55 --> Total execution time: 0.1106
DEBUG - 2024-03-07 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:55 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:55 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:53:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:53:57 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:54:30 --> Total execution time: 0.0885
DEBUG - 2024-03-07 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:54:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:54:30 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:54:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:54:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:54:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:55:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:55:20 --> Total execution time: 0.0742
DEBUG - 2024-03-07 10:55:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:21 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-07 10:55:21 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:55:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:21 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:22 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 10:55:54 --> Severity: Notice --> Undefined index: amountinwords C:\xampp\htdocs\habitro\admin\application\views\edit\updatepricing.php 38
DEBUG - 2024-03-07 10:55:54 --> Total execution time: 0.1000
DEBUG - 2024-03-07 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:54 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:54 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:55:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:55 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:55:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:55:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:55:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:56:27 --> Total execution time: 0.0581
DEBUG - 2024-03-07 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:27 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 10:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:56:40 --> Total execution time: 0.0546
DEBUG - 2024-03-07 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:56:43 --> Total execution time: 0.0849
DEBUG - 2024-03-07 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:56:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:05 --> Total execution time: 0.0576
DEBUG - 2024-03-07 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:20 --> Total execution time: 0.0602
DEBUG - 2024-03-07 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:26 --> Total execution time: 0.0659
DEBUG - 2024-03-07 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:29 --> Total execution time: 0.0633
DEBUG - 2024-03-07 10:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:33 --> Total execution time: 0.0658
DEBUG - 2024-03-07 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:37 --> Total execution time: 0.0617
DEBUG - 2024-03-07 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:57:42 --> Total execution time: 0.0627
DEBUG - 2024-03-07 10:57:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:57:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 10:58:19 --> Total execution time: 0.0628
DEBUG - 2024-03-07 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:58:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 10:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 10:58:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:02:20 --> Total execution time: 0.0676
DEBUG - 2024-03-07 11:02:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:02:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:02:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:02:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:02:23 --> Total execution time: 0.1391
DEBUG - 2024-03-07 11:02:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:02:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:02:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:02:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:03:00 --> Total execution time: 0.0732
DEBUG - 2024-03-07 11:03:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:03:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:03:27 --> Total execution time: 0.0591
DEBUG - 2024-03-07 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:03:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:03:57 --> Total execution time: 0.1293
DEBUG - 2024-03-07 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:03:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:04:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:04:01 --> Total execution time: 0.0768
DEBUG - 2024-03-07 11:04:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:04:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:04:03 --> Total execution time: 0.0729
DEBUG - 2024-03-07 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:04:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:04:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:10:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:10:56 --> Total execution time: 1.0337
DEBUG - 2024-03-07 11:10:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:10:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:10:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:11:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:11:20 --> Total execution time: 0.1790
DEBUG - 2024-03-07 11:11:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:11:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:11:35 --> Total execution time: 0.0862
DEBUG - 2024-03-07 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:11:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:12:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:12:26 --> Total execution time: 0.0625
DEBUG - 2024-03-07 11:12:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:12:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:12:34 --> Total execution time: 0.0739
DEBUG - 2024-03-07 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:12:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:48:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:48:22 --> Total execution time: 0.1389
DEBUG - 2024-03-07 11:48:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:48:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 11:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 11:53:59 --> Total execution time: 0.1183
DEBUG - 2024-03-07 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 11:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 11:53:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:02:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:02:52 --> Total execution time: 0.0990
DEBUG - 2024-03-07 12:02:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:02:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:08:24 --> Total execution time: 0.0900
DEBUG - 2024-03-07 12:08:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:08:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:09:07 --> Total execution time: 0.0910
DEBUG - 2024-03-07 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:09:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:13:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:13:56 --> Total execution time: 0.1735
DEBUG - 2024-03-07 12:13:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:13:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:13:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:13:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 12:13:58 --> Severity: error --> Exception: Call to undefined method GetData::getgallery() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 280
DEBUG - 2024-03-07 12:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:14:12 --> Total execution time: 0.0837
DEBUG - 2024-03-07 12:14:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:14:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:15:09 --> Total execution time: 0.1000
DEBUG - 2024-03-07 12:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:15:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:15:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:15:37 --> Total execution time: 0.0904
DEBUG - 2024-03-07 12:15:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:15:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:15:48 --> Total execution time: 0.0955
DEBUG - 2024-03-07 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:15:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:15:55 --> Total execution time: 0.0862
DEBUG - 2024-03-07 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:15:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:16:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:16:03 --> Total execution time: 0.0950
DEBUG - 2024-03-07 12:16:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:16:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:16:09 --> Total execution time: 0.1044
DEBUG - 2024-03-07 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:16:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:16:15 --> Total execution time: 0.0909
DEBUG - 2024-03-07 12:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:16:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:16:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:16:37 --> Total execution time: 0.1116
DEBUG - 2024-03-07 12:16:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:16:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:17:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:17:24 --> Total execution time: 0.1021
DEBUG - 2024-03-07 12:17:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:17:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:17:31 --> Total execution time: 0.0879
DEBUG - 2024-03-07 12:17:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:17:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:17:45 --> Total execution time: 0.0876
DEBUG - 2024-03-07 12:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:17:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:17:58 --> Total execution time: 0.0555
DEBUG - 2024-03-07 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:17:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:20:15 --> Total execution time: 0.1113
DEBUG - 2024-03-07 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:20:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:20:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:20:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:20:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:20:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:20:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:20:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:20:24 --> UTF-8 Support Enabled
ERROR - 2024-03-07 12:20:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:20:24 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:21:40 --> Total execution time: 0.1094
DEBUG - 2024-03-07 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:21:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:21:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:21:41 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:21:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:21:41 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:21:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:21:42 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:21:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:22:15 --> Total execution time: 0.1050
DEBUG - 2024-03-07 12:22:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:22:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:40:43 --> Total execution time: 0.1231
DEBUG - 2024-03-07 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:40:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:40:43 --> 404 Page Not Found: Images/big
DEBUG - 2024-03-07 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:41:05 --> Total execution time: 0.1332
DEBUG - 2024-03-07 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:41:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:41:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:41:20 --> Total execution time: 0.1481
DEBUG - 2024-03-07 12:41:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:41:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:41:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:41:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:41:28 --> Total execution time: 0.1954
DEBUG - 2024-03-07 12:41:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:41:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:42:38 --> Total execution time: 0.1289
DEBUG - 2024-03-07 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:42:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:42:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:42:55 --> Total execution time: 0.0900
DEBUG - 2024-03-07 12:42:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:42:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:42:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:43:01 --> Total execution time: 0.0511
DEBUG - 2024-03-07 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:43:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:43:03 --> Total execution time: 0.0697
DEBUG - 2024-03-07 12:43:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:43:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:43:21 --> Total execution time: 0.0896
DEBUG - 2024-03-07 12:43:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:43:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:43:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:43:27 --> Total execution time: 0.0565
DEBUG - 2024-03-07 12:43:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:43:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:43:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:43:39 --> Total execution time: 0.0887
DEBUG - 2024-03-07 12:43:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:43:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:43:50 --> Total execution time: 0.0861
DEBUG - 2024-03-07 12:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:43:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:44:18 --> Total execution time: 0.1002
DEBUG - 2024-03-07 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:44:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:44:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:44:25 --> Total execution time: 0.0953
DEBUG - 2024-03-07 12:44:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:44:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:44:33 --> Total execution time: 0.1070
DEBUG - 2024-03-07 12:44:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:44:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:44:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:44:44 --> Total execution time: 0.1014
DEBUG - 2024-03-07 12:44:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:44:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:45:04 --> Total execution time: 0.0847
DEBUG - 2024-03-07 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:45:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:45:27 --> Total execution time: 0.1133
DEBUG - 2024-03-07 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:45:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:45:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:45:32 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:45:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:45:33 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 12:45:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:47:33 --> Total execution time: 0.1765
DEBUG - 2024-03-07 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:34 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-07 12:47:34 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:35 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:47:38 --> Total execution time: 0.0812
DEBUG - 2024-03-07 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:38 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:39 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:47:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:47:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:47:40 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:49:09 --> Total execution time: 0.1157
DEBUG - 2024-03-07 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:49:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:50:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:50:55 --> Total execution time: 0.0675
DEBUG - 2024-03-07 12:50:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:50:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:50:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 12:50:58 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 81
ERROR - 2024-03-07 12:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 81
DEBUG - 2024-03-07 12:50:58 --> Total execution time: 0.1569
DEBUG - 2024-03-07 12:50:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:50:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:51:31 --> Total execution time: 0.1111
DEBUG - 2024-03-07 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:51:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:52:10 --> Total execution time: 0.1124
DEBUG - 2024-03-07 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:52:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:53:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 12:53:24 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 82
ERROR - 2024-03-07 12:53:24 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 82
DEBUG - 2024-03-07 12:53:24 --> Total execution time: 0.0786
DEBUG - 2024-03-07 12:53:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:53:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:53:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 12:53:27 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 82
ERROR - 2024-03-07 12:53:27 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 82
DEBUG - 2024-03-07 12:53:27 --> Total execution time: 0.0595
DEBUG - 2024-03-07 12:53:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:53:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:53:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:53:39 --> Total execution time: 0.0943
DEBUG - 2024-03-07 12:53:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:53:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:53:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:54:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:54:01 --> Total execution time: 0.0923
DEBUG - 2024-03-07 12:54:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:54:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:54:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:54:28 --> Total execution time: 0.0848
DEBUG - 2024-03-07 12:54:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:54:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:55:34 --> Total execution time: 0.0694
DEBUG - 2024-03-07 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:55:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:56:20 --> Total execution time: 0.1201
DEBUG - 2024-03-07 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:56:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:56:31 --> Total execution time: 0.0928
DEBUG - 2024-03-07 12:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:56:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:56:36 --> Total execution time: 0.0725
DEBUG - 2024-03-07 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:56:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:56:44 --> Total execution time: 0.0889
DEBUG - 2024-03-07 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:56:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:56:52 --> Total execution time: 0.0964
DEBUG - 2024-03-07 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:56:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:57:05 --> Total execution time: 0.1044
DEBUG - 2024-03-07 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:57:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:57:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 12:57:27 --> Total execution time: 0.1012
DEBUG - 2024-03-07 12:57:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:57:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:57:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 12:57:54 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 106
ERROR - 2024-03-07 12:57:54 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 106
ERROR - 2024-03-07 12:57:54 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 106
ERROR - 2024-03-07 12:57:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 130
DEBUG - 2024-03-07 12:57:54 --> Total execution time: 0.1237
DEBUG - 2024-03-07 12:57:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:57:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:57:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 12:58:17 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 106
ERROR - 2024-03-07 12:58:17 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 106
ERROR - 2024-03-07 12:58:17 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 106
ERROR - 2024-03-07 12:58:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 130
DEBUG - 2024-03-07 12:58:17 --> Total execution time: 0.1178
DEBUG - 2024-03-07 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 12:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 12:58:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:02:05 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 128
ERROR - 2024-03-07 13:02:05 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 128
ERROR - 2024-03-07 13:02:05 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 128
DEBUG - 2024-03-07 13:02:05 --> Total execution time: 0.1488
DEBUG - 2024-03-07 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:02:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:02:27 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
ERROR - 2024-03-07 13:02:27 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
ERROR - 2024-03-07 13:02:27 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
DEBUG - 2024-03-07 13:02:27 --> Total execution time: 0.1186
DEBUG - 2024-03-07 13:02:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:02:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:02:53 --> Severity: Notice --> Undefined index: data_filter C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 86
ERROR - 2024-03-07 13:02:53 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
ERROR - 2024-03-07 13:02:53 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
ERROR - 2024-03-07 13:02:53 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
DEBUG - 2024-03-07 13:02:53 --> Total execution time: 0.1174
DEBUG - 2024-03-07 13:02:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:02:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:03:03 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
ERROR - 2024-03-07 13:03:03 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
ERROR - 2024-03-07 13:03:03 --> Severity: Warning --> Illegal string offset 'data_filter' C:\xampp\htdocs\habitro\admin\application\views\gallery-wall.php 126
DEBUG - 2024-03-07 13:03:03 --> Total execution time: 0.1714
DEBUG - 2024-03-07 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:03:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:03:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:03:36 --> Total execution time: 0.1410
DEBUG - 2024-03-07 13:03:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:03:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:04:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:04:08 --> Total execution time: 0.1190
DEBUG - 2024-03-07 13:04:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:04:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:05:50 --> Total execution time: 0.1331
DEBUG - 2024-03-07 13:05:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:05:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:06:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:06:31 --> Total execution time: 0.1174
DEBUG - 2024-03-07 13:06:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:06:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:06:36 --> Total execution time: 0.0554
DEBUG - 2024-03-07 13:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:06:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:08:38 --> Total execution time: 0.1276
DEBUG - 2024-03-07 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:08:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:08:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:08:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:08:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:08:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:08:49 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 13:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:08:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:09:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:09:13 --> Total execution time: 0.1166
DEBUG - 2024-03-07 13:09:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:09:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:09:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:09:14 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 13:09:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:09:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:09:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:09:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:09:15 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:09:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:09:39 --> Total execution time: 0.1012
DEBUG - 2024-03-07 13:09:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:09:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:10:02 --> Total execution time: 0.0725
DEBUG - 2024-03-07 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:10:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:10:22 --> Total execution time: 0.0563
DEBUG - 2024-03-07 13:10:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:10:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:10:24 --> Total execution time: 0.1056
DEBUG - 2024-03-07 13:10:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:10:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:10:33 --> Total execution time: 0.1277
DEBUG - 2024-03-07 13:10:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:39 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:40 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:10:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 13:10:40 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:11:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:11:01 --> Total execution time: 0.1481
DEBUG - 2024-03-07 13:11:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:11:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:11:02 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:11:02 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:11:02 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:11:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:11:03 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:11:32 --> Total execution time: 0.1039
DEBUG - 2024-03-07 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:11:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:12:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:12:12 --> Total execution time: 0.1169
DEBUG - 2024-03-07 13:12:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:12:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:12:14 --> 404 Page Not Found: Welcome/update_gallery
DEBUG - 2024-03-07 13:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:14:17 --> Severity: error --> Exception: Too few arguments to function Welcome::update_gallery(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 284
DEBUG - 2024-03-07 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:14:41 --> Total execution time: 0.0918
DEBUG - 2024-03-07 13:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:14:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:16:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:16:47 --> Total execution time: 0.1740
DEBUG - 2024-03-07 13:16:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:16:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:16:56 --> Total execution time: 0.1109
DEBUG - 2024-03-07 13:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:16:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:17:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:17:49 --> Total execution time: 0.0821
DEBUG - 2024-03-07 13:17:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:17:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:23:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:23:04 --> Total execution time: 0.0881
DEBUG - 2024-03-07 13:23:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:23:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:23:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:23:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:23:36 --> Total execution time: 0.0873
DEBUG - 2024-03-07 13:23:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:23:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:23:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:24:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:24:14 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `package` (`title`, `package`) VALUES (NULL, 'standard')
DEBUG - 2024-03-07 13:25:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:25:01 --> Total execution time: 0.0889
DEBUG - 2024-03-07 13:25:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:25:08 --> Severity: error --> Exception: Call to undefined method GetData::update_gallery() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 299
DEBUG - 2024-03-07 13:30:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:30:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:30:15 --> Total execution time: 0.0706
DEBUG - 2024-03-07 13:30:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:30:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:30:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:31:30 --> Total execution time: 0.0680
DEBUG - 2024-03-07 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:31:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:31:37 --> Total execution time: 0.0596
DEBUG - 2024-03-07 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:31:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:32:55 --> Total execution time: 0.0857
DEBUG - 2024-03-07 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:32:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:32:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:32:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:32:57 --> Total execution time: 0.0981
DEBUG - 2024-03-07 13:32:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:32:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:33:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:33:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:33:01 --> Total execution time: 0.0625
DEBUG - 2024-03-07 13:33:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:33:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:33:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:33:15 --> Total execution time: 0.0744
DEBUG - 2024-03-07 13:33:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:33:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:34:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:34:06 --> Total execution time: 0.1013
DEBUG - 2024-03-07 13:34:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:34:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:34:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:34:12 --> Query error: Unknown column 'image' in 'field list' - Invalid query: INSERT INTO `testimonials` (`image`, `data_filter`) VALUES ('https://ik.imagekit.io/habitro/gallery/construction/29.jpg?updatedAt=1709808752596', NULL)
DEBUG - 2024-03-07 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:34:25 --> Total execution time: 0.0696
DEBUG - 2024-03-07 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-07 13:34:32 --> Query error: Unknown column 'image' in 'field list' - Invalid query: INSERT INTO `testimonials` (`image`, `data_filter`) VALUES ('http://via.placeholder.com/640x360', 'construction')
DEBUG - 2024-03-07 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:34:49 --> Total execution time: 0.0620
DEBUG - 2024-03-07 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:34:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:35:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:35:35 --> Total execution time: 0.0588
DEBUG - 2024-03-07 13:35:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:35:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:35:42 --> Total execution time: 0.0663
DEBUG - 2024-03-07 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:35:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:35:49 --> Total execution time: 0.0667
DEBUG - 2024-03-07 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:35:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:36:42 --> Total execution time: 0.1307
DEBUG - 2024-03-07 13:36:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:36:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:36:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:36:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:36:49 --> Total execution time: 0.0622
DEBUG - 2024-03-07 13:36:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:36:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:37:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:37:19 --> Total execution time: 0.1143
DEBUG - 2024-03-07 13:37:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:37:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:37:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:37:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:37:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:37:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:37:29 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-07 13:37:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:39:44 --> Total execution time: 0.0648
DEBUG - 2024-03-07 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:39:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:39:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:39:45 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:39:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:39:46 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:40:52 --> Total execution time: 0.1295
DEBUG - 2024-03-07 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:40:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:40:52 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:40:52 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-07 13:40:52 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-07 13:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:40:53 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-07 13:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:44:04 --> Total execution time: 0.1392
DEBUG - 2024-03-07 13:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:44:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:44:08 --> Total execution time: 0.0537
DEBUG - 2024-03-07 13:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:44:08 --> Total execution time: 0.0559
DEBUG - 2024-03-07 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:44:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:44:55 --> Total execution time: 0.0689
DEBUG - 2024-03-07 13:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:44:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:45:33 --> Total execution time: 0.0744
DEBUG - 2024-03-07 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:45:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 13:45:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 13:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 13:45:38 --> Total execution time: 0.0722
DEBUG - 2024-03-07 13:45:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 13:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 13:45:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:30 --> No URI present. Default controller set.
DEBUG - 2024-03-07 14:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:17:30 --> Total execution time: 0.2774
DEBUG - 2024-03-07 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:17:30 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-07 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:17:34 --> Total execution time: 0.0544
DEBUG - 2024-03-07 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:17:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:17:58 --> Total execution time: 0.0660
DEBUG - 2024-03-07 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:17:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:18:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:06 --> Total execution time: 0.0777
DEBUG - 2024-03-07 14:18:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:18:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:14 --> Total execution time: 0.0656
DEBUG - 2024-03-07 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:18:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:18 --> Total execution time: 0.0738
DEBUG - 2024-03-07 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:18 --> Total execution time: 0.0618
DEBUG - 2024-03-07 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:18:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:21 --> Total execution time: 0.0710
DEBUG - 2024-03-07 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:21 --> Total execution time: 0.0599
DEBUG - 2024-03-07 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:18:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:24 --> Total execution time: 0.0661
DEBUG - 2024-03-07 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:18:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:18:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:18:39 --> Total execution time: 0.0714
DEBUG - 2024-03-07 14:18:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:18:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:19:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:19:57 --> Total execution time: 0.0879
DEBUG - 2024-03-07 14:19:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:19:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:20:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:08 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:11 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:18 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:22 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:32 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:35 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:35 --> 404 Page Not Found: Residential/price
DEBUG - 2024-03-07 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:20:44 --> Total execution time: 0.0622
DEBUG - 2024-03-07 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:20:52 --> Total execution time: 0.0586
DEBUG - 2024-03-07 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:20:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:22:43 --> Total execution time: 0.2341
DEBUG - 2024-03-07 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:22:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:23:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:23:03 --> Total execution time: 0.0556
DEBUG - 2024-03-07 14:23:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:23:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:23:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:23:16 --> Total execution time: 0.2080
DEBUG - 2024-03-07 14:23:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:23:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:23:18 --> Total execution time: 0.0574
DEBUG - 2024-03-07 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:23:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:23:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:23:23 --> Total execution time: 0.0593
DEBUG - 2024-03-07 14:23:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:23:25 --> Total execution time: 0.0532
DEBUG - 2024-03-07 14:23:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:23:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:23:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:23:29 --> Total execution time: 0.0559
DEBUG - 2024-03-07 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:01 --> Total execution time: 0.2335
DEBUG - 2024-03-07 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:24:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:03 --> Total execution time: 0.0659
DEBUG - 2024-03-07 14:24:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:24:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:06 --> Total execution time: 0.0718
DEBUG - 2024-03-07 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:09 --> Total execution time: 0.0548
DEBUG - 2024-03-07 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:24:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:12 --> Total execution time: 0.0773
DEBUG - 2024-03-07 14:24:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:14 --> Total execution time: 0.0581
DEBUG - 2024-03-07 14:24:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:17 --> Total execution time: 0.0628
DEBUG - 2024-03-07 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:20 --> Total execution time: 0.0596
DEBUG - 2024-03-07 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:24:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:23 --> Total execution time: 0.0652
DEBUG - 2024-03-07 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:27 --> Total execution time: 0.0605
DEBUG - 2024-03-07 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:30 --> Total execution time: 0.0637
DEBUG - 2024-03-07 14:24:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:24:41 --> Total execution time: 0.1175
DEBUG - 2024-03-07 14:24:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:24:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:25:11 --> Total execution time: 0.0711
DEBUG - 2024-03-07 14:25:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:25:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:25:24 --> Total execution time: 0.0775
DEBUG - 2024-03-07 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:25:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:25:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:25:27 --> Total execution time: 0.0571
DEBUG - 2024-03-07 14:25:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:25:33 --> Total execution time: 0.1002
DEBUG - 2024-03-07 14:25:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:25:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:25:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:25:50 --> Total execution time: 0.0601
DEBUG - 2024-03-07 14:25:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:25:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:25:53 --> Total execution time: 0.0612
DEBUG - 2024-03-07 14:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:26:09 --> Total execution time: 0.0752
DEBUG - 2024-03-07 14:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:26:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:26:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:26:12 --> Total execution time: 0.0719
DEBUG - 2024-03-07 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:26:15 --> Total execution time: 0.0702
DEBUG - 2024-03-07 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:26:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:26:31 --> Total execution time: 0.0839
DEBUG - 2024-03-07 14:26:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:26:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:26:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:26:36 --> Total execution time: 0.0596
DEBUG - 2024-03-07 14:26:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:26:44 --> Total execution time: 0.1142
DEBUG - 2024-03-07 14:26:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:26:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:27:20 --> Total execution time: 0.1147
DEBUG - 2024-03-07 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:27:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:27:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:27:25 --> Total execution time: 0.0618
DEBUG - 2024-03-07 14:27:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:27:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:27:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:27:29 --> Total execution time: 0.0590
DEBUG - 2024-03-07 14:27:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:27:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:27:34 --> Total execution time: 0.0584
DEBUG - 2024-03-07 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:27:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:11 --> Total execution time: 0.1333
DEBUG - 2024-03-07 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:18 --> Total execution time: 0.1099
DEBUG - 2024-03-07 14:28:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:22 --> Total execution time: 0.0752
DEBUG - 2024-03-07 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:25 --> Total execution time: 0.0829
DEBUG - 2024-03-07 14:28:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:28 --> Total execution time: 0.0609
DEBUG - 2024-03-07 14:28:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:33 --> Total execution time: 0.0751
DEBUG - 2024-03-07 14:28:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:36 --> Total execution time: 0.1163
DEBUG - 2024-03-07 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:41 --> Total execution time: 0.0702
DEBUG - 2024-03-07 14:28:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-07 14:28:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-07 14:28:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-07 14:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-07 14:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-07 14:28:45 --> Total execution time: 0.0546

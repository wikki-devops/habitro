<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-12 09:10:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-12 09:10:50 --> No URI present. Default controller set.
DEBUG - 2024-03-12 09:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-12 09:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-12 09:10:51 --> Total execution time: 0.8171
DEBUG - 2024-03-12 09:10:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-12 09:10:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-12 09:10:52 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-12 09:10:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-12 09:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-12 09:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-12 09:10:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-12 09:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-12 09:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-12 09:10:57 --> Total execution time: 0.1730
DEBUG - 2024-03-12 09:10:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-12 09:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-12 09:10:57 --> 404 Page Not Found: Assets/datatables

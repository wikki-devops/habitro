<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-07 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:27:13 --> No URI present. Default controller set.
DEBUG - 2024-02-07 13:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:27:14 --> Total execution time: 0.9713
DEBUG - 2024-02-07 13:27:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:27:14 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-07 13:27:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:27:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:27:54 --> Total execution time: 0.0557
DEBUG - 2024-02-07 13:28:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:28:01 --> Total execution time: 0.1069
DEBUG - 2024-02-07 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:28:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:28:01 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 13:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:28:01 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 13:28:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:28:03 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-07 13:28:03 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 13:28:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:28:09 --> Total execution time: 0.1019
DEBUG - 2024-02-07 13:28:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:28:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:28:12 --> Total execution time: 0.0985
DEBUG - 2024-02-07 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:28:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:31:54 --> Total execution time: 0.0716
DEBUG - 2024-02-07 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:31:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:34:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:34:15 --> Total execution time: 0.0726
DEBUG - 2024-02-07 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:34:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:34:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:34:16 --> Total execution time: 0.0807
DEBUG - 2024-02-07 13:34:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:34:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:34:29 --> Total execution time: 0.0608
DEBUG - 2024-02-07 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:34:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:34:49 --> Total execution time: 0.0604
DEBUG - 2024-02-07 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:34:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:35:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:35:29 --> Total execution time: 0.0743
DEBUG - 2024-02-07 13:35:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:35:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:35:41 --> Total execution time: 0.0625
DEBUG - 2024-02-07 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:35:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:35:50 --> Total execution time: 0.0670
DEBUG - 2024-02-07 13:35:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:35:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:36:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:36:06 --> Total execution time: 0.0662
DEBUG - 2024-02-07 13:36:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:36:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:36:14 --> Total execution time: 0.0610
DEBUG - 2024-02-07 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:36:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:37:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:37:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:37:23 --> Total execution time: 0.0746
DEBUG - 2024-02-07 13:37:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:37:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:38:21 --> Total execution time: 0.0608
DEBUG - 2024-02-07 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:38:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:38:28 --> Total execution time: 0.0617
DEBUG - 2024-02-07 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:38:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:50:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:50:28 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-07 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:36 --> Total execution time: 0.0699
DEBUG - 2024-02-07 13:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:41 --> Total execution time: 0.0816
DEBUG - 2024-02-07 13:50:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:47 --> Total execution time: 0.0755
DEBUG - 2024-02-07 13:50:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:49 --> Total execution time: 0.0913
DEBUG - 2024-02-07 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:50 --> Total execution time: 0.0616
DEBUG - 2024-02-07 13:50:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:50:51 --> Total execution time: 0.0582
DEBUG - 2024-02-07 13:53:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:53:07 --> 404 Page Not Found: Admin/index
DEBUG - 2024-02-07 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:53:08 --> Total execution time: 0.0710
DEBUG - 2024-02-07 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 13:53:14 --> Total execution time: 0.0622
DEBUG - 2024-02-07 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:53:14 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:53:14 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 13:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:53:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 13:53:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 13:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 13:53:15 --> UTF-8 Support Enabled
ERROR - 2024-02-07 13:53:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 13:53:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 13:53:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:20:58 --> Total execution time: 0.0597
DEBUG - 2024-02-07 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:20:58 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-07 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:21:06 --> Total execution time: 0.0529
DEBUG - 2024-02-07 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:06 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 14:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:06 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 14:21:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:07 --> UTF-8 Support Enabled
ERROR - 2024-02-07 14:21:07 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 14:21:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:07 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-07 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:21:10 --> Total execution time: 0.0695
DEBUG - 2024-02-07 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:21:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:21:13 --> Total execution time: 0.0713
DEBUG - 2024-02-07 14:21:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:21:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:21:16 --> Total execution time: 0.0650
DEBUG - 2024-02-07 14:21:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:21:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:21:21 --> Total execution time: 0.0665
DEBUG - 2024-02-07 14:21:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:21:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:23:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:23:34 --> Total execution time: 0.0688
DEBUG - 2024-02-07 14:23:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:23:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:23:41 --> Total execution time: 0.0624
DEBUG - 2024-02-07 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:23:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:23:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-07 14:23:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-07 14:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-07 14:23:45 --> Total execution time: 0.1030
DEBUG - 2024-02-07 14:23:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-07 14:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-07 14:23:45 --> 404 Page Not Found: Assets/datatables

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-06 08:07:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:07:21 --> No URI present. Default controller set.
DEBUG - 2024-03-06 08:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:07:22 --> Total execution time: 0.9480
DEBUG - 2024-03-06 08:07:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-06 08:07:22 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-06 08:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:17:18 --> Total execution time: 0.2322
DEBUG - 2024-03-06 08:17:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-06 08:17:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-06 08:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:17:37 --> Total execution time: 0.1566
DEBUG - 2024-03-06 08:17:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-06 08:17:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-06 08:20:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:20:07 --> Total execution time: 0.1395
DEBUG - 2024-03-06 08:20:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-06 08:20:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-06 08:20:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:20:21 --> Total execution time: 0.1041
DEBUG - 2024-03-06 08:20:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-06 08:20:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-06 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-06 08:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-06 08:20:28 --> Total execution time: 0.1161
DEBUG - 2024-03-06 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-06 08:20:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-06 08:20:28 --> 404 Page Not Found: Assets/datatables

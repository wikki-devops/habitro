<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-16 10:00:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:21 --> No URI present. Default controller set.
DEBUG - 2024-03-16 10:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:22 --> Total execution time: 1.1365
DEBUG - 2024-03-16 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:23 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-16 10:00:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:28 --> Total execution time: 0.2597
DEBUG - 2024-03-16 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:32 --> Total execution time: 0.3992
DEBUG - 2024-03-16 10:00:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:34 --> Total execution time: 0.1239
DEBUG - 2024-03-16 10:00:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:00:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:40 --> Total execution time: 0.0657
DEBUG - 2024-03-16 10:00:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:44 --> Total execution time: 0.1061
DEBUG - 2024-03-16 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:48 --> Total execution time: 0.1914
DEBUG - 2024-03-16 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:00:52 --> Total execution time: 0.1275
DEBUG - 2024-03-16 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:00:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:03:10 --> Total execution time: 0.1491
DEBUG - 2024-03-16 10:03:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:03:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:03:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:06:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:06:43 --> Total execution time: 0.0664
DEBUG - 2024-03-16 10:06:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:06:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:07:10 --> Total execution time: 0.0606
DEBUG - 2024-03-16 10:07:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:07:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:07:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:07:35 --> Total execution time: 0.0743
DEBUG - 2024-03-16 10:07:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:07:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:07:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:07:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:07:54 --> Total execution time: 0.0589
DEBUG - 2024-03-16 10:07:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:07:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:08:29 --> Total execution time: 0.0789
DEBUG - 2024-03-16 10:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:08:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:08:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:08:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:08:42 --> Total execution time: 0.0674
DEBUG - 2024-03-16 10:08:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:08:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:09:07 --> Total execution time: 0.0693
DEBUG - 2024-03-16 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:09:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:09:23 --> Total execution time: 0.0638
DEBUG - 2024-03-16 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:09:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:10:14 --> Total execution time: 0.0760
DEBUG - 2024-03-16 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:10:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:10:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:10:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:10:34 --> Total execution time: 0.0740
DEBUG - 2024-03-16 10:10:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:10:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:10:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:12:44 --> Total execution time: 0.0969
DEBUG - 2024-03-16 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:12:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:12:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:12:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:12:56 --> Total execution time: 0.0671
DEBUG - 2024-03-16 10:12:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:12:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:12:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:01 --> Total execution time: 0.1071
DEBUG - 2024-03-16 10:13:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:17 --> Total execution time: 0.0776
DEBUG - 2024-03-16 10:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:29 --> Total execution time: 0.0629
DEBUG - 2024-03-16 10:13:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:37 --> Total execution time: 0.0709
DEBUG - 2024-03-16 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:44 --> Total execution time: 0.0644
DEBUG - 2024-03-16 10:13:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:47 --> Total execution time: 0.0795
DEBUG - 2024-03-16 10:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:51 --> Total execution time: 0.0658
DEBUG - 2024-03-16 10:13:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:52 --> Total execution time: 0.0796
DEBUG - 2024-03-16 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:13:58 --> Total execution time: 0.1278
DEBUG - 2024-03-16 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:13:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:14:06 --> Total execution time: 0.1280
DEBUG - 2024-03-16 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:14:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:14:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:14:21 --> Total execution time: 0.1028
DEBUG - 2024-03-16 10:14:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:14:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:14:24 --> Total execution time: 0.0692
DEBUG - 2024-03-16 10:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:14:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:14:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:14:29 --> Total execution time: 0.1120
DEBUG - 2024-03-16 10:14:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:14:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:14:39 --> Total execution time: 0.0603
DEBUG - 2024-03-16 10:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:14:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:14:41 --> Total execution time: 0.0679
DEBUG - 2024-03-16 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:14:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:51:21 --> Total execution time: 0.1644
DEBUG - 2024-03-16 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:51:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:51:43 --> Total execution time: 0.0970
DEBUG - 2024-03-16 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:51:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:51:45 --> Total execution time: 0.0782
DEBUG - 2024-03-16 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:51:55 --> Total execution time: 0.1370
DEBUG - 2024-03-16 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:51:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:51:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:53:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:53:26 --> Total execution time: 0.2161
DEBUG - 2024-03-16 10:53:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:53:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:53:41 --> Total execution time: 0.1328
DEBUG - 2024-03-16 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:53:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:54:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:54:16 --> Total execution time: 0.1366
DEBUG - 2024-03-16 10:54:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:54:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:54:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:54:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:54:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:54:31 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:54:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:55:33 --> Total execution time: 0.0700
DEBUG - 2024-03-16 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:33 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:34 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-16 10:55:34 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:55:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:55:37 --> Total execution time: 0.1091
DEBUG - 2024-03-16 10:55:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:38 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-16 10:55:38 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:55:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:39 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:55:41 --> Total execution time: 0.0627
DEBUG - 2024-03-16 10:55:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:42 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:42 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:42 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:55:57 --> Total execution time: 0.1327
DEBUG - 2024-03-16 10:55:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:55:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:57 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:57 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:58 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:55:58 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:56:12 --> Total execution time: 0.1230
DEBUG - 2024-03-16 10:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:13 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:56:23 --> Total execution time: 0.1248
DEBUG - 2024-03-16 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:23 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:23 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:56:30 --> Total execution time: 0.1427
DEBUG - 2024-03-16 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:31 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:56:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:56:32 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 10:57:21 --> Total execution time: 0.2252
DEBUG - 2024-03-16 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:57:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:57:22 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:57:22 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:57:23 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 10:57:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 10:57:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 10:57:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:26:07 --> Total execution time: 0.0791
DEBUG - 2024-03-16 12:26:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:26:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:26:10 --> Total execution time: 0.0852
DEBUG - 2024-03-16 12:26:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:26:16 --> Total execution time: 0.0620
DEBUG - 2024-03-16 12:26:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:26:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:26:21 --> Total execution time: 0.0681
DEBUG - 2024-03-16 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:26:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:26:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:26:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:26:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:39 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 12:26:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:26:39 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:37:30 --> Total execution time: 0.0807
DEBUG - 2024-03-16 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:31 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:31 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-16 12:37:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:31 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:37:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:37:33 --> Total execution time: 0.3639
DEBUG - 2024-03-16 12:37:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:34 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-03-16 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:34 --> 404 Page Not Found: Assets/css
ERROR - 2024-03-16 12:37:34 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-16 12:37:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:37:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:38:37 --> Total execution time: 0.1390
DEBUG - 2024-03-16 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:38:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:38:38 --> 404 Page Not Found: Images/property
DEBUG - 2024-03-16 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:38:38 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-03-16 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:38:52 --> Total execution time: 0.1167
DEBUG - 2024-03-16 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:38:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:38:52 --> 404 Page Not Found: Images/property
ERROR - 2024-03-16 12:38:52 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-03-16 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:39:23 --> Total execution time: 0.1434
DEBUG - 2024-03-16 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:39:23 --> 404 Page Not Found: Images/property
DEBUG - 2024-03-16 12:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:39:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:39:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2024-03-16 12:39:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:39:32 --> Total execution time: 0.1160
DEBUG - 2024-03-16 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:39:32 --> 404 Page Not Found: Images/property
DEBUG - 2024-03-16 12:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:39:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:40:21 --> Total execution time: 0.1154
DEBUG - 2024-03-16 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:40:21 --> 404 Page Not Found: Images/property
ERROR - 2024-03-16 12:40:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:40:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:40:46 --> Total execution time: 0.1515
DEBUG - 2024-03-16 12:40:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:40:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:40:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:40:46 --> 404 Page Not Found: Images/property
DEBUG - 2024-03-16 12:40:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:40:58 --> Total execution time: 0.1394
DEBUG - 2024-03-16 12:40:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:40:58 --> UTF-8 Support Enabled
ERROR - 2024-03-16 12:40:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:40:58 --> 404 Page Not Found: Images/property
DEBUG - 2024-03-16 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:41:10 --> Total execution time: 0.1349
DEBUG - 2024-03-16 12:41:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:41:11 --> UTF-8 Support Enabled
ERROR - 2024-03-16 12:41:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:41:11 --> 404 Page Not Found: Images/property
DEBUG - 2024-03-16 12:41:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:41:57 --> Total execution time: 1.0163
DEBUG - 2024-03-16 12:41:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:41:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:41:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:42:45 --> Total execution time: 0.1706
DEBUG - 2024-03-16 12:42:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:42:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:43:24 --> Total execution time: 0.1470
DEBUG - 2024-03-16 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:43:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:43:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:44:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:44:23 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:44:23 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:44:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:44:24 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:46:27 --> Total execution time: 0.0987
DEBUG - 2024-03-16 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:46:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:46:28 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:46:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:46:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:46:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:46:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 12:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 12:47:00 --> Total execution time: 0.1434
DEBUG - 2024-03-16 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:47:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:47:01 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:47:01 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-16 12:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:47:01 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 12:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 12:47:01 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-16 13:00:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 13:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 13:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 13:00:51 --> Total execution time: 0.1206
DEBUG - 2024-03-16 13:00:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 13:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 13:00:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 13:01:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 13:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 13:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 13:01:32 --> Total execution time: 0.1243
DEBUG - 2024-03-16 13:01:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 13:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 13:01:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-16 13:02:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 13:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-16 13:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-16 13:02:11 --> Total execution time: 0.1299
DEBUG - 2024-03-16 13:02:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-16 13:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-16 13:02:11 --> 404 Page Not Found: Assets/datatables

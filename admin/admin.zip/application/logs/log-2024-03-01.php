<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-01 12:41:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:09 --> No URI present. Default controller set.
DEBUG - 2024-03-01 12:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:41:09 --> Total execution time: 0.9666
DEBUG - 2024-03-01 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:41:10 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-01 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:41:15 --> Total execution time: 0.1762
DEBUG - 2024-03-01 12:41:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:41:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:41:19 --> Total execution time: 0.0928
DEBUG - 2024-03-01 12:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:41:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:41:40 --> Total execution time: 0.0785
DEBUG - 2024-03-01 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:41:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:41:47 --> Total execution time: 0.1137
DEBUG - 2024-03-01 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:41:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:42:58 --> Total execution time: 0.0760
DEBUG - 2024-03-01 12:42:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:42:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:42:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:44:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:34 --> Total execution time: 0.0947
DEBUG - 2024-03-01 12:44:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:44:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:40 --> Total execution time: 0.1043
DEBUG - 2024-03-01 12:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:44:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:44:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:48 --> Total execution time: 0.0858
DEBUG - 2024-03-01 12:44:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:44:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:44:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:51 --> Total execution time: 0.0917
DEBUG - 2024-03-01 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:55 --> Total execution time: 0.0670
DEBUG - 2024-03-01 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:44:55 --> Total execution time: 0.0647
DEBUG - 2024-03-01 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:44:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:50:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:50:37 --> Total execution time: 0.0839
DEBUG - 2024-03-01 12:50:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:50:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:50:41 --> Total execution time: 0.0818
DEBUG - 2024-03-01 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:50:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:50:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 12:50:49 --> Severity: error --> Exception: Call to undefined method GetData::addpackage() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 463
DEBUG - 2024-03-01 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 12:51:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\models\GetData.php 338
DEBUG - 2024-03-01 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:51:20 --> Total execution time: 0.0568
DEBUG - 2024-03-01 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:51:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:51:27 --> Total execution time: 0.0653
DEBUG - 2024-03-01 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:51:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 12:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\models\GetData.php 338
DEBUG - 2024-03-01 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:51:32 --> Total execution time: 0.0767
DEBUG - 2024-03-01 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:51:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:52:07 --> Total execution time: 0.0658
DEBUG - 2024-03-01 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:52:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:52:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:53:16 --> Total execution time: 0.0726
DEBUG - 2024-03-01 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:53:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:53:19 --> Total execution time: 0.0728
DEBUG - 2024-03-01 12:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:53:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:53:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 12:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\models\GetData.php 338
DEBUG - 2024-03-01 12:53:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:53:25 --> Total execution time: 0.0606
DEBUG - 2024-03-01 12:53:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:53:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 12:58:15 --> Total execution time: 0.1406
DEBUG - 2024-03-01 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:58:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:58:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 12:58:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 12:58:18 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `package` (`title`) VALUES (NULL)
DEBUG - 2024-03-01 12:58:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:58:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 12:58:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 506
DEBUG - 2024-03-01 12:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 12:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 12:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 12:59:38 --> Severity: Notice --> Undefined property: Welcome::$YourModel C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 468
ERROR - 2024-03-01 12:59:38 --> Severity: error --> Exception: Call to a member function addpackage() on null C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 468
DEBUG - 2024-03-01 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 13:00:02 --> Severity: Notice --> Undefined property: Welcome::$YourModel C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 467
ERROR - 2024-03-01 13:00:02 --> Severity: error --> Exception: Call to a member function addpackage() on null C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 467
DEBUG - 2024-03-01 13:00:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 13:00:17 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `package` (`title`) VALUES (NULL)
DEBUG - 2024-03-01 13:01:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 13:01:14 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `package` (`title`) VALUES (NULL)
DEBUG - 2024-03-01 13:01:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 13:01:15 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `package` (`title`) VALUES (NULL)
DEBUG - 2024-03-01 13:02:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:02:06 --> Total execution time: 0.0936
DEBUG - 2024-03-01 13:02:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:02:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:02:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-01 13:02:14 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `package` (`title`) VALUES (NULL)
DEBUG - 2024-03-01 13:02:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:02:58 --> Total execution time: 0.0811
DEBUG - 2024-03-01 13:02:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:02:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:09:52 --> Total execution time: 0.0780
DEBUG - 2024-03-01 13:10:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:10:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:10:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:10:01 --> Total execution time: 0.0568
DEBUG - 2024-03-01 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:10:02 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-01 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:10:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:10:07 --> Total execution time: 0.0661
DEBUG - 2024-03-01 13:10:07 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:10:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:10:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:10:12 --> Total execution time: 0.0705
DEBUG - 2024-03-01 13:10:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:10:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:11:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:15 --> Severity: Compile Error --> Cannot redeclare Welcome::add_package() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 484
DEBUG - 2024-03-01 13:11:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:34 --> Severity: Compile Error --> Cannot redeclare Welcome::add_package() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 473
DEBUG - 2024-03-01 13:11:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:37 --> Severity: Compile Error --> Cannot redeclare Welcome::add_package() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 473
DEBUG - 2024-03-01 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:39 --> Severity: Compile Error --> Cannot redeclare Welcome::add_package() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 473
DEBUG - 2024-03-01 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:40 --> Severity: Compile Error --> Cannot redeclare Welcome::add_package() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 473
DEBUG - 2024-03-01 13:11:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:11:50 --> Total execution time: 0.0989
DEBUG - 2024-03-01 13:11:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:11:59 --> Total execution time: 0.1252
DEBUG - 2024-03-01 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:11:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:11:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:12:03 --> Total execution time: 0.0642
DEBUG - 2024-03-01 13:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:12:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:12:09 --> Total execution time: 0.0623
DEBUG - 2024-03-01 13:12:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:12:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:12:59 --> Total execution time: 0.1089
DEBUG - 2024-03-01 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:12:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:13:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:13:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:13:05 --> Total execution time: 0.0619
DEBUG - 2024-03-01 13:13:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:13:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:13:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:15:34 --> Total execution time: 0.0961
DEBUG - 2024-03-01 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:15:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:15:38 --> Total execution time: 0.0682
DEBUG - 2024-03-01 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:15:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:15:42 --> Total execution time: 0.0705
DEBUG - 2024-03-01 13:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:15:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:17:30 --> Total execution time: 0.0924
DEBUG - 2024-03-01 13:17:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:17:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:17:33 --> Total execution time: 0.0622
DEBUG - 2024-03-01 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:17:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:17:38 --> Total execution time: 0.0622
DEBUG - 2024-03-01 13:17:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:17:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:21:02 --> Total execution time: 0.0897
DEBUG - 2024-03-01 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:21:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:21:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:21:05 --> Total execution time: 0.0612
DEBUG - 2024-03-01 13:21:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:21:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:21:11 --> Total execution time: 0.0561
DEBUG - 2024-03-01 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:21:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:22:21 --> Total execution time: 0.0823
DEBUG - 2024-03-01 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:22:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:22:24 --> Total execution time: 0.0622
DEBUG - 2024-03-01 13:22:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:22:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:22:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:22:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:22:30 --> Total execution time: 0.0712
DEBUG - 2024-03-01 13:22:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:22:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:22:48 --> Total execution time: 0.0594
DEBUG - 2024-03-01 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:22:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:23:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:23:19 --> Total execution time: 0.0991
DEBUG - 2024-03-01 13:23:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:23:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:23:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:23:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:23:25 --> Total execution time: 0.0561
DEBUG - 2024-03-01 13:23:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:23:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:24:02 --> Total execution time: 0.0597
DEBUG - 2024-03-01 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:24:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:24:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:24:56 --> Total execution time: 0.0557
DEBUG - 2024-03-01 13:24:56 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:24:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:25:42 --> Total execution time: 0.0638
DEBUG - 2024-03-01 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:25:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:25:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:25:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:25:48 --> Total execution time: 0.0614
DEBUG - 2024-03-01 13:25:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:25:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:25:53 --> Total execution time: 0.0638
DEBUG - 2024-03-01 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:25:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:26:15 --> Total execution time: 0.0603
DEBUG - 2024-03-01 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:26:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:26:26 --> Total execution time: 0.0779
DEBUG - 2024-03-01 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:26:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:26:46 --> Total execution time: 0.0610
DEBUG - 2024-03-01 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:26:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:27:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:27:04 --> Total execution time: 0.0597
DEBUG - 2024-03-01 13:27:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:27:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:27:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:27:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:27:37 --> Total execution time: 0.0747
DEBUG - 2024-03-01 13:27:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:27:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:27:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:27:41 --> Total execution time: 0.0751
DEBUG - 2024-03-01 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:28:37 --> Total execution time: 0.1104
DEBUG - 2024-03-01 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:28:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:28:48 --> Total execution time: 0.0679
DEBUG - 2024-03-01 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:28:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:29:08 --> Total execution time: 0.0886
DEBUG - 2024-03-01 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:29:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:29:46 --> Total execution time: 0.1411
DEBUG - 2024-03-01 13:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:29:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:29:54 --> Total execution time: 0.0658
DEBUG - 2024-03-01 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:29:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:30:00 --> Total execution time: 0.0754
DEBUG - 2024-03-01 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:30:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:30:05 --> Total execution time: 0.0618
DEBUG - 2024-03-01 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:30:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:31:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:31:52 --> Total execution time: 0.1282
DEBUG - 2024-03-01 13:31:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:31:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:31:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:33:23 --> Total execution time: 0.1083
DEBUG - 2024-03-01 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:33:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:34:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:34:43 --> Total execution time: 0.1085
DEBUG - 2024-03-01 13:34:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:34:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:35:51 --> Total execution time: 0.1074
DEBUG - 2024-03-01 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:35:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:35:57 --> Total execution time: 0.0751
DEBUG - 2024-03-01 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:35:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:37:50 --> Total execution time: 0.1365
DEBUG - 2024-03-01 13:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:37:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:37:58 --> Total execution time: 0.0554
DEBUG - 2024-03-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:37:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:37:59 --> Total execution time: 0.0739
DEBUG - 2024-03-01 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:37:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:38:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:38:01 --> Total execution time: 0.0580
DEBUG - 2024-03-01 13:38:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:38:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:38:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:39:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:39:03 --> Total execution time: 0.1367
DEBUG - 2024-03-01 13:39:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:39:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:40:43 --> Total execution time: 0.1341
DEBUG - 2024-03-01 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:40:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:41:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:41:15 --> Total execution time: 0.1394
DEBUG - 2024-03-01 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:41:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:41:49 --> Total execution time: 0.2111
DEBUG - 2024-03-01 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:41:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:42:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:42:04 --> Total execution time: 0.1607
DEBUG - 2024-03-01 13:42:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:42:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:42:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:42:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:42:19 --> Total execution time: 0.1281
DEBUG - 2024-03-01 13:42:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:42:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:42:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:52:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:52:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:52:10 --> Total execution time: 0.0648
DEBUG - 2024-03-01 13:52:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:52:11 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-01 13:52:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:52:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:52:16 --> Total execution time: 0.0686
DEBUG - 2024-03-01 13:52:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:52:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 13:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 13:52:21 --> Total execution time: 0.1223
DEBUG - 2024-03-01 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 13:52:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:01:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:01:15 --> Total execution time: 0.1219
DEBUG - 2024-03-01 14:01:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:01:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:01:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:01:35 --> Total execution time: 0.1756
DEBUG - 2024-03-01 14:01:35 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:01:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:01:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:02:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:02:31 --> Total execution time: 0.1326
DEBUG - 2024-03-01 14:02:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:02:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:02:42 --> Total execution time: 0.0592
DEBUG - 2024-03-01 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:02:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:03:17 --> Total execution time: 0.1387
DEBUG - 2024-03-01 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:03:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:04:33 --> Total execution time: 0.1302
DEBUG - 2024-03-01 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:04:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:04:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:04:41 --> Total execution time: 0.0641
DEBUG - 2024-03-01 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:04:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:05:05 --> Total execution time: 0.0715
DEBUG - 2024-03-01 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:05:05 --> Total execution time: 0.0796
DEBUG - 2024-03-01 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:05:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:05:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:05:19 --> Total execution time: 0.0819
DEBUG - 2024-03-01 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:05:19 --> Total execution time: 0.0916
DEBUG - 2024-03-01 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:05:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:05:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:06:38 --> Total execution time: 0.1208
DEBUG - 2024-03-01 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:06:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:06:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:06:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:06:42 --> Total execution time: 0.0576
DEBUG - 2024-03-01 14:06:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:06:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:06:58 --> Total execution time: 0.1262
DEBUG - 2024-03-01 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:06:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:07:45 --> Total execution time: 0.1266
DEBUG - 2024-03-01 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:07:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:13:43 --> Total execution time: 0.1552
DEBUG - 2024-03-01 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:13:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:13:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:14:40 --> Total execution time: 0.1643
DEBUG - 2024-03-01 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:14:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:15:29 --> Total execution time: 0.2170
DEBUG - 2024-03-01 14:15:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:15:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:16:21 --> Total execution time: 0.1199
DEBUG - 2024-03-01 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:16:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:19:14 --> Total execution time: 0.1445
DEBUG - 2024-03-01 14:19:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:19:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:21:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:21:09 --> Total execution time: 0.1382
DEBUG - 2024-03-01 14:21:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:21:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:22:33 --> Total execution time: 0.1379
DEBUG - 2024-03-01 14:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:22:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:23:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:23:01 --> Total execution time: 0.1532
DEBUG - 2024-03-01 14:23:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:23:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:23:18 --> Total execution time: 0.1326
DEBUG - 2024-03-01 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:23:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 14:23:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:23:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:23:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:23:31 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-01 14:23:31 --> Total execution time: 0.0962
DEBUG - 2024-03-01 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 14:24:02 --> Total execution time: 0.1999
DEBUG - 2024-03-01 14:24:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 14:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 14:24:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-01 15:22:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 15:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 15:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 15:22:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 15:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 15:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 15:22:54 --> Total execution time: 0.0804
DEBUG - 2024-03-01 15:22:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 15:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 15:22:55 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-01 15:23:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 15:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 15:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 15:23:00 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 15:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-01 15:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-01 15:23:00 --> Total execution time: 0.0705
DEBUG - 2024-03-01 15:23:01 --> UTF-8 Support Enabled
DEBUG - 2024-03-01 15:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-01 15:23:01 --> 404 Page Not Found: Assets/datatables

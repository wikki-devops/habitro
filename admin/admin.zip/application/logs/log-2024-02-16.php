<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-16 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:47:40 --> No URI present. Default controller set.
DEBUG - 2024-02-16 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 05:47:40 --> Total execution time: 0.0862
DEBUG - 2024-02-16 05:47:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:47:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:47:46 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-16 05:48:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 05:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 05:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 05:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 05:48:24 --> Total execution time: 0.0262
DEBUG - 2024-02-16 05:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:48:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 05:48:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:48:24 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 05:48:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 05:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 05:48:38 --> Total execution time: 0.0151
DEBUG - 2024-02-16 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:48:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:48:39 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 05:49:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 05:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 05:49:01 --> Total execution time: 0.0157
DEBUG - 2024-02-16 05:49:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:49:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 05:49:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 05:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 05:49:01 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 09:24:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:25 --> No URI present. Default controller set.
DEBUG - 2024-02-16 09:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:24:25 --> Total execution time: 0.1198
DEBUG - 2024-02-16 09:24:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:26 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-16 09:24:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:24:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:24:37 --> Total execution time: 0.0137
DEBUG - 2024-02-16 09:24:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 09:24:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:37 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:24:42 --> Total execution time: 0.0157
DEBUG - 2024-02-16 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:42 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 09:24:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:24:47 --> Total execution time: 0.0054
DEBUG - 2024-02-16 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:24:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:25:17 --> Total execution time: 0.0056
DEBUG - 2024-02-16 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:25:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:25:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:25:27 --> Total execution time: 0.0078
DEBUG - 2024-02-16 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:25:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:25:27 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-16 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-16 09:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-16 09:28:51 --> Total execution time: 0.0668
DEBUG - 2024-02-16 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:28:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-16 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-16 09:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-16 09:28:52 --> 404 Page Not Found: Vendor/summernote

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-22 16:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:19 --> No URI present. Default controller set.
DEBUG - 2024-02-22 16:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:19 --> Total execution time: 0.9353
DEBUG - 2024-02-22 16:49:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-22 16:49:20 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-22 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:24 --> Total execution time: 0.1244
DEBUG - 2024-02-22 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-22 16:49:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-22 16:49:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:40 --> Total execution time: 0.0542
DEBUG - 2024-02-22 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:46 --> Total execution time: 0.0789
DEBUG - 2024-02-22 16:49:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:49:52 --> Total execution time: 0.0718
DEBUG - 2024-02-22 16:50:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:50:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:50:05 --> Total execution time: 0.1268
DEBUG - 2024-02-22 16:50:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:50:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-22 16:50:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-22 16:51:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:51:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:51:10 --> Total execution time: 0.0683
DEBUG - 2024-02-22 16:51:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:51:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:51:21 --> Total execution time: 0.0691
DEBUG - 2024-02-22 16:51:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:51:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:51:35 --> Total execution time: 0.0630
DEBUG - 2024-02-22 16:51:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-22 16:51:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-22 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:02 --> Total execution time: 0.0749
DEBUG - 2024-02-22 16:52:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:06 --> Total execution time: 0.0566
DEBUG - 2024-02-22 16:52:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-22 16:52:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-22 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:18 --> Total execution time: 0.0662
DEBUG - 2024-02-22 16:52:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 16:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 16:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 16:52:28 --> Total execution time: 0.0567
DEBUG - 2024-02-22 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 17:08:51 --> Total execution time: 0.0624
DEBUG - 2024-02-22 17:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 17:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 17:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 17:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 17:09:03 --> Total execution time: 0.0598
DEBUG - 2024-02-22 17:09:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-22 17:09:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-22 17:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 17:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 17:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-22 17:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-22 17:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-22 17:18:34 --> Total execution time: 0.0694

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-05 09:05:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 09:05:02 --> No URI present. Default controller set.
DEBUG - 2024-03-05 09:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 09:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 09:05:04 --> Total execution time: 2.1494
DEBUG - 2024-03-05 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 09:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 09:05:09 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-05 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 09:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 09:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 09:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 09:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 09:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 09:05:10 --> Total execution time: 0.2183
DEBUG - 2024-03-05 09:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 09:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 09:05:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 11:24:24 --> Total execution time: 0.0713
DEBUG - 2024-03-05 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 11:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 11:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 11:24:30 --> Total execution time: 0.0672
DEBUG - 2024-03-05 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 11:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 11:24:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:32:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:32:47 --> Total execution time: 0.0751
DEBUG - 2024-03-05 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:32:48 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-05 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:32:53 --> Total execution time: 0.1146
DEBUG - 2024-03-05 13:32:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:32:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:42:12 --> Total execution time: 0.0547
DEBUG - 2024-03-05 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:42:17 --> Total execution time: 0.0528
DEBUG - 2024-03-05 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:42:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:42:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:42:42 --> Total execution time: 0.0822
DEBUG - 2024-03-05 13:42:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:42:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:44:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:44:29 --> Total execution time: 0.1357
DEBUG - 2024-03-05 13:44:29 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:44:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:44:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:53:40 --> Total execution time: 0.0699
DEBUG - 2024-03-05 13:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:53:44 --> Total execution time: 0.0541
DEBUG - 2024-03-05 13:53:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:53:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:53:46 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-05 13:53:46 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\habitro\admin\application\views\pricing.php 179
DEBUG - 2024-03-05 13:53:47 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:53:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:53:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-05 13:53:52 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\habitro\admin\application\views\pricing.php 179
DEBUG - 2024-03-05 13:53:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:53:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:54:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-05 13:54:37 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\habitro\admin\application\views\pricing.php 181
DEBUG - 2024-03-05 13:54:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:54:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-03-05 13:54:48 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\habitro\admin\application\views\pricing.php 178
DEBUG - 2024-03-05 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:54:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 13:54:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 13:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 13:54:58 --> Total execution time: 0.1100
DEBUG - 2024-03-05 13:54:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 13:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 13:54:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-05 14:50:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 14:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 14:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 14:50:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 14:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 14:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 14:50:19 --> Total execution time: 0.0628
DEBUG - 2024-03-05 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 14:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 14:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 14:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-05 14:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-05 14:50:24 --> Total execution time: 0.0605
DEBUG - 2024-03-05 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-05 14:50:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-05 14:50:24 --> 404 Page Not Found: Assets/datatables

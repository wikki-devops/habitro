<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-08 07:34:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:34:36 --> No URI present. Default controller set.
DEBUG - 2024-02-08 07:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 07:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 07:34:36 --> Total execution time: 0.1887
DEBUG - 2024-02-08 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 07:34:37 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-08 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 07:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 07:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 07:36:14 --> Total execution time: 0.0975
DEBUG - 2024-02-08 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 07:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 07:36:14 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 07:36:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 07:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 07:36:14 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 07:36:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 07:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 07:36:16 --> UTF-8 Support Enabled
ERROR - 2024-02-08 07:36:16 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 07:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 07:36:16 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:28 --> Total execution time: 0.1039
DEBUG - 2024-02-08 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:36 --> Total execution time: 0.1146
DEBUG - 2024-02-08 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:11:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-08 10:11:36 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 10:11:36 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:11:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:11:38 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:11:38 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:52 --> Total execution time: 0.1107
DEBUG - 2024-02-08 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:11:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:11:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:56 --> Total execution time: 0.1365
DEBUG - 2024-02-08 10:11:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:11:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:11:58 --> Total execution time: 0.1058
DEBUG - 2024-02-08 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:11:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:12:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:12:00 --> Total execution time: 0.0947
DEBUG - 2024-02-08 10:12:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:12:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:12:03 --> Total execution time: 0.0602
DEBUG - 2024-02-08 10:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:12:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:15:03 --> Total execution time: 0.0790
DEBUG - 2024-02-08 10:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:15:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:15:46 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-08 10:15:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:15:46 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-08 10:15:46 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:17:27 --> Total execution time: 0.4326
DEBUG - 2024-02-08 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:17:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:17:28 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-08 10:17:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:17:28 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:17:56 --> Total execution time: 0.0575
DEBUG - 2024-02-08 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:17:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-08 10:17:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:17:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:18:16 --> Total execution time: 0.0585
DEBUG - 2024-02-08 10:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:16 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:16 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:17 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:18:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:18:33 --> Total execution time: 0.0659
DEBUG - 2024-02-08 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:34 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:18:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:19:29 --> Total execution time: 0.0579
DEBUG - 2024-02-08 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:19:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:19:29 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:19:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:19:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:19:30 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:20:43 --> Total execution time: 0.0639
DEBUG - 2024-02-08 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:44 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-08 10:20:44 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:44 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:20:55 --> Total execution time: 0.0517
DEBUG - 2024-02-08 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:56 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:20:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:23:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:23:01 --> Total execution time: 0.0734
DEBUG - 2024-02-08 10:23:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:23:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:23:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:23:03 --> Total execution time: 0.0815
DEBUG - 2024-02-08 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:23:04 --> Total execution time: 0.0844
DEBUG - 2024-02-08 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:23:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:23:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:25:15 --> Total execution time: 0.0663
DEBUG - 2024-02-08 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:25:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:25:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:34:57 --> Total execution time: 0.0989
DEBUG - 2024-02-08 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:34:58 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-08 10:35:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:35:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:35:05 --> Total execution time: 0.0711
DEBUG - 2024-02-08 10:35:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:05 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 10:35:05 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:35:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:06 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:06 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:35:09 --> Total execution time: 0.1123
DEBUG - 2024-02-08 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:16 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:16 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:35:16 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:43:36 --> Total execution time: 0.0721
DEBUG - 2024-02-08 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:43:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:43:50 --> Total execution time: 0.0598
DEBUG - 2024-02-08 10:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:43:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:44:26 --> Total execution time: 0.0606
DEBUG - 2024-02-08 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:44:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:44:32 --> Total execution time: 0.0609
DEBUG - 2024-02-08 10:44:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:44:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:44:40 --> Total execution time: 0.0582
DEBUG - 2024-02-08 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:44:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:58:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:58:10 --> Total execution time: 0.0749
DEBUG - 2024-02-08 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:58:25 --> Total execution time: 0.0766
DEBUG - 2024-02-08 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:25 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:25 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:58:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:27 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:27 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:58:30 --> Total execution time: 0.0705
DEBUG - 2024-02-08 10:58:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:58:58 --> Total execution time: 0.0686
DEBUG - 2024-02-08 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:58:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:58:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 10:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 10:59:14 --> Total execution time: 0.0571
DEBUG - 2024-02-08 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 10:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 10:59:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:00:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:00:38 --> Total execution time: 0.0680
DEBUG - 2024-02-08 11:00:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:00:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:01:59 --> Total execution time: 0.0874
DEBUG - 2024-02-08 11:01:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:01:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:02:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:02:47 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-08 11:02:47 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:03:45 --> Total execution time: 0.0850
DEBUG - 2024-02-08 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:03:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:03:45 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:03:45 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-08 11:03:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:08:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:08:59 --> Total execution time: 0.0666
DEBUG - 2024-02-08 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:08:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:08:59 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:08:59 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:08:59 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:17:24 --> Total execution time: 0.0774
DEBUG - 2024-02-08 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:17:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:20:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:20:28 --> Total execution time: 0.0721
DEBUG - 2024-02-08 11:20:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:20:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:20:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:21:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:21:15 --> Total execution time: 0.0664
DEBUG - 2024-02-08 11:21:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:21:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:21:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:21:19 --> 404 Page Not Found: Welcome/update_package
DEBUG - 2024-02-08 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:39:11 --> Total execution time: 0.0657
DEBUG - 2024-02-08 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:12 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-08 11:39:12 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:12 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:12 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-08 11:39:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:39:20 --> Total execution time: 0.0556
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:20 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:20 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:20 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-08 11:39:20 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:20 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:22 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 11:39:22 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:39:22 --> Total execution time: 0.1636
DEBUG - 2024-02-08 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:23 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-08 11:39:23 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:23 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:39:27 --> Total execution time: 0.0722
DEBUG - 2024-02-08 11:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:27 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 11:39:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:39:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-08 11:41:02 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 25
ERROR - 2024-02-08 11:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 25
ERROR - 2024-02-08 11:41:02 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 72
ERROR - 2024-02-08 11:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 72
ERROR - 2024-02-08 11:41:02 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 115
ERROR - 2024-02-08 11:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 115
ERROR - 2024-02-08 11:41:02 --> Severity: Notice --> Undefined variable: brands C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 160
ERROR - 2024-02-08 11:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 160
DEBUG - 2024-02-08 11:41:02 --> Total execution time: 0.1291
DEBUG - 2024-02-08 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:41:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:41:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:41:33 --> Total execution time: 0.0759
DEBUG - 2024-02-08 11:41:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:41:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:41:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:41:42 --> Total execution time: 0.0631
DEBUG - 2024-02-08 11:41:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:41:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:41:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:41:49 --> Total execution time: 0.0614
DEBUG - 2024-02-08 11:41:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:41:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:41:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:41:59 --> Total execution time: 0.0602
DEBUG - 2024-02-08 11:41:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:41:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:41:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:44:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:44:20 --> Total execution time: 0.0930
DEBUG - 2024-02-08 11:44:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:44:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:44:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-08 11:44:29 --> Severity: error --> Exception: Call to undefined method GetData::update_package() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 553
DEBUG - 2024-02-08 11:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:45:27 --> Total execution time: 0.0681
DEBUG - 2024-02-08 11:45:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:45:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:45:42 --> Total execution time: 0.0628
DEBUG - 2024-02-08 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:45:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:45:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:51:02 --> Total execution time: 0.1108
DEBUG - 2024-02-08 11:51:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:51:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:51:33 --> Total execution time: 0.1205
DEBUG - 2024-02-08 11:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:51:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:51:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:51:34 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-08 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:51:34 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-08 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:54:06 --> Total execution time: 0.0779
DEBUG - 2024-02-08 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:54:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:55:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:55:05 --> Total execution time: 0.0715
DEBUG - 2024-02-08 11:55:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:55:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 11:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 11:55:38 --> Total execution time: 0.0670
DEBUG - 2024-02-08 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 11:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 11:55:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:10 --> Total execution time: 0.0628
DEBUG - 2024-02-08 12:05:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:11 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-08 12:05:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:14 --> Total execution time: 0.0689
DEBUG - 2024-02-08 12:05:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:15 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-08 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:23 --> Total execution time: 0.0884
DEBUG - 2024-02-08 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:05:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:25 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 12:05:25 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:27 --> Total execution time: 0.1102
DEBUG - 2024-02-08 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:05:30 --> Total execution time: 0.0902
DEBUG - 2024-02-08 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:05:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:13:47 --> Total execution time: 0.0949
DEBUG - 2024-02-08 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:13:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:13:47 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 12:13:47 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:13:49 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 12:13:49 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:16 --> 404 Page Not Found: Welcome/www.habitro.com
DEBUG - 2024-02-08 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:24 --> Total execution time: 0.0875
DEBUG - 2024-02-08 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:34 --> Total execution time: 0.0903
DEBUG - 2024-02-08 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:34 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:34 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:14:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:36 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 12:14:36 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:39 --> Total execution time: 0.1468
DEBUG - 2024-02-08 12:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:52 --> Total execution time: 0.0893
DEBUG - 2024-02-08 12:14:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:14:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:14:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:14:59 --> Total execution time: 0.0943
DEBUG - 2024-02-08 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:15:04 --> Total execution time: 0.0986
DEBUG - 2024-02-08 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:15:04 --> UTF-8 Support Enabled
ERROR - 2024-02-08 12:15:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-08 12:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:15:04 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:15:04 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:15:06 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-08 12:15:06 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-08 12:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-08 12:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-08 12:15:09 --> Total execution time: 0.1059
DEBUG - 2024-02-08 12:15:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-08 12:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-08 12:15:09 --> 404 Page Not Found: Assets/datatables

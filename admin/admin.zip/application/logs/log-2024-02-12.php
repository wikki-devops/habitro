<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-12 07:24:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:45 --> No URI present. Default controller set.
DEBUG - 2024-02-12 07:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:24:46 --> Total execution time: 0.9524
DEBUG - 2024-02-12 07:24:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:24:46 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 07:24:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:24:53 --> Total execution time: 0.0495
DEBUG - 2024-02-12 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:24:59 --> Total execution time: 0.1237
DEBUG - 2024-02-12 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:24:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:24:59 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:24:59 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:25:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:02 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 07:25:02 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:25:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:06 --> Total execution time: 0.1177
DEBUG - 2024-02-12 07:25:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:25:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:11 --> Total execution time: 0.0745
DEBUG - 2024-02-12 07:25:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:11 --> Total execution time: 0.0633
DEBUG - 2024-02-12 07:25:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:13 --> Total execution time: 0.0779
DEBUG - 2024-02-12 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:13 --> Total execution time: 0.0631
DEBUG - 2024-02-12 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:16 --> Total execution time: 0.0606
DEBUG - 2024-02-12 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:16 --> Total execution time: 0.0577
DEBUG - 2024-02-12 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:19 --> Total execution time: 0.0696
DEBUG - 2024-02-12 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:19 --> Total execution time: 0.0601
DEBUG - 2024-02-12 07:25:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:22 --> Total execution time: 0.0572
DEBUG - 2024-02-12 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:25:22 --> Total execution time: 0.0645
DEBUG - 2024-02-12 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:25:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:47:15 --> Total execution time: 0.0626
DEBUG - 2024-02-12 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:47:21 --> Total execution time: 0.0550
DEBUG - 2024-02-12 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:21 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:22 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 07:47:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:47:26 --> Total execution time: 0.1055
DEBUG - 2024-02-12 07:47:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:47:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:47:37 --> Total execution time: 0.0943
DEBUG - 2024-02-12 07:47:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:47:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:49:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:49:00 --> Total execution time: 0.1651
DEBUG - 2024-02-12 07:49:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:49:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:49:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:49:04 --> Total execution time: 0.0737
DEBUG - 2024-02-12 07:49:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:49:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:51:01 --> Total execution time: 0.1002
DEBUG - 2024-02-12 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:51:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:51:03 --> Total execution time: 0.0925
DEBUG - 2024-02-12 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:51:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:51:06 --> Total execution time: 0.0554
DEBUG - 2024-02-12 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:51:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:51:50 --> Total execution time: 0.6759
DEBUG - 2024-02-12 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:51:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:52:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:52:49 --> Total execution time: 0.1044
DEBUG - 2024-02-12 07:52:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:52:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:53:00 --> Total execution time: 0.1413
DEBUG - 2024-02-12 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:53:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:53:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:53:02 --> Total execution time: 0.1036
DEBUG - 2024-02-12 07:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:53:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:53:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:53:04 --> Total execution time: 0.0652
DEBUG - 2024-02-12 07:53:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:53:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:53:19 --> Total execution time: 0.0747
DEBUG - 2024-02-12 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:53:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:53:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:53:21 --> Total execution time: 0.0669
DEBUG - 2024-02-12 07:53:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:53:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:53:40 --> Total execution time: 0.0616
DEBUG - 2024-02-12 07:53:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:53:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:53:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:55:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:55:50 --> Total execution time: 0.1196
DEBUG - 2024-02-12 07:55:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:55:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:55:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:56:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:56:01 --> 404 Page Not Found: Welcome/cconstruction
DEBUG - 2024-02-12 07:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:56:23 --> Total execution time: 0.0985
DEBUG - 2024-02-12 07:56:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:56:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:56:26 --> Total execution time: 0.0697
DEBUG - 2024-02-12 07:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:57:01 --> Total execution time: 0.1184
DEBUG - 2024-02-12 07:57:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:57:04 --> Total execution time: 0.0554
DEBUG - 2024-02-12 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:57:12 --> Total execution time: 0.0671
DEBUG - 2024-02-12 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:57:33 --> Total execution time: 0.0974
DEBUG - 2024-02-12 07:57:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:57:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:47 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:47 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:57:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:57:47 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 07:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:58:36 --> Total execution time: 0.1226
DEBUG - 2024-02-12 07:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:36 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 07:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:36 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:58:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:37 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:58:50 --> Total execution time: 0.0591
DEBUG - 2024-02-12 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:50 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:50 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:58:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:51 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 07:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 07:58:56 --> Total execution time: 0.0559
DEBUG - 2024-02-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:56 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 07:58:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 07:58:56 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 09:34:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:34:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:34:43 --> Total execution time: 0.0765
DEBUG - 2024-02-12 09:34:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:43 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:34:48 --> Total execution time: 0.1051
DEBUG - 2024-02-12 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:48 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 09:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:48 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:49 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:49 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 09:34:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:34:52 --> Total execution time: 0.0843
DEBUG - 2024-02-12 09:34:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:34:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:34:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:02:11 --> Total execution time: 0.0681
DEBUG - 2024-02-12 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:02:17 --> Total execution time: 0.0713
DEBUG - 2024-02-12 10:02:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:02:17 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 10:02:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:02:17 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 10:02:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:02:18 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 10:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:02:18 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 10:02:22 --> Severity: Notice --> Undefined variable: brands C:\xampp\htdocs\habitro\admin\application\views\pages\residential.php 62
ERROR - 2024-02-12 10:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\habitro\admin\application\views\pages\residential.php 62
DEBUG - 2024-02-12 10:02:22 --> Total execution time: 0.1197
DEBUG - 2024-02-12 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:02:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:05:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 10:05:06 --> Severity: Notice --> Undefined property: Welcome::$GetaData C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 398
ERROR - 2024-02-12 10:05:06 --> Severity: error --> Exception: Call to a member function getresidentialbrands() on null C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 398
DEBUG - 2024-02-12 10:05:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 10:05:39 --> Severity: Notice --> Undefined property: Welcome::$GetaData C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 398
ERROR - 2024-02-12 10:05:39 --> Severity: error --> Exception: Call to a member function getresidentialbrands() on null C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 398
DEBUG - 2024-02-12 10:06:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:06:24 --> Total execution time: 0.1009
DEBUG - 2024-02-12 10:06:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:06:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:06:59 --> Total execution time: 0.0952
DEBUG - 2024-02-12 10:06:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:06:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:07:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:07:01 --> 404 Page Not Found: Welcome/add_residentialpartner
DEBUG - 2024-02-12 10:08:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:08:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:08:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:09:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:09:14 --> Total execution time: 0.0638
DEBUG - 2024-02-12 10:09:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:09:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:09:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:09:31 --> Total execution time: 0.0701
DEBUG - 2024-02-12 10:09:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:09:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:09:41 --> Total execution time: 0.0721
DEBUG - 2024-02-12 10:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:09:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:09:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 10:09:58 --> Severity: Notice --> Undefined property: Welcome::$add C:\xampp\htdocs\habitro\admin\system\core\Model.php 74
ERROR - 2024-02-12 10:09:58 --> Severity: error --> Exception: Call to undefined function residentialpartner() C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 602
DEBUG - 2024-02-12 10:10:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:10:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:10:38 --> Total execution time: 0.0617
DEBUG - 2024-02-12 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:10:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:10:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:10:43 --> Total execution time: 0.0760
DEBUG - 2024-02-12 10:10:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:10:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:10:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 10:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 10:12:53 --> Total execution time: 0.1448
DEBUG - 2024-02-12 10:12:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 10:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 10:12:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:25 --> No URI present. Default controller set.
DEBUG - 2024-02-12 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:38:25 --> Total execution time: 0.0607
DEBUG - 2024-02-12 11:38:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:38:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:38:30 --> Total execution time: 0.0532
DEBUG - 2024-02-12 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:38:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:38:30 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:38:30 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:38:31 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:38:31 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:39:12 --> Total execution time: 0.0729
DEBUG - 2024-02-12 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:39:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:39:14 --> Total execution time: 0.0634
DEBUG - 2024-02-12 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:39:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:40:40 --> Total execution time: 0.0552
DEBUG - 2024-02-12 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:40:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:42:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:42:05 --> Total execution time: 0.0951
DEBUG - 2024-02-12 11:42:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:42:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:42:43 --> Total execution time: 0.1228
DEBUG - 2024-02-12 11:42:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:42:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:43:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:43:28 --> Total execution time: 0.1060
DEBUG - 2024-02-12 11:43:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:43:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:44:40 --> Total execution time: 0.0897
DEBUG - 2024-02-12 11:44:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:44:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:46:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:46:06 --> Total execution time: 0.1100
DEBUG - 2024-02-12 11:46:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:46:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:46:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:47:22 --> Total execution time: 0.1008
DEBUG - 2024-02-12 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:47:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:47:58 --> Total execution time: 0.1055
DEBUG - 2024-02-12 11:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:47:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:48:50 --> Total execution time: 0.1093
DEBUG - 2024-02-12 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:48:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:49:00 --> Total execution time: 0.0937
DEBUG - 2024-02-12 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:49:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:51:07 --> Total execution time: 0.1014
DEBUG - 2024-02-12 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:51:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:51:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:51:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:51:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:51:51 --> Total execution time: 0.1285
DEBUG - 2024-02-12 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:51:51 --> UTF-8 Support Enabled
ERROR - 2024-02-12 11:51:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:51:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:52:25 --> Total execution time: 0.1730
DEBUG - 2024-02-12 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:52:25 --> UTF-8 Support Enabled
ERROR - 2024-02-12 11:52:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:52:25 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:53:03 --> Total execution time: 0.1038
DEBUG - 2024-02-12 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:53:03 --> UTF-8 Support Enabled
ERROR - 2024-02-12 11:53:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:53:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:53:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:53:54 --> Total execution time: 0.1210
DEBUG - 2024-02-12 11:53:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:53:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:53:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:53:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:54:12 --> Total execution time: 0.0876
DEBUG - 2024-02-12 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:54:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 11:54:12 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:54:47 --> Total execution time: 0.1176
DEBUG - 2024-02-12 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:54:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:54:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:55:40 --> Total execution time: 0.1477
DEBUG - 2024-02-12 11:55:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:55:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:55:40 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:55:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:56:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:56:28 --> Total execution time: 0.1561
DEBUG - 2024-02-12 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:56:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:56:29 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:58:57 --> Total execution time: 0.1126
DEBUG - 2024-02-12 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:58:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:58:57 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:58:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:00 --> Total execution time: 0.0797
DEBUG - 2024-02-12 11:59:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:04 --> Total execution time: 0.0587
DEBUG - 2024-02-12 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:06 --> Total execution time: 0.0658
DEBUG - 2024-02-12 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:06 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 11:59:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:11 --> Total execution time: 0.0585
DEBUG - 2024-02-12 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:13 --> Total execution time: 0.0815
DEBUG - 2024-02-12 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:13 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:14 --> Total execution time: 0.0614
DEBUG - 2024-02-12 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 11:59:20 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:21 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:21 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 11:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:21 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 11:59:42 --> Total execution time: 0.1171
DEBUG - 2024-02-12 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:42 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 11:59:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 11:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:43 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-02-12 11:59:43 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 11:59:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 11:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 11:59:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:06:36 --> Total execution time: 0.1258
DEBUG - 2024-02-12 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:06:36 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:06:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:06:36 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:06:49 --> Total execution time: 0.0730
DEBUG - 2024-02-12 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:06:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:06:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 12:06:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:08:53 --> Total execution time: 0.1602
DEBUG - 2024-02-12 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:08:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:08:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:09:09 --> Total execution time: 0.0622
DEBUG - 2024-02-12 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:09:10 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:09:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:09:25 --> Total execution time: 0.1133
DEBUG - 2024-02-12 12:09:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:09:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:09:25 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:09:28 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:09:39 --> Total execution time: 0.0705
DEBUG - 2024-02-12 12:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:09:43 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:09:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:09:45 --> Total execution time: 0.0619
DEBUG - 2024-02-12 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:12:44 --> Total execution time: 0.1147
DEBUG - 2024-02-12 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:12:44 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 12:12:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:12:49 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:12:52 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:13:48 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:14:16 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:14:28 --> Total execution time: 0.0792
DEBUG - 2024-02-12 12:14:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:14:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:14:30 --> Total execution time: 0.0610
DEBUG - 2024-02-12 12:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:14:30 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 12:14:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:14:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:14:34 --> Severity: error --> Exception: Too few arguments to function Welcome::update_package(), 0 passed in C:\xampp\htdocs\habitro\admin\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\habitro\admin\application\controllers\Welcome.php 178
DEBUG - 2024-02-12 12:14:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:14:55 --> Total execution time: 0.0776
DEBUG - 2024-02-12 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:14:57 --> Total execution time: 0.0592
DEBUG - 2024-02-12 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:14:57 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:14:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:15:00 --> Total execution time: 0.0629
DEBUG - 2024-02-12 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 12:15:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:06 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:06 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 12:15:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:06 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:15:42 --> Total execution time: 0.1147
DEBUG - 2024-02-12 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:42 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:15:42 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:15:42 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:42 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:15:47 --> Total execution time: 0.1047
DEBUG - 2024-02-12 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:15:47 --> Total execution time: 0.1348
DEBUG - 2024-02-12 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:48 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 12:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:15:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:15:48 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 18
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 22
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 37
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 44
DEBUG - 2024-02-12 12:16:05 --> Total execution time: 0.0804
DEBUG - 2024-02-12 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 18
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 22
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 37
ERROR - 2024-02-12 12:16:05 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 44
DEBUG - 2024-02-12 12:16:05 --> Total execution time: 0.0748
DEBUG - 2024-02-12 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:16:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:17:35 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 29
DEBUG - 2024-02-12 12:17:35 --> Total execution time: 0.0739
DEBUG - 2024-02-12 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:17:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:17:36 --> Severity: Notice --> Undefined variable: tailcontent C:\xampp\htdocs\habitro\admin\application\views\edit\editpackage.php 29
DEBUG - 2024-02-12 12:17:36 --> Total execution time: 0.0877
DEBUG - 2024-02-12 12:17:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:17:45 --> Total execution time: 0.0853
DEBUG - 2024-02-12 12:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:17:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:17:45 --> Total execution time: 0.1502
DEBUG - 2024-02-12 12:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:17:56 --> Total execution time: 0.0661
DEBUG - 2024-02-12 12:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:17:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:17:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:17:59 --> Total execution time: 0.0606
DEBUG - 2024-02-12 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:59 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:17:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:17:59 --> Total execution time: 0.1087
DEBUG - 2024-02-12 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:06 --> Total execution time: 0.0587
DEBUG - 2024-02-12 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:06 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:18:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:18:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:09 --> Total execution time: 0.0678
DEBUG - 2024-02-12 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:18:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:09 --> Total execution time: 0.0928
DEBUG - 2024-02-12 12:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:34 --> Total execution time: 0.0721
DEBUG - 2024-02-12 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:18:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:18:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:43 --> Total execution time: 0.0639
DEBUG - 2024-02-12 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:18:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 12:18:43 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:47 --> Total execution time: 0.0650
DEBUG - 2024-02-12 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:18:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:18:47 --> Total execution time: 0.0900
DEBUG - 2024-02-12 12:19:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:19:36 --> Total execution time: 0.0916
DEBUG - 2024-02-12 12:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:19:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:19:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:19:36 --> Total execution time: 0.0801
DEBUG - 2024-02-12 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:20:33 --> Total execution time: 0.0762
DEBUG - 2024-02-12 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:20:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:20:33 --> Total execution time: 0.0742
DEBUG - 2024-02-12 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:20:47 --> Total execution time: 0.0626
DEBUG - 2024-02-12 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:20:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:20:47 --> Total execution time: 0.1697
DEBUG - 2024-02-12 12:22:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:22:26 --> Total execution time: 0.0709
DEBUG - 2024-02-12 12:22:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:22:26 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:22:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:22:26 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:22:33 --> Total execution time: 0.0813
DEBUG - 2024-02-12 12:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:22:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:22:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:22:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:22:33 --> Total execution time: 0.1411
DEBUG - 2024-02-12 12:23:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:23:48 --> Total execution time: 0.0760
DEBUG - 2024-02-12 12:23:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:23:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:23:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:23:51 --> Total execution time: 0.0811
DEBUG - 2024-02-12 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:23:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:23:51 --> Total execution time: 0.1356
DEBUG - 2024-02-12 12:23:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:23:58 --> Total execution time: 0.0633
DEBUG - 2024-02-12 12:23:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:23:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:23:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:23:58 --> Total execution time: 0.0937
DEBUG - 2024-02-12 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:05 --> Total execution time: 1.0325
DEBUG - 2024-02-12 12:26:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:05 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:26:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:06 --> Total execution time: 0.3161
DEBUG - 2024-02-12 12:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:09 --> Total execution time: 0.0616
DEBUG - 2024-02-12 12:26:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:09 --> Total execution time: 0.1428
DEBUG - 2024-02-12 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:11 --> Total execution time: 0.0990
DEBUG - 2024-02-12 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:14 --> Total execution time: 0.0646
DEBUG - 2024-02-12 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:26:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:14 --> Total execution time: 0.0822
DEBUG - 2024-02-12 12:26:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:19 --> Total execution time: 0.0545
DEBUG - 2024-02-12 12:26:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:19 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:26:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:26:19 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:42 --> Total execution time: 0.0630
DEBUG - 2024-02-12 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:26:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:42 --> Total execution time: 0.1029
DEBUG - 2024-02-12 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:26:59 --> Total execution time: 0.0581
DEBUG - 2024-02-12 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:26:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:26:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:26:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:26:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:15 --> Total execution time: 0.0725
DEBUG - 2024-02-12 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 12:29:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:29:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:18 --> Total execution time: 0.0802
DEBUG - 2024-02-12 12:29:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:18 --> Total execution time: 0.0804
DEBUG - 2024-02-12 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:23 --> Total execution time: 0.0602
DEBUG - 2024-02-12 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:29:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:28 --> Total execution time: 0.0699
DEBUG - 2024-02-12 12:29:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:28 --> Total execution time: 0.0736
DEBUG - 2024-02-12 12:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:34 --> Total execution time: 0.0572
DEBUG - 2024-02-12 12:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 12:29:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:38 --> Total execution time: 0.0934
DEBUG - 2024-02-12 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:38 --> Total execution time: 0.0880
DEBUG - 2024-02-12 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:29:46 --> Total execution time: 0.0670
DEBUG - 2024-02-12 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:29:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:32:14 --> Total execution time: 0.0662
DEBUG - 2024-02-12 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:32:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:32:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:32:37 --> Total execution time: 0.0692
DEBUG - 2024-02-12 12:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:32:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:32:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:32:37 --> Total execution time: 0.0834
DEBUG - 2024-02-12 12:34:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:34:23 --> Total execution time: 0.0713
DEBUG - 2024-02-12 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:34:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:34:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:34:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:03 --> Total execution time: 0.0574
DEBUG - 2024-02-12 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:35:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:35:03 --> Total execution time: 0.1458
DEBUG - 2024-02-12 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:06 --> Total execution time: 0.0575
DEBUG - 2024-02-12 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:35:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:06 --> Total execution time: 0.1703
DEBUG - 2024-02-12 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:48 --> Total execution time: 0.0651
DEBUG - 2024-02-12 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:35:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:35:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:54 --> Total execution time: 0.0688
DEBUG - 2024-02-12 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:35:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:35:55 --> Total execution time: 0.1193
DEBUG - 2024-02-12 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:36:13 --> Total execution time: 0.0598
DEBUG - 2024-02-12 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:36:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:36:13 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:37:50 --> Severity: Warning --> Use of undefined constant base - assumed 'base' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 18
ERROR - 2024-02-12 12:37:50 --> Severity: error --> Exception: Call to undefined function url() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 18
DEBUG - 2024-02-12 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:37:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:37:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:37:54 --> Severity: Warning --> Use of undefined constant base - assumed 'base' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 18
ERROR - 2024-02-12 12:37:54 --> Severity: error --> Exception: Call to undefined function url() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 18
DEBUG - 2024-02-12 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:37:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:37:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:37:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:37:59 --> Severity: Warning --> Use of undefined constant base - assumed 'base' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 18
ERROR - 2024-02-12 12:37:59 --> Severity: error --> Exception: Call to undefined function url() C:\xampp\htdocs\habitro\admin\application\views\pages\construction.php 18
DEBUG - 2024-02-12 12:37:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:37:59 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:37:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:37:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:38:09 --> Total execution time: 0.1125
DEBUG - 2024-02-12 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:38:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:38:09 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:38:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:38:18 --> Total execution time: 0.0967
DEBUG - 2024-02-12 12:38:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:38:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:38:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:38:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:38:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:38:19 --> 404 Page Not Found: Welcome/add_package
DEBUG - 2024-02-12 12:39:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:39:33 --> Total execution time: 0.0973
DEBUG - 2024-02-12 12:39:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:39:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:39:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:39:33 --> Total execution time: 0.1629
DEBUG - 2024-02-12 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:39:53 --> Total execution time: 0.0521
DEBUG - 2024-02-12 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:39:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:39:54 --> Total execution time: 0.1478
DEBUG - 2024-02-12 12:40:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:40:08 --> Total execution time: 0.0651
DEBUG - 2024-02-12 12:40:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:08 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:40:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:40:08 --> Total execution time: 0.0711
DEBUG - 2024-02-12 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:40:15 --> Total execution time: 0.0731
DEBUG - 2024-02-12 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:40:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:40:16 --> Total execution time: 0.0984
DEBUG - 2024-02-12 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:40:53 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\add\add-package.php 21
ERROR - 2024-02-12 12:40:53 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\add\add-package.php 28
DEBUG - 2024-02-12 12:40:53 --> Total execution time: 0.0861
DEBUG - 2024-02-12 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:40:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:40:53 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\add\add-package.php 21
ERROR - 2024-02-12 12:40:53 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\habitro\admin\application\views\add\add-package.php 28
DEBUG - 2024-02-12 12:40:53 --> Total execution time: 0.0924
DEBUG - 2024-02-12 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:41:06 --> Total execution time: 0.0747
DEBUG - 2024-02-12 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:41:06 --> UTF-8 Support Enabled
ERROR - 2024-02-12 12:41:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:41:06 --> Total execution time: 0.0617
DEBUG - 2024-02-12 12:43:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:43:58 --> Total execution time: 0.1000
DEBUG - 2024-02-12 12:43:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:43:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:43:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:43:58 --> Total execution time: 0.1429
DEBUG - 2024-02-12 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:44:59 --> Total execution time: 0.0810
DEBUG - 2024-02-12 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:44:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:44:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:44:59 --> Total execution time: 0.0790
DEBUG - 2024-02-12 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:46:00 --> Total execution time: 0.1035
DEBUG - 2024-02-12 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 12:46:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:46:00 --> Total execution time: 0.0986
DEBUG - 2024-02-12 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:48:16 --> Total execution time: 0.0978
DEBUG - 2024-02-12 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:48:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:48:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:48:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:48:16 --> Total execution time: 0.1408
DEBUG - 2024-02-12 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:49:04 --> Total execution time: 0.0742
DEBUG - 2024-02-12 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:49:04 --> Total execution time: 0.0705
DEBUG - 2024-02-12 12:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:49:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:49:54 --> Total execution time: 0.0681
DEBUG - 2024-02-12 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:49:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:49:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:51:13 --> Total execution time: 0.0764
DEBUG - 2024-02-12 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:51:14 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 12:51:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:51:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:51:16 --> Total execution time: 0.0787
DEBUG - 2024-02-12 12:51:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:51:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:51:16 --> Total execution time: 0.0867
DEBUG - 2024-02-12 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:51:32 --> Total execution time: 0.0571
DEBUG - 2024-02-12 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:51:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:51:32 --> Total execution time: 0.0923
DEBUG - 2024-02-12 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:58:11 --> Total execution time: 0.0701
DEBUG - 2024-02-12 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:58:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:58:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:58:14 --> Total execution time: 0.0881
DEBUG - 2024-02-12 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:58:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:58:14 --> Total execution time: 0.0969
DEBUG - 2024-02-12 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 12:58:35 --> Total execution time: 0.0633
DEBUG - 2024-02-12 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 12:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:58:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 12:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 12:58:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:00:03 --> Total execution time: 0.1157
DEBUG - 2024-02-12 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:00:03 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:00:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:00:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:00:14 --> Total execution time: 0.1030
DEBUG - 2024-02-12 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:00:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:00:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:00:30 --> Total execution time: 0.0956
DEBUG - 2024-02-12 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:00:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 13:00:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:00:44 --> Total execution time: 0.1115
DEBUG - 2024-02-12 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:00:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:00:44 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:01:01 --> Total execution time: 0.0632
DEBUG - 2024-02-12 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:01:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:01:01 --> Total execution time: 0.0872
DEBUG - 2024-02-12 13:01:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:01:32 --> Total execution time: 0.0575
DEBUG - 2024-02-12 13:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:13:45 --> No URI present. Default controller set.
DEBUG - 2024-02-12 13:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:13:45 --> Total execution time: 0.1289
DEBUG - 2024-02-12 13:13:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:13:46 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:14:05 --> Total execution time: 0.0754
DEBUG - 2024-02-12 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:14:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:14:05 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:14:05 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:14:05 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:14:05 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:14:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:14:07 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:14:07 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:14:59 --> Total execution time: 0.1525
DEBUG - 2024-02-12 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:14:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:14:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:18:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:18:22 --> Total execution time: 0.1448
DEBUG - 2024-02-12 13:18:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:18:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:18:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:18:22 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:22:21 --> Total execution time: 0.0980
DEBUG - 2024-02-12 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:22:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:22:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:22:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:22:25 --> Total execution time: 0.0780
DEBUG - 2024-02-12 13:22:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:22:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:22:25 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:22:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:22:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:22:27 --> Total execution time: 0.0733
DEBUG - 2024-02-12 13:22:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:22:27 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:22:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:22:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:23:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:23:15 --> Total execution time: 0.0975
DEBUG - 2024-02-12 13:23:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:23:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:23:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:23:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:23:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:23:59 --> Total execution time: 0.0882
DEBUG - 2024-02-12 13:23:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:23:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:23:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:23:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:24:02 --> Total execution time: 0.0712
DEBUG - 2024-02-12 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:24:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:24:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:24:20 --> Total execution time: 0.1038
DEBUG - 2024-02-12 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:24:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 13:24:20 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:25:26 --> Total execution time: 0.1573
DEBUG - 2024-02-12 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:25:26 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:25:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:25:28 --> Total execution time: 0.0627
DEBUG - 2024-02-12 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:25:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:25:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:25:30 --> Total execution time: 0.0764
DEBUG - 2024-02-12 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:25:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:25:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:25:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:26:26 --> Total execution time: 0.1485
DEBUG - 2024-02-12 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:26:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:26:26 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:27:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:27:16 --> Total execution time: 0.1399
DEBUG - 2024-02-12 13:27:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:27:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:27:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:27:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:27:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:27:59 --> 404 Page Not Found: Welcome/profile
DEBUG - 2024-02-12 13:28:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:28:46 --> Total execution time: 0.0908
DEBUG - 2024-02-12 13:28:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:28:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:28:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:28:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:34:05 --> Total execution time: 0.1088
DEBUG - 2024-02-12 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:05 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:05 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:34:05 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:05 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:07 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:07 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:34:08 --> Total execution time: 0.0662
DEBUG - 2024-02-12 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:08 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:08 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:34:08 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:34:10 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:34:10 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:42:11 --> Total execution time: 0.1295
DEBUG - 2024-02-12 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:11 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:11 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:13 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:13 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:42:30 --> Total execution time: 0.0742
DEBUG - 2024-02-12 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:30 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:31 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:32 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:42:32 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:42:50 --> Total execution time: 0.0585
DEBUG - 2024-02-12 13:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:50 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:50 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:50 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:42:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:42:51 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:42:51 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:43:59 --> Total execution time: 0.0630
DEBUG - 2024-02-12 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:43:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:43:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:43:59 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:43:59 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:44:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:01 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:44:01 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:44:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 13:44:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\habitro\admin\application\views\dashboard.php 62
ERROR - 2024-02-12 13:44:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\habitro\admin\application\views\dashboard.php 79
DEBUG - 2024-02-12 13:44:22 --> Total execution time: 0.1064
DEBUG - 2024-02-12 13:44:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:22 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:44:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:23 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:24 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:44:24 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:45:09 --> Total execution time: 0.1329
DEBUG - 2024-02-12 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:09 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:45:09 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:09 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:11 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:45:11 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:45:33 --> Total execution time: 0.0776
DEBUG - 2024-02-12 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:45:33 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:45:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:33 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:33 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:45:35 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:45:35 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:47:34 --> Total execution time: 0.1075
DEBUG - 2024-02-12 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:34 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:47:34 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:47:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:34 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:47:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:47:36 --> Total execution time: 0.0658
DEBUG - 2024-02-12 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:36 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:36 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:36 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:36 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:47:37 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:47:37 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:48:08 --> Total execution time: 0.0865
DEBUG - 2024-02-12 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 13:48:08 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:48:08 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:48:08 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:09 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:48:09 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:48:54 --> Total execution time: 0.0775
DEBUG - 2024-02-12 13:48:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:54 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:48:54 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:48:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:48:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:54 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:54 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:56 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:48:56 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:48:56 --> Total execution time: 0.0735
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:56 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:56 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:48:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:56 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:48:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:48:59 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:48:59 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:49:28 --> Total execution time: 0.1244
DEBUG - 2024-02-12 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:49:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:49:28 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:49:28 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:49:28 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:49:29 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:49:29 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 13:50:18 --> Severity: Notice --> Undefined variable: count3 C:\xampp\htdocs\habitro\admin\application\views\dashboard.php 62
DEBUG - 2024-02-12 13:50:18 --> Total execution time: 0.1275
DEBUG - 2024-02-12 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:18 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:50:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:18 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:20 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:50:20 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:50:43 --> Total execution time: 0.0896
DEBUG - 2024-02-12 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:43 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:50:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:45 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:50:45 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:51:13 --> Total execution time: 0.0781
DEBUG - 2024-02-12 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:51:13 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:51:13 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:51:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:51:13 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:51:13 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:51:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:51:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:51:15 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:51:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:52:15 --> Total execution time: 0.0862
DEBUG - 2024-02-12 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:15 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:17 --> 404 Page Not Found: Images/testimonial
ERROR - 2024-02-12 13:52:17 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:52:42 --> Total execution time: 0.0785
DEBUG - 2024-02-12 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:43 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:52:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:43 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:52:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:52:44 --> 404 Page Not Found: Images/testimonial
DEBUG - 2024-02-12 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:53:19 --> Total execution time: 0.0868
DEBUG - 2024-02-12 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:53:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:53:19 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:53:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:53:52 --> Total execution time: 0.0853
DEBUG - 2024-02-12 13:53:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:53:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:53:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:53:52 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:53:59 --> Total execution time: 0.0693
DEBUG - 2024-02-12 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:53:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:53:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:56:55 --> Total execution time: 0.0847
DEBUG - 2024-02-12 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:56:55 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-12 13:56:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:57:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:57:18 --> Total execution time: 0.0767
DEBUG - 2024-02-12 13:57:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:57:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:57:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:29 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:57:29 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:58:14 --> Total execution time: 0.0880
DEBUG - 2024-02-12 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:58:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:58:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2024-02-12 13:58:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:58:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:58:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:59:14 --> Total execution time: 0.0825
DEBUG - 2024-02-12 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:14 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:59:15 --> UTF-8 Support Enabled
ERROR - 2024-02-12 13:59:15 --> 404 Page Not Found: Assets/css
DEBUG - 2024-02-12 13:59:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:15 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 13:59:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:15 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-12 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:59:30 --> Total execution time: 0.0632
DEBUG - 2024-02-12 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:59:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:59:32 --> Total execution time: 0.0833
DEBUG - 2024-02-12 13:59:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 13:59:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:32 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 13:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:59:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 13:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 13:59:39 --> Total execution time: 0.0525
DEBUG - 2024-02-12 13:59:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 13:59:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 13:59:40 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 08:05:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:05:39 --> No URI present. Default controller set.
DEBUG - 2024-02-12 08:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 08:05:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/manosprm/demo.godparticles.uk/habitro/admin/system/database/drivers/mysqli/mysqli_driver.php 211
ERROR - 2024-02-12 08:05:39 --> Unable to connect to the database
DEBUG - 2024-02-12 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:33 --> No URI present. Default controller set.
DEBUG - 2024-02-12 08:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:06:33 --> Total execution time: 0.0185
DEBUG - 2024-02-12 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:33 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:06:38 --> Total execution time: 0.0126
DEBUG - 2024-02-12 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:06:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:06:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:06:46 --> Total execution time: 0.0120
DEBUG - 2024-02-12 08:06:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:06:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:06:52 --> Total execution time: 0.0117
DEBUG - 2024-02-12 08:06:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:06:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:06:53 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:08:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:08:35 --> Total execution time: 0.0612
DEBUG - 2024-02-12 08:08:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:08:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:08:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:08:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:09:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:09:09 --> Total execution time: 0.0108
DEBUG - 2024-02-12 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:09:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:09:10 --> Total execution time: 0.0150
DEBUG - 2024-02-12 08:12:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:12:33 --> Total execution time: 0.0610
DEBUG - 2024-02-12 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:12:47 --> Total execution time: 0.0117
DEBUG - 2024-02-12 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:12:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-12 08:12:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 17
ERROR - 2024-02-12 08:12:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 18
ERROR - 2024-02-12 08:12:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 22
ERROR - 2024-02-12 08:12:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 29
DEBUG - 2024-02-12 08:12:47 --> Total execution time: 0.0092
DEBUG - 2024-02-12 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:13:17 --> Total execution time: 0.0154
DEBUG - 2024-02-12 08:13:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:13:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:13:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 08:13:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 17
ERROR - 2024-02-12 08:13:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 18
ERROR - 2024-02-12 08:13:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 22
ERROR - 2024-02-12 08:13:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 29
DEBUG - 2024-02-12 08:13:18 --> Total execution time: 0.0135
DEBUG - 2024-02-12 08:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:14:25 --> Total execution time: 0.0187
DEBUG - 2024-02-12 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:14:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:14:25 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:14:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:14:50 --> Total execution time: 0.0126
DEBUG - 2024-02-12 08:14:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:14:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:14:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 08:14:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 17
ERROR - 2024-02-12 08:14:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 18
ERROR - 2024-02-12 08:14:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 22
ERROR - 2024-02-12 08:14:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 29
DEBUG - 2024-02-12 08:14:50 --> Total execution time: 0.0138
DEBUG - 2024-02-12 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:15:10 --> Total execution time: 0.0089
DEBUG - 2024-02-12 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:15:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:15:10 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:15:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:15:20 --> Total execution time: 0.0144
DEBUG - 2024-02-12 08:15:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:15:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:15:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:15:20 --> Total execution time: 0.0098
DEBUG - 2024-02-12 08:16:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:16:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:16:41 --> Total execution time: 0.0117
DEBUG - 2024-02-12 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:16:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:16:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:16:56 --> Total execution time: 0.0115
DEBUG - 2024-02-12 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:16:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:16:56 --> Total execution time: 0.0064
DEBUG - 2024-02-12 08:17:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:17:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:17:28 --> Total execution time: 0.0095
DEBUG - 2024-02-12 08:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:17:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:17:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:17:29 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:17:50 --> Total execution time: 0.0123
DEBUG - 2024-02-12 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:17:50 --> Total execution time: 0.0069
DEBUG - 2024-02-12 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:17:50 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:18:26 --> Total execution time: 0.0116
DEBUG - 2024-02-12 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:18:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:18:26 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:20:57 --> Total execution time: 0.0550
DEBUG - 2024-02-12 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:20:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:20:57 --> Total execution time: 0.0099
DEBUG - 2024-02-12 08:21:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:21:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:21:43 --> Total execution time: 0.0111
DEBUG - 2024-02-12 08:21:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:21:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:21:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:21:44 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:46:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:46:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:46:41 --> Total execution time: 0.0073
DEBUG - 2024-02-12 08:46:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:46:42 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:46:48 --> Total execution time: 0.0175
DEBUG - 2024-02-12 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:46:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:46:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:46:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:47:06 --> Total execution time: 0.0162
DEBUG - 2024-02-12 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:47:08 --> Total execution time: 0.0119
DEBUG - 2024-02-12 08:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:08 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:47:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:08 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:47:15 --> Total execution time: 0.0105
DEBUG - 2024-02-12 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:47:15 --> Total execution time: 0.0100
DEBUG - 2024-02-12 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:47:38 --> Total execution time: 0.0082
DEBUG - 2024-02-12 08:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:47:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:47:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:49:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:49:18 --> Total execution time: 0.0974
DEBUG - 2024-02-12 08:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:49:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:49:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:49:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:49:24 --> Total execution time: 0.0153
DEBUG - 2024-02-12 08:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:49:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:49:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 08:49:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 17
ERROR - 2024-02-12 08:49:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 18
ERROR - 2024-02-12 08:49:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 22
ERROR - 2024-02-12 08:49:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 29
DEBUG - 2024-02-12 08:49:24 --> Total execution time: 0.0089
DEBUG - 2024-02-12 08:49:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:49:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:49:52 --> Total execution time: 0.0077
DEBUG - 2024-02-12 08:49:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:49:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:49:53 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:49:53 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:49:59 --> Total execution time: 0.0095
DEBUG - 2024-02-12 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:49:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:49:59 --> Total execution time: 0.0061
DEBUG - 2024-02-12 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:50:27 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:50:27 --> Total execution time: 0.1928
DEBUG - 2024-02-12 08:50:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:50:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:50:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:50:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:50:47 --> Total execution time: 0.0153
DEBUG - 2024-02-12 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:50:47 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:50:47 --> Total execution time: 0.0100
DEBUG - 2024-02-12 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 08:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 08:51:11 --> Total execution time: 0.0110
DEBUG - 2024-02-12 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:51:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 08:51:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 08:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 08:51:11 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:01:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:41 --> Total execution time: 0.0096
DEBUG - 2024-02-12 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:46 --> Total execution time: 0.0162
DEBUG - 2024-02-12 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:01:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:01:46 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:52 --> Total execution time: 0.0163
DEBUG - 2024-02-12 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:01:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:01:52 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:55 --> Total execution time: 0.0164
DEBUG - 2024-02-12 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:01:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:01:55 --> Total execution time: 0.0079
DEBUG - 2024-02-12 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:02:25 --> Total execution time: 0.0112
DEBUG - 2024-02-12 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:02:25 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:02:25 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:02:29 --> Total execution time: 0.0105
DEBUG - 2024-02-12 09:02:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:02:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:02:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:02:30 --> Total execution time: 0.0112
DEBUG - 2024-02-12 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:04:21 --> Total execution time: 0.0121
DEBUG - 2024-02-12 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:04:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:04:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:04:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:04:31 --> Total execution time: 0.0074
DEBUG - 2024-02-12 09:04:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:04:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:04:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-12 09:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 17
ERROR - 2024-02-12 09:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 18
ERROR - 2024-02-12 09:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 22
ERROR - 2024-02-12 09:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 29
DEBUG - 2024-02-12 09:04:32 --> Total execution time: 0.0129
DEBUG - 2024-02-12 09:04:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:04:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:04:48 --> Total execution time: 0.0107
DEBUG - 2024-02-12 09:04:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:04:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:04:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:04:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:05:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:05:03 --> Total execution time: 0.0105
DEBUG - 2024-02-12 09:05:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:05:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:05:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:05:03 --> Total execution time: 0.0071
DEBUG - 2024-02-12 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:05:28 --> Total execution time: 0.0078
DEBUG - 2024-02-12 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:05:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:05:28 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:08:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:08:52 --> Total execution time: 0.0629
DEBUG - 2024-02-12 09:08:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:08:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:08:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:08:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:08:52 --> Total execution time: 0.0097
DEBUG - 2024-02-12 09:09:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:09:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:09:16 --> Total execution time: 0.0154
DEBUG - 2024-02-12 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:09:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:09:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:09:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:09:29 --> Total execution time: 0.0512
DEBUG - 2024-02-12 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:09:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:09:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:09:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:09:32 --> Total execution time: 0.0160
DEBUG - 2024-02-12 09:09:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:09:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:09:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:09:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:11:18 --> Total execution time: 0.0590
DEBUG - 2024-02-12 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:11:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:11:18 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:12:28 --> Total execution time: 0.0135
DEBUG - 2024-02-12 09:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:12:29 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:12:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:12:29 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:14:17 --> Total execution time: 0.0852
DEBUG - 2024-02-12 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:14:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:14:17 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:14:22 --> Total execution time: 0.0110
DEBUG - 2024-02-12 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:14:22 --> Total execution time: 0.0076
DEBUG - 2024-02-12 09:14:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:14:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:14:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:15:40 --> Total execution time: 0.0114
DEBUG - 2024-02-12 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:15:40 --> Total execution time: 0.0063
DEBUG - 2024-02-12 09:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:15:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:16:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:16:07 --> Total execution time: 0.0146
DEBUG - 2024-02-12 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:16:07 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:16:07 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:16:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:16:34 --> Total execution time: 0.0157
DEBUG - 2024-02-12 09:16:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:16:35 --> UTF-8 Support Enabled
ERROR - 2024-02-12 09:16:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 17
ERROR - 2024-02-12 09:16:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 18
ERROR - 2024-02-12 09:16:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 22
ERROR - 2024-02-12 09:16:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editpackage.php 29
DEBUG - 2024-02-12 09:16:35 --> Total execution time: 0.0145
DEBUG - 2024-02-12 09:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:16:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:16:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:16:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:16:49 --> Total execution time: 0.0080
DEBUG - 2024-02-12 09:16:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:16:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:16:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:16:49 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:17:22 --> Total execution time: 0.0134
DEBUG - 2024-02-12 09:19:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:19:17 --> No URI present. Default controller set.
DEBUG - 2024-02-12 09:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:19:17 --> Total execution time: 0.0720
DEBUG - 2024-02-12 09:19:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:19:20 --> No URI present. Default controller set.
DEBUG - 2024-02-12 09:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:19:20 --> Total execution time: 0.0084
DEBUG - 2024-02-12 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:19:58 --> Total execution time: 0.0113
DEBUG - 2024-02-12 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:19:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-12 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:19:59 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-12 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:35:58 --> No URI present. Default controller set.
DEBUG - 2024-02-12 09:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:35:58 --> Total execution time: 0.0802
DEBUG - 2024-02-12 09:36:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:36:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-12 09:36:02 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-12 09:41:54 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:41:54 --> No URI present. Default controller set.
DEBUG - 2024-02-12 09:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:41:54 --> Total execution time: 0.0557
DEBUG - 2024-02-12 09:42:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-12 09:42:04 --> No URI present. Default controller set.
DEBUG - 2024-02-12 09:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-12 09:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-12 09:42:04 --> Total execution time: 0.0099

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-03-02 07:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:48:20 --> No URI present. Default controller set.
DEBUG - 2024-03-02 07:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:48:20 --> Total execution time: 0.0822
DEBUG - 2024-03-02 07:48:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:48:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:48:21 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-02 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:52:03 --> Total execution time: 0.0778
DEBUG - 2024-03-02 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:52:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:52:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:54:14 --> Total execution time: 0.0749
DEBUG - 2024-03-02 07:54:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:54:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:54:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:54:48 --> Total execution time: 0.0682
DEBUG - 2024-03-02 07:54:48 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:54:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:54:54 --> Total execution time: 0.0754
DEBUG - 2024-03-02 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:54:54 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:55:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:55:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:55:53 --> Total execution time: 0.0586
DEBUG - 2024-03-02 07:55:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:55:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:56:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:56:09 --> Total execution time: 0.0744
DEBUG - 2024-03-02 07:56:09 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:56:09 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:56:17 --> Total execution time: 0.0650
DEBUG - 2024-03-02 07:56:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:56:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:56:26 --> Total execution time: 0.0728
DEBUG - 2024-03-02 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:56:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:56:58 --> Total execution time: 0.0698
DEBUG - 2024-03-02 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:56:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:57:11 --> Total execution time: 0.0697
DEBUG - 2024-03-02 07:57:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:57:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:57:14 --> Total execution time: 0.0595
DEBUG - 2024-03-02 07:57:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:57:23 --> Total execution time: 0.0720
DEBUG - 2024-03-02 07:57:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:57:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:57:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:57:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:57:34 --> Total execution time: 0.0613
DEBUG - 2024-03-02 07:57:34 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:57:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:57:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 07:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 07:59:28 --> Total execution time: 0.1416
DEBUG - 2024-03-02 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 07:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 07:59:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:07:31 --> Total execution time: 0.1440
DEBUG - 2024-03-02 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:07:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:08:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:08:13 --> Total execution time: 0.1366
DEBUG - 2024-03-02 08:08:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:08:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:08:45 --> Total execution time: 0.1358
DEBUG - 2024-03-02 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:08:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:09:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:09:17 --> Total execution time: 0.1382
DEBUG - 2024-03-02 08:09:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:09:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:24 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:25 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:25 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:09:41 --> Total execution time: 0.1150
DEBUG - 2024-03-02 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:41 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:41 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:41 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:09:43 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:10:17 --> Total execution time: 0.1360
DEBUG - 2024-03-02 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:10:17 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:10:17 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-02 08:10:17 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:10:17 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:10:18 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:12:03 --> Total execution time: 0.1155
DEBUG - 2024-03-02 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:04 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:12:05 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:05 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:12:30 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:12:31 --> Total execution time: 0.0945
DEBUG - 2024-03-02 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:38 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:39 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:12:39 --> UTF-8 Support Enabled
ERROR - 2024-03-02 08:12:39 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:12:39 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:13:04 --> Total execution time: 0.1226
DEBUG - 2024-03-02 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:13:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:13:04 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:13:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:13:04 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:13:06 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:14:24 --> Total execution time: 0.0675
DEBUG - 2024-03-02 08:14:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:14:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:14:25 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:14:25 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:14:25 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:14:25 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:14:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:14:26 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:15:11 --> Total execution time: 0.1380
DEBUG - 2024-03-02 08:15:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:15:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:15:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:15:40 --> Total execution time: 0.1061
DEBUG - 2024-03-02 08:15:40 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:15:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:16:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:16:14 --> Total execution time: 0.0702
DEBUG - 2024-03-02 08:16:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:16:14 --> Total execution time: 0.0683
DEBUG - 2024-03-02 08:16:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:16:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:16:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:17:55 --> Total execution time: 0.1342
DEBUG - 2024-03-02 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:17:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:17:59 --> Total execution time: 0.0603
DEBUG - 2024-03-02 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:17:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:18:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:18:02 --> Total execution time: 0.0640
DEBUG - 2024-03-02 08:18:02 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:18:02 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:18:10 --> Total execution time: 0.0654
DEBUG - 2024-03-02 08:18:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:18:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:18:16 --> Total execution time: 0.0531
DEBUG - 2024-03-02 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:18:16 --> Total execution time: 0.0574
DEBUG - 2024-03-02 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:18:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:18:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:27:51 --> Total execution time: 0.1265
DEBUG - 2024-03-02 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:27:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:28:13 --> Total execution time: 0.1409
DEBUG - 2024-03-02 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:28:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:28:41 --> Total execution time: 0.1310
DEBUG - 2024-03-02 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:28:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:29:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:29:12 --> Total execution time: 0.1263
DEBUG - 2024-03-02 08:29:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:29:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:29:42 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:29:43 --> Total execution time: 0.1124
DEBUG - 2024-03-02 08:29:43 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:29:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:29:43 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:29:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:29:55 --> Total execution time: 0.1209
DEBUG - 2024-03-02 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:29:55 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:30:04 --> Total execution time: 0.1247
DEBUG - 2024-03-02 08:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:30:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:30:38 --> Total execution time: 0.1068
DEBUG - 2024-03-02 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:30:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:31:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:31:23 --> Total execution time: 0.1188
DEBUG - 2024-03-02 08:31:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:31:24 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:32:49 --> Total execution time: 0.0932
DEBUG - 2024-03-02 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:32:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:32:49 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:32:53 --> Total execution time: 0.0780
DEBUG - 2024-03-02 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:32:53 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:32:59 --> Total execution time: 0.0609
DEBUG - 2024-03-02 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:32:59 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:33:03 --> Total execution time: 0.0581
DEBUG - 2024-03-02 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:33:06 --> Total execution time: 0.0667
DEBUG - 2024-03-02 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:33:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:33:11 --> Total execution time: 0.0560
DEBUG - 2024-03-02 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:33:11 --> Total execution time: 0.0823
DEBUG - 2024-03-02 08:33:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:33:11 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:33:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:33:15 --> Total execution time: 0.0611
DEBUG - 2024-03-02 08:33:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:33:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:33:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:40:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:40:19 --> Total execution time: 0.1204
DEBUG - 2024-03-02 08:40:19 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:40:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:40:19 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:41:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:41:52 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:41:52 --> UTF-8 Support Enabled
ERROR - 2024-03-02 08:41:52 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:41:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:41:53 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:41:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:41:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:41:53 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:41:53 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:41:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:41:53 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:42:12 --> Total execution time: 0.0848
DEBUG - 2024-03-02 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:12 --> 404 Page Not Found: Assets/vendor
ERROR - 2024-03-02 08:42:12 --> 404 Page Not Found: Assets/css
DEBUG - 2024-03-02 08:42:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:13 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:42:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:14 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-03-02 08:42:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:42:33 --> Total execution time: 0.0595
DEBUG - 2024-03-02 08:42:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:33 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:42:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:42:37 --> Total execution time: 0.0628
DEBUG - 2024-03-02 08:42:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:37 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:42:39 --> Total execution time: 0.0745
DEBUG - 2024-03-02 08:42:39 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:39 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:42:44 --> Total execution time: 0.0584
DEBUG - 2024-03-02 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:42:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:45:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:45:20 --> Total execution time: 0.0770
DEBUG - 2024-03-02 08:45:20 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:45:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:46:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:46:10 --> Total execution time: 0.0753
DEBUG - 2024-03-02 08:46:10 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:46:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 08:46:14 --> Total execution time: 0.0603
DEBUG - 2024-03-02 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 08:46:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 08:46:14 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 09:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 09:27:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 09:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 09:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 09:27:14 --> Total execution time: 0.0774
DEBUG - 2024-03-02 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 09:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 09:27:15 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-02 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 12:46:24 --> No URI present. Default controller set.
DEBUG - 2024-03-02 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 12:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 12:46:24 --> Total execution time: 0.1380
DEBUG - 2024-03-02 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 12:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 12:46:24 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-02 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 12:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 12:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 12:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 12:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 12:46:28 --> Total execution time: 0.0700
DEBUG - 2024-03-02 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 12:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 12:46:28 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 14:59:54 --> No URI present. Default controller set.
DEBUG - 2024-03-02 14:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 14:59:54 --> Total execution time: 0.2320
DEBUG - 2024-03-02 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 14:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 14:59:55 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-02 15:00:11 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:00:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:00:12 --> Total execution time: 0.0816
DEBUG - 2024-03-02 15:00:12 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:00:12 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:04:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:04:13 --> Total execution time: 0.0717
DEBUG - 2024-03-02 15:04:13 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:04:13 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:04:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:04:18 --> Total execution time: 0.0681
DEBUG - 2024-03-02 15:04:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:04:18 --> Total execution time: 0.0665
DEBUG - 2024-03-02 15:04:18 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:04:18 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:04:23 --> Total execution time: 0.0637
DEBUG - 2024-03-02 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:04:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:04:26 --> Total execution time: 0.1341
DEBUG - 2024-03-02 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:04:26 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:04:31 --> Total execution time: 0.0836
DEBUG - 2024-03-02 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:04:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:24:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:24:32 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:24:32 --> Total execution time: 0.0530
DEBUG - 2024-03-02 15:24:33 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:24:33 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-03-02 15:24:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:24:37 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:24:37 --> Total execution time: 0.0509
DEBUG - 2024-03-02 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:24:44 --> Total execution time: 0.0601
DEBUG - 2024-03-02 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:24:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:24:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-03-02 15:28:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-03-02 15:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-03-02 15:28:14 --> Total execution time: 0.0592
DEBUG - 2024-03-02 15:28:14 --> UTF-8 Support Enabled
DEBUG - 2024-03-02 15:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-03-02 15:28:14 --> 404 Page Not Found: Assets/datatables

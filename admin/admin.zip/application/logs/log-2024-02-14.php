<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-14 02:07:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:07:21 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:07:21 --> Total execution time: 0.1804
DEBUG - 2024-02-14 02:07:26 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:07:26 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-14 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:08:29 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:08:29 --> Total execution time: 0.0103
DEBUG - 2024-02-14 02:08:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:08:40 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:08:40 --> Total execution time: 0.0057
DEBUG - 2024-02-14 02:08:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:08:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:08:46 --> Total execution time: 0.0117
DEBUG - 2024-02-14 02:08:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:08:46 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:08:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:08:47 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:12:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:12:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:12:51 --> Total execution time: 0.0052
DEBUG - 2024-02-14 02:12:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:12:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:12:56 --> Total execution time: 0.0097
DEBUG - 2024-02-14 02:12:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:12:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:12:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:12:57 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:13:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:13:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:13:08 --> Total execution time: 0.0064
DEBUG - 2024-02-14 02:13:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:13:12 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:13:12 --> Total execution time: 0.0083
DEBUG - 2024-02-14 02:14:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:14:39 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:14:39 --> Total execution time: 0.0639
DEBUG - 2024-02-14 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:10 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:15:10 --> Total execution time: 0.0102
DEBUG - 2024-02-14 02:15:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:14 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:15:14 --> Total execution time: 0.0102
DEBUG - 2024-02-14 02:15:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:15:15 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-14 02:15:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:18 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:15:18 --> Total execution time: 0.0089
DEBUG - 2024-02-14 02:15:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:35 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:15:35 --> Total execution time: 0.0087
DEBUG - 2024-02-14 02:15:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:42 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:15:42 --> Total execution time: 0.0094
DEBUG - 2024-02-14 02:15:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:15:44 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:15:44 --> Total execution time: 0.0080
DEBUG - 2024-02-14 02:16:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:16:01 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:16:01 --> Total execution time: 0.0126
DEBUG - 2024-02-14 02:16:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:16:03 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:16:03 --> Total execution time: 0.0114
DEBUG - 2024-02-14 02:16:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:16:06 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:16:06 --> Total execution time: 0.0086
DEBUG - 2024-02-14 02:16:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:16:08 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:16:08 --> Total execution time: 0.0050
DEBUG - 2024-02-14 02:16:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:16:10 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:16:10 --> Total execution time: 0.0084
DEBUG - 2024-02-14 02:27:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:27:28 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:27:28 --> Total execution time: 0.0843
DEBUG - 2024-02-14 02:27:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:27:39 --> 404 Page Not Found: Images/favicon.png
DEBUG - 2024-02-14 02:27:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:27:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:27:44 --> Total execution time: 0.0112
DEBUG - 2024-02-14 02:27:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:27:45 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:27:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:27:45 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:28:01 --> Total execution time: 0.0203
DEBUG - 2024-02-14 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:01 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:01 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:28:03 --> Total execution time: 0.0181
DEBUG - 2024-02-14 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:03 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:03 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:28:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:28:50 --> Total execution time: 0.0168
DEBUG - 2024-02-14 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:28:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:28:57 --> Total execution time: 0.0090
DEBUG - 2024-02-14 02:28:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:28:57 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-14 02:28:57 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:06 --> Total execution time: 0.0081
DEBUG - 2024-02-14 02:29:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:10 --> Total execution time: 0.0136
DEBUG - 2024-02-14 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:10 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-14 02:29:10 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 17
ERROR - 2024-02-14 02:29:10 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 18
ERROR - 2024-02-14 02:29:10 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 22
ERROR - 2024-02-14 02:29:10 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 29
DEBUG - 2024-02-14 02:29:10 --> Total execution time: 0.0077
DEBUG - 2024-02-14 02:29:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:13 --> Total execution time: 0.0080
DEBUG - 2024-02-14 02:29:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:16 --> Total execution time: 0.0071
DEBUG - 2024-02-14 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:16 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:16 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:20 --> Total execution time: 0.0103
DEBUG - 2024-02-14 02:29:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:21 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:21 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:22 --> Total execution time: 0.0116
DEBUG - 2024-02-14 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:31 --> Total execution time: 0.0110
DEBUG - 2024-02-14 02:29:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:31 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:34 --> Total execution time: 0.0085
DEBUG - 2024-02-14 02:29:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:35 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:35 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:37 --> Total execution time: 0.0269
DEBUG - 2024-02-14 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-14 02:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 17
ERROR - 2024-02-14 02:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 18
ERROR - 2024-02-14 02:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 22
ERROR - 2024-02-14 02:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editcta.php 29
DEBUG - 2024-02-14 02:29:38 --> Total execution time: 0.0173
DEBUG - 2024-02-14 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:40 --> Total execution time: 0.0066
DEBUG - 2024-02-14 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:40 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:42 --> Total execution time: 0.0167
DEBUG - 2024-02-14 02:29:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:42 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:29:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:42 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:29:48 --> Total execution time: 0.0091
DEBUG - 2024-02-14 02:29:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:29:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:29:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:30:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:30:03 --> Total execution time: 0.0134
DEBUG - 2024-02-14 02:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:30:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:30:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 02:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 02:30:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 02:31:55 --> No URI present. Default controller set.
DEBUG - 2024-02-14 02:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 02:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 02:31:55 --> Total execution time: 0.0731
DEBUG - 2024-02-14 03:38:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:38:46 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-14 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:15 --> Total execution time: 0.0189
DEBUG - 2024-02-14 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:15 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:15 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:18 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-14 03:50:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:23 --> Total execution time: 0.0164
DEBUG - 2024-02-14 03:50:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:23 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:23 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:30 --> Total execution time: 0.0163
DEBUG - 2024-02-14 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:30 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:30 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:31 --> Total execution time: 0.0099
DEBUG - 2024-02-14 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:32 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:32 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:34 --> Total execution time: 0.0117
DEBUG - 2024-02-14 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:34 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:34 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:39 --> Total execution time: 0.0131
DEBUG - 2024-02-14 03:50:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:40 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-14 03:50:40 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/profile.php 17
ERROR - 2024-02-14 03:50:40 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/profile.php 18
ERROR - 2024-02-14 03:50:40 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/profile.php 22
ERROR - 2024-02-14 03:50:40 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/profile.php 26
ERROR - 2024-02-14 03:50:40 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/profile.php 39
ERROR - 2024-02-14 03:50:40 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/profile.php 43
DEBUG - 2024-02-14 03:50:40 --> Total execution time: 0.0085
DEBUG - 2024-02-14 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:46 --> Total execution time: 0.0146
DEBUG - 2024-02-14 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:51 --> Total execution time: 0.0113
DEBUG - 2024-02-14 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:51 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:51 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:56 --> Total execution time: 0.0123
DEBUG - 2024-02-14 03:50:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:56 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:56 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:50:58 --> Total execution time: 0.0071
DEBUG - 2024-02-14 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:58 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:50:58 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:00 --> Total execution time: 0.0073
DEBUG - 2024-02-14 03:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:00 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:00 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:03 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:03 --> Total execution time: 0.0104
DEBUG - 2024-02-14 03:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:04 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:04 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:06 --> Total execution time: 0.0086
DEBUG - 2024-02-14 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:06 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:06 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:19 --> Total execution time: 0.0122
DEBUG - 2024-02-14 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:20 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 17
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 18
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 22
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 29
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 36
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 43
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 50
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 60
ERROR - 2024-02-14 03:51:20 --> Severity: Notice --> Trying to access array offset on value of type null /home/manosprm/demo.godparticles.uk/habitro/admin/application/views/edit/editbanner.php 67
DEBUG - 2024-02-14 03:51:20 --> Total execution time: 0.0127
DEBUG - 2024-02-14 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:30 --> Total execution time: 0.0062
DEBUG - 2024-02-14 03:51:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:31 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:31 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:33 --> Total execution time: 0.0171
DEBUG - 2024-02-14 03:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2024-02-14 03:51:33 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:38 --> Total execution time: 0.0083
DEBUG - 2024-02-14 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:38 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:38 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:44 --> Total execution time: 0.0070
DEBUG - 2024-02-14 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:44 --> 404 Page Not Found: Vendor/summernote
ERROR - 2024-02-14 03:51:44 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:47 --> Total execution time: 0.0079
DEBUG - 2024-02-14 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:48 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:51:48 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:51:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:51:57 --> Total execution time: 0.0064
DEBUG - 2024-02-14 03:52:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:52:40 --> Total execution time: 0.0198
DEBUG - 2024-02-14 03:52:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:52:41 --> 404 Page Not Found: Assets/datatables
DEBUG - 2024-02-14 03:52:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:52:41 --> 404 Page Not Found: Vendor/summernote
DEBUG - 2024-02-14 03:54:37 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:54:38 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:54:38 --> Total execution time: 0.0110
DEBUG - 2024-02-14 03:54:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:54:40 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-14 03:54:45 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:54:45 --> Total execution time: 0.0085
DEBUG - 2024-02-14 03:54:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:54:49 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-14 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:54:59 --> Total execution time: 0.0115
DEBUG - 2024-02-14 03:55:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:55:02 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-14 03:55:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:13 --> Total execution time: 0.0086
DEBUG - 2024-02-14 03:55:15 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:15 --> No URI present. Default controller set.
DEBUG - 2024-02-14 03:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:15 --> Total execution time: 0.0121
DEBUG - 2024-02-14 03:55:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:16 --> No URI present. Default controller set.
DEBUG - 2024-02-14 03:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:16 --> Total execution time: 0.0084
DEBUG - 2024-02-14 03:55:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:16 --> No URI present. Default controller set.
DEBUG - 2024-02-14 03:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:16 --> Total execution time: 0.0053
DEBUG - 2024-02-14 03:55:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:17 --> No URI present. Default controller set.
DEBUG - 2024-02-14 03:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:17 --> Total execution time: 0.0085
DEBUG - 2024-02-14 03:55:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-02-14 03:55:19 --> 404 Page Not Found: Assets/vendor
DEBUG - 2024-02-14 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-14 03:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-14 03:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-14 03:55:41 --> Total execution time: 0.0055
